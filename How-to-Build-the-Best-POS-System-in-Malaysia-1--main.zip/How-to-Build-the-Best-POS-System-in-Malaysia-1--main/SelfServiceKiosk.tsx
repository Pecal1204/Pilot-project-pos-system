import { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { usePOS, MenuItem, CartItem } from "@/lib/pos-context";
import { Badge } from "@/components/ui/badge";
import { ShoppingCart, Plus, Minus, User, CreditCard, Send } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/components/ui/use-toast";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";

export default function SelfServiceKiosk() {
  const { 
    menuItems, 
    cart, 
    addToCart, 
    removeFromCart, 
    updateCartItemQuantity,
    clearCart,
    createOrder,
    recommendations,
    sendWhatsAppReceipt
  } = usePOS();

  const [activeTab, setActiveTab] = useState("menu");
  const [customerName, setCustomerName] = useState("");
  const [customerPhone, setCustomerPhone] = useState("");
  const [paymentMethod, setPaymentMethod] = useState("");
  const [orderComplete, setOrderComplete] = useState(false);
  const [orderNumber, setOrderNumber] = useState("");
  const [showCartDialog, setShowCartDialog] = useState(false);
  const [receiptSent, setReceiptSent] = useState(false);

  const categories = [...new Set(menuItems.map(item => item.category))];
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  const filteredItems = selectedCategory 
    ? menuItems.filter(item => item.category === selectedCategory)
    : menuItems;

  const cartTotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const taxAmount = cartTotal * 0.06; // 6% tax
  const finalTotal = cartTotal + taxAmount;

  const handleCategorySelect = (category: string) => {
    setSelectedCategory(prevCategory => prevCategory === category ? null : category);
  };

  const { toast } = useToast();
  
  const handleCheckout = () => {
    if (cart.length === 0) {
      toast({
        title: "Cart is empty",
        description: "Please add items to your cart before proceeding to checkout.",
        variant: "destructive"
      });
      return;
    }
    setActiveTab("checkout");
  };

  const handlePlaceOrder = () => {
    if (!paymentMethod) {
      toast({
        title: "Payment method required",
        description: "Please select a payment method to complete your order.",
        variant: "destructive"
      });
      return;
    }

    // Create the order
    const order = createOrder(undefined, customerName || "Guest", customerPhone);
    setOrderNumber(order.id);
    setOrderComplete(true);
    setActiveTab("confirmation");

    // Send receipt if phone number is provided
    if (customerPhone) {
      sendWhatsAppReceipt(order.id, customerPhone);
      setReceiptSent(true);
    }
  };

  const handleStartNewOrder = () => {
    setActiveTab("menu");
    setCustomerName("");
    setCustomerPhone("");
    setPaymentMethod("");
    setOrderComplete(false);
    setOrderNumber("");
    setReceiptSent(false);
    clearCart();
  };

  const renderMenuItem = (item: MenuItem) => (
    <Card key={item.id} className="overflow-hidden">
      <div className="aspect-video w-full overflow-hidden bg-muted">
        <img 
          src={item.imageUrl || `https://source.unsplash.com/random/300x200/?food,${item.name}`} 
          alt={item.name}
          className="h-full w-full object-cover transition-all hover:scale-105"
        />
      </div>
      <CardHeader className="p-4">
        <div className="flex justify-between items-start">
          <CardTitle className="text-lg">{item.name}</CardTitle>
          <Badge variant="outline">RM {item.price.toFixed(2)}</Badge>
        </div>
        <CardDescription className="line-clamp-2 h-10">{item.description}</CardDescription>
      </CardHeader>
      <CardFooter className="p-4 pt-0 flex justify-between">
        {cart.find(cartItem => cartItem.id === item.id) ? (
          <div className="flex items-center gap-2">
            <Button 
              variant="outline" 
              size="icon" 
              onClick={() => removeFromCart(item.id)}
            >
              <Minus className="h-4 w-4" />
            </Button>
            <span className="w-8 text-center">
              {cart.find(cartItem => cartItem.id === item.id)?.quantity || 0}
            </span>
            <Button 
              variant="outline" 
              size="icon" 
              onClick={() => addToCart(item)}
            >
              <Plus className="h-4 w-4" />
            </Button>
          </div>
        ) : (
          <Button onClick={() => addToCart(item)}>Add to Cart</Button>
        )}
      </CardFooter>
    </Card>
  );

  const renderCartItem = (item: CartItem) => (
    <div key={item.id} className="flex justify-between items-center py-2">
      <div className="flex-1">
        <p className="font-medium">{item.name}</p>
        <p className="text-sm text-muted-foreground">RM {item.price.toFixed(2)} each</p>
      </div>
      <div className="flex items-center gap-2">
        <Button 
          variant="outline" 
          size="icon" 
          onClick={() => removeFromCart(item.id)}
        >
          <Minus className="h-4 w-4" />
        </Button>
        <span className="w-8 text-center">{item.quantity}</span>
        <Button 
          variant="outline" 
          size="icon" 
          onClick={() => addToCart(item)}
        >
          <Plus className="h-4 w-4" />
        </Button>
      </div>
      <div className="w-24 text-right">
        RM {(item.price * item.quantity).toFixed(2)}
      </div>
    </div>
  );

  return (
    <div className="flex flex-col min-h-screen">
      <header className="bg-primary text-primary-foreground py-4 px-6 flex justify-between items-center">
        <h1 className="text-xl font-bold">MalaysiaDish POS</h1>
        {activeTab !== "confirmation" && (
          <Button 
            variant="secondary" 
            className="flex items-center gap-2"
            onClick={() => setShowCartDialog(true)}
          >
            <ShoppingCart className="h-4 w-4" />
            <span>Cart ({cart.reduce((sum, item) => sum + item.quantity, 0)})</span>
          </Button>
        )}
      </header>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 container mx-auto py-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="menu" disabled={orderComplete}>Menu</TabsTrigger>
          <TabsTrigger value="checkout" disabled={cart.length === 0 || orderComplete}>Checkout</TabsTrigger>
          <TabsTrigger value="confirmation" disabled={!orderComplete}>Confirmation</TabsTrigger>
        </TabsList>

        <TabsContent value="menu" className="py-4">
          <div className="flex flex-col gap-6">
            <div className="flex gap-2 overflow-x-auto pb-2">
              {categories.map(category => (
                <Button 
                  key={category}
                  variant={selectedCategory === category ? "default" : "outline"}
                  onClick={() => handleCategorySelect(category)}
                >
                  {category}
                </Button>
              ))}
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filteredItems.map(renderMenuItem)}
            </div>

            {recommendations.length > 0 && (
              <div className="mt-8">
                <h2 className="text-xl font-bold mb-4">Recommended for You</h2>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  {recommendations.map(rec => {
                    const item = menuItems.find(item => item.id === rec.productId);
                    if (!item) return null;
                    
                    return (
                      <Card key={rec.id} className="bg-primary/5">
                        <CardHeader className="pb-2">
                          <CardTitle className="text-lg">{item.name}</CardTitle>
                          <CardDescription>{rec.reason}</CardDescription>
                        </CardHeader>
                        <CardFooter>
                          <Button onClick={() => addToCart(item)}>Add to Cart</Button>
                        </CardFooter>
                      </Card>
                    );
                  })}
                </div>
              </div>
            )}

            {cart.length > 0 && (
              <div className="mt-4 flex justify-end">
                <Button size="lg" onClick={handleCheckout}>
                  Proceed to Checkout
                </Button>
              </div>
            )}
          </div>
        </TabsContent>

        <TabsContent value="checkout" className="py-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <h2 className="text-xl font-bold mb-4">Order Summary</h2>
              <Card>
                <CardContent className="pt-6">
                  {cart.map(renderCartItem)}
                  
                  <Separator className="my-4" />
                  
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span>Subtotal</span>
                      <span>RM {cartTotal.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between">
                      <span>Tax (6%)</span>
                      <span>RM {taxAmount.toFixed(2)}</span>
                    </div>
                    <div className="flex justify-between font-bold">
                      <span>Total</span>
                      <span>RM {finalTotal.toFixed(2)}</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            <div>
              <h2 className="text-xl font-bold mb-4">Customer Information</h2>
              <Card>
                <CardContent className="pt-6 space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name (Optional)</Label>
                    <Input 
                      id="name" 
                      placeholder="Enter your name" 
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label htmlFor="phone">Phone Number (For WhatsApp Receipt)</Label>
                    <Input 
                      id="phone" 
                      placeholder="e.g., +60123456789" 
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                    />
                  </div>
                  
                  <Separator />
                  
                  <div className="space-y-2">
                    <Label>Payment Method</Label>
                    <div className="grid grid-cols-2 gap-2">
                      {['Credit Card', 'Debit Card', 'Touch n Go', 'GrabPay', 'Boost', 'DuitNow QR'].map(method => (
                        <Button
                          key={method}
                          variant={paymentMethod === method ? "default" : "outline"}
                          className="justify-start"
                          onClick={() => setPaymentMethod(method)}
                        >
                          <CreditCard className="mr-2 h-4 w-4" />
                          {method}
                        </Button>
                      ))}
                    </div>
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <Button variant="outline" onClick={() => setActiveTab("menu")}>
                    Back to Menu
                  </Button>
                  <Button onClick={handlePlaceOrder}>
                    Place Order
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="confirmation" className="py-4">
          <Card className="max-w-md mx-auto">
            <CardHeader className="text-center">
              <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
                <User className="h-8 w-8 text-primary" />
              </div>
              <CardTitle className="text-2xl">Order Confirmed!</CardTitle>
              <CardDescription>
                Thank you for your order. Your order number is <strong>{orderNumber}</strong>.
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="bg-muted p-4 rounded-md">
                <p className="font-medium">Order Summary</p>
                <p className="text-sm">Total: RM {finalTotal.toFixed(2)}</p>
                <p className="text-sm">Payment Method: {paymentMethod}</p>
              </div>
              
              {receiptSent && (
                <div className="flex items-center gap-2 text-sm text-green-600">
                  <Send className="h-4 w-4" />
                  <span>Receipt sent to your WhatsApp</span>
                </div>
              )}
            </CardContent>
            <CardFooter>
              <Button className="w-full" onClick={handleStartNewOrder}>
                Start New Order
              </Button>
            </CardFooter>
          </Card>
        </TabsContent>
      </Tabs>

      <Dialog open={showCartDialog} onOpenChange={setShowCartDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Your Cart</DialogTitle>
            <DialogDescription>
              {cart.length === 0 ? "Your cart is empty" : `${cart.length} items in your cart`}
            </DialogDescription>
          </DialogHeader>
          
          {cart.length > 0 && (
            <>
              <div className="max-h-[60vh] overflow-y-auto">
                {cart.map(renderCartItem)}
              </div>
              
              <Separator />
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span>RM {cartTotal.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span>Tax (6%)</span>
                  <span>RM {taxAmount.toFixed(2)}</span>
                </div>
                <div className="flex justify-between font-bold">
                  <span>Total</span>
                  <span>RM {finalTotal.toFixed(2)}</span>
                </div>
              </div>
            </>
          )}
          
          <DialogFooter>
            {cart.length > 0 ? (
              <Button onClick={() => {
                setShowCartDialog(false);
                handleCheckout();
              }}>
                Proceed to Checkout
              </Button>
            ) : (
              <Button onClick={() => setShowCartDialog(false)}>
                Continue Shopping
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <footer className="bg-muted py-4 px-6 text-center text-sm">
        <p>MalaysiaDish POS System &copy; 2025 | IRBM e-Invoicing Compliant</p>
      </footer>
    </div>
  );
}
