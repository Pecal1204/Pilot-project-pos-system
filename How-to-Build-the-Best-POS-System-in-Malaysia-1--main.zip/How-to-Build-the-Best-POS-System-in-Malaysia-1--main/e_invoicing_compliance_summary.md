# Malaysia E-Invoicing Compliance Requirements for POS Systems

## Implementation Timeline

Based on the IRBM e-Invoice Guideline (Version 4.3, March 18, 2025), Malaysia is implementing mandatory e-invoicing in phases:

1. **August 1, 2024**: Businesses with annual turnover/revenue > RM100 million
2. **January 1, 2025**: Businesses with annual turnover/revenue > RM25 million and up to RM100 million
3. **July 1, 2025**: Businesses with annual turnover/revenue > RM500,000 and up to RM25 million
4. **January 1, 2026**: Businesses with annual turnover/revenue up to RM500,000

The annual turnover/revenue is determined based on:
- Audited financial statements for financial year 2022, or
- Tax return for year of assessment 2022 (if no audited statements)

For new businesses starting from 2023-2024:
- With revenue > RM500,000: Implementation date is July 1, 2025
- With revenue ≤ RM500,000: Implementation date is January 1, 2026

For new businesses starting from 2025 onwards:
- Implementation date is January 1, 2026 or upon operation commencement

## Technical Requirements

### Format Requirements
- E-invoices must be generated in XML or JSON format
- Must adhere to Universal Business Language (UBL) 2.1 standard
- Must include all mandatory fields as specified in the IRBM guidelines

### Transmission Methods
IRBM provides two transmission mechanisms:

1. **MyInvois Portal**:
   - Web-based portal hosted by IRBM
   - Allows manual generation through forms or batch upload via spreadsheets
   - Suitable for businesses with lower transaction volumes
   - Free to use

2. **API Integration**:
   - Direct integration with business systems
   - Methods include:
     - Direct ERP integration with MyInvois System
     - Integration through Peppol technology providers
     - Integration through non-Peppol technology providers
   - Suitable for businesses with high transaction volumes
   - Requires technical implementation and potential investment

### POS-Specific Requirements

The MyInvois e-POS System is specifically provided by IRBM for micro and small enterprises:
- Available free of charge
- Enhances business operational efficiency
- Meets e-Invoice implementation requirements
- Features include:
  - Sales management
  - Accounting
  - Inventory management
  - Financial reporting
  - Direct e-Invoice generation during transactions

For businesses with existing POS systems, they must ensure their systems can:
1. Generate e-invoices in the required format (XML/JSON with UBL 2.1)
2. Transmit e-invoices to IRBM via Portal or API
3. Store validated e-invoices for record-keeping

## Workflow Requirements

The e-invoicing workflow includes:

1. **Creation**: Generate e-invoice with all required fields
2. **Submission**: Submit to IRBM via Portal or API
3. **Validation**: IRBM validates the e-invoice
4. **Notification**: Supplier receives validation status
5. **Sharing**: Validated e-invoice shared with buyer
6. **Storage**: E-invoices stored in IRBM database

## Special Considerations

### Consolidated E-Invoices
- For transactions with buyers who don't require individual e-invoices
- Can be issued on a monthly basis
- Not allowed for certain activities requiring per-transaction e-invoices

### Self-Billed E-Invoices
- Required for certain scenarios including foreign transactions
- Special fields and workflow apply

### Exemptions
Certain entities are exempted from e-invoicing requirements:
- Foreign diplomatic offices
- Individuals not conducting business
- Statutory bodies (for certain transactions before July 1, 2025)
- International organizations (for transactions before July 1, 2025)
- Taxpayers with annual turnover/revenue < RM150,000

## Interim Relaxation Period
The IRBM has provided interim relaxation periods for each implementation phase to ease transition.

## Compliance Implications for POS Systems

For a POS system to be compliant with Malaysia's e-invoicing requirements by mid-2025:

1. **Format Compliance**: Must generate e-invoices in XML or JSON format adhering to UBL 2.1 standard
2. **Transmission Capability**: Must integrate with either MyInvois Portal or API
3. **Data Fields**: Must capture and include all mandatory fields required by IRBM
4. **Validation Handling**: Must process validation responses from IRBM
5. **Storage**: Must store validated e-invoices for record-keeping
6. **Consolidated Invoicing**: Should support consolidated e-invoicing for applicable scenarios
7. **Self-Billing**: Should support self-billed e-invoices for applicable scenarios

## Resources Available

1. **MyInvois Portal**: Free e-invoicing solution provided by IRBM
2. **MyInvois e-POS**: Free POS system with e-invoicing capabilities for micro and small enterprises
3. **Guidelines**: Comprehensive documentation from IRBM
4. **Software Development Kit (SDK)**: For technical implementation
5. **Training Materials**: For staff training and implementation guidance
