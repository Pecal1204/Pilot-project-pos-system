import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { RootState } from '../../store';
import { api } from '../../services/api';

interface Channel {
  id: string;
  name: string;
  type: 'in_store' | 'online' | 'mobile' | 'kiosk' | 'third_party';
  isActive: boolean;
  syncEnabled: boolean;
  lastSyncTime: string | null;
  apiEndpoint?: string;
  apiKey?: string;
}

interface SyncStatus {
  channel: string;
  entity: 'product' | 'inventory' | 'order' | 'customer' | 'promotion';
  status: 'pending' | 'in_progress' | 'completed' | 'failed';
  startTime: string;
  endTime?: string;
  itemsProcessed?: number;
  totalItems?: number;
  error?: string;
}

interface OmnichannelState {
  channels: Channel[];
  activeChannels: string[];
  syncHistory: SyncStatus[];
  currentSyncs: SyncStatus[];
  isConfiguring: boolean;
  configError: string | null;
  realTimeSyncEnabled: boolean;
  syncInterval: number; // in minutes
  lastFullSyncTime: string | null;
}

const initialState: OmnichannelState = {
  channels: [
    {
      id: 'in_store',
      name: 'In-Store POS',
      type: 'in_store',
      isActive: true,
      syncEnabled: true,
      lastSyncTime: new Date().toISOString()
    },
    {
      id: 'online_web',
      name: 'Online Website',
      type: 'online',
      isActive: true,
      syncEnabled: true,
      lastSyncTime: null
    },
    {
      id: 'mobile_app',
      name: 'Mobile App',
      type: 'mobile',
      isActive: true,
      syncEnabled: true,
      lastSyncTime: null
    },
    {
      id: 'self_kiosk',
      name: 'Self-Service Kiosk',
      type: 'kiosk',
      isActive: true,
      syncEnabled: true,
      lastSyncTime: null
    },
    {
      id: 'food_panda',
      name: 'Food Panda',
      type: 'third_party',
      isActive: false,
      syncEnabled: false,
      lastSyncTime: null,
      apiEndpoint: 'https://api.foodpanda.my/partner',
      apiKey: 'fp_api_key_placeholder'
    },
    {
      id: 'grab_food',
      name: 'Grab Food',
      type: 'third_party',
      isActive: false,
      syncEnabled: false,
      lastSyncTime: null,
      apiEndpoint: 'https://api.grab.com/food/partner',
      apiKey: 'grab_api_key_placeholder'
    }
  ],
  activeChannels: ['in_store', 'online_web', 'mobile_app', 'self_kiosk'],
  syncHistory: [],
  currentSyncs: [],
  isConfiguring: false,
  configError: null,
  realTimeSyncEnabled: true,
  syncInterval: 15,
  lastFullSyncTime: null
};

export const omnichannelSlice = createSlice({
  name: 'omnichannel',
  initialState,
  reducers: {
    setChannelActive: (state, action: PayloadAction<{ channelId: string; isActive: boolean }>) => {
      const channel = state.channels.find(c => c.id === action.payload.channelId);
      if (channel) {
        channel.isActive = action.payload.isActive;
        
        // Update activeChannels list
        if (action.payload.isActive) {
          if (!state.activeChannels.includes(channel.id)) {
            state.activeChannels.push(channel.id);
          }
        } else {
          state.activeChannels = state.activeChannels.filter(id => id !== channel.id);
        }
      }
    },
    setChannelSyncEnabled: (state, action: PayloadAction<{ channelId: string; syncEnabled: boolean }>) => {
      const channel = state.channels.find(c => c.id === action.payload.channelId);
      if (channel) {
        channel.syncEnabled = action.payload.syncEnabled;
      }
    },
    updateChannelConfig: (state, action: PayloadAction<Partial<Channel> & { id: string }>) => {
      const index = state.channels.findIndex(c => c.id === action.payload.id);
      if (index !== -1) {
        state.channels[index] = {
          ...state.channels[index],
          ...action.payload
        };
      }
    },
    addChannel: (state, action: PayloadAction<Omit<Channel, 'lastSyncTime'> & { lastSyncTime?: string | null }>) => {
      state.channels.push({
        ...action.payload,
        lastSyncTime: action.payload.lastSyncTime || null
      });
      
      if (action.payload.isActive) {
        state.activeChannels.push(action.payload.id);
      }
    },
    removeChannel: (state, action: PayloadAction<string>) => {
      state.channels = state.channels.filter(c => c.id !== action.payload);
      state.activeChannels = state.activeChannels.filter(id => id !== action.payload);
    },
    addSyncStatus: (state, action: PayloadAction<SyncStatus>) => {
      state.currentSyncs.push(action.payload);
    },
    updateSyncStatus: (state, action: PayloadAction<Partial<SyncStatus> & { channel: string; entity: 'product' | 'inventory' | 'order' | 'customer' | 'promotion' }>) => {
      const index = state.currentSyncs.findIndex(
        s => s.channel === action.payload.channel && s.entity === action.payload.entity
      );
      
      if (index !== -1) {
        state.currentSyncs[index] = {
          ...state.currentSyncs[index],
          ...action.payload
        };
        
        // If sync is completed or failed, move to history
        if (action.payload.status === 'completed' || action.payload.status === 'failed') {
          const completedSync = {
            ...state.currentSyncs[index],
            ...action.payload,
            endTime: action.payload.endTime || new Date().toISOString()
          };
          
          state.syncHistory.unshift(completedSync);
          state.currentSyncs.splice(index, 1);
          
          // Update channel lastSyncTime if completed successfully
          if (action.payload.status === 'completed') {
            const channelIndex = state.channels.findIndex(c => c.id === action.payload.channel);
            if (channelIndex !== -1) {
              state.channels[channelIndex].lastSyncTime = completedSync.endTime;
            }
          }
        }
      }
    },
    setRealTimeSyncEnabled: (state, action: PayloadAction<boolean>) => {
      state.realTimeSyncEnabled = action.payload;
    },
    setSyncInterval: (state, action: PayloadAction<number>) => {
      state.syncInterval = action.payload;
    },
    setLastFullSyncTime: (state, action: PayloadAction<string>) => {
      state.lastFullSyncTime = action.payload;
    },
    setIsConfiguring: (state, action: PayloadAction<boolean>) => {
      state.isConfiguring = action.payload;
    },
    setConfigError: (state, action: PayloadAction<string | null>) => {
      state.configError = action.payload;
    },
    clearSyncHistory: (state) => {
      state.syncHistory = [];
    }
  },
  extraReducers: (builder) => {
    builder
      .addMatcher(
        api.endpoints.syncChannel?.matchPending,
        (state, { meta }) => {
          const { channel, entity } = meta.arg.originalArgs;
          
          // Add to currentSyncs if not already there
          const existingSync = state.currentSyncs.find(
            s => s.channel === channel && s.entity === entity
          );
          
          if (!existingSync) {
            state.currentSyncs.push({
              channel,
              entity,
              status: 'in_progress',
              startTime: new Date().toISOString()
            });
          } else {
            // Update existing sync
            existingSync.status = 'in_progress';
            existingSync.startTime = new Date().toISOString();
            existingSync.error = undefined;
          }
        }
      )
      .addMatcher(
        api.endpoints.syncChannel?.matchFulfilled,
        (state, { meta, payload }) => {
          const { channel, entity } = meta.arg.originalArgs;
          
          // Find and update sync status
          const syncIndex = state.currentSyncs.findIndex(
            s => s.channel === channel && s.entity === entity
          );
          
          if (syncIndex !== -1) {
            const completedSync = {
              ...state.currentSyncs[syncIndex],
              status: 'completed',
              endTime: new Date().toISOString(),
              itemsProcessed: payload.data.itemsProcessed,
              totalItems: payload.data.totalItems
            };
            
            // Move to history
            state.syncHistory.unshift(completedSync);
            state.currentSyncs.splice(syncIndex, 1);
            
            // Update channel lastSyncTime
            const channelIndex = state.channels.findIndex(c => c.id === channel);
            if (channelIndex !== -1) {
              state.channels[channelIndex].lastSyncTime = completedSync.endTime;
            }
          }
        }
      )
      .addMatcher(
        api.endpoints.syncChannel?.matchRejected,
        (state, { meta, error }) => {
          const { channel, entity } = meta.arg.originalArgs;
          
          // Find and update sync status
          const syncIndex = state.currentSyncs.findIndex(
            s => s.channel === channel && s.entity === entity
          );
          
          if (syncIndex !== -1) {
            const failedSync = {
              ...state.currentSyncs[syncIndex],
              status: 'failed',
              endTime: new Date().toISOString(),
              error: error.message || 'Sync failed'
            };
            
            // Move to history
            state.syncHistory.unshift(failedSync);
            state.currentSyncs.splice(syncIndex, 1);
          }
        }
      );
  }
});

export const {
  setChannelActive,
  setChannelSyncEnabled,
  updateChannelConfig,
  addChannel,
  removeChannel,
  addSyncStatus,
  updateSyncStatus,
  setRealTimeSyncEnabled,
  setSyncInterval,
  setLastFullSyncTime,
  setIsConfiguring,
  setConfigError,
  clearSyncHistory
} = omnichannelSlice.actions;

// Selectors
export const selectChannels = (state: RootState) => state.omnichannel.channels;
export const selectActiveChannels = (state: RootState) => 
  state.omnichannel.channels.filter(c => state.omnichannel.activeChannels.includes(c.id));
export const selectSyncEnabledChannels = (state: RootState) => 
  state.omnichannel.channels.filter(c => c.syncEnabled);
export const selectCurrentSyncs = (state: RootState) => state.omnichannel.currentSyncs;
export const selectSyncHistory = (state: RootState) => state.omnichannel.syncHistory;
export const selectIsConfiguring = (state: RootState) => state.omnichannel.isConfiguring;
export const selectConfigError = (state: RootState) => state.omnichannel.configError;
export const selectRealTimeSyncEnabled = (state: RootState) => state.omnichannel.realTimeSyncEnabled;
export const selectSyncInterval = (state: RootState) => state.omnichannel.syncInterval;
export const selectLastFullSyncTime = (state: RootState) => state.omnichannel.lastFullSyncTime;
export const selectChannelById = (id: string) => (state: RootState) => 
  state.omnichannel.channels.find(c => c.id === id);

export default omnichannelSlice.reducer;
