import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import { orderRoutes } from './routes/orderRoutes';
import { eInvoiceRoutes } from './routes/eInvoiceRoutes';
import { paymentRoutes } from './routes/paymentRoutes';
import { aiRoutes } from './routes/aiRoutes';
import { communicationRoutes } from './routes/communicationRoutes';

const app = express();
const PORT = process.env.PORT || 3001;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Routes
app.use('/api/orders', orderRoutes);
app.use('/api/e-invoice', eInvoiceRoutes);
app.use('/api/payments', paymentRoutes);
app.use('/api/ai', aiRoutes);
app.use('/api/communication', communicationRoutes);

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    timestamp: new Date().toISOString(),
    version: '1.0.0',
    environment: process.env.NODE_ENV || 'development'
  });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error('Error:', err);
  
  res.status(err.status || 500).json({
    success: false,
    error: {
      code: err.code || 'INTERNAL_SERVER_ERROR',
      message: err.message || 'An unexpected error occurred'
    }
  });
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`MalaysiaDish POS API Server running on port ${PORT}`);
});

export default app;
