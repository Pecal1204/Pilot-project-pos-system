import React, { useState } from 'react';
import { 
  Box, 
  Typography, 
  Paper, 
  Grid, 
  Card, 
  CardContent, 
  Button, 
  Divider,
  TextField,
  InputAdornment,
  IconButton,
  Tabs,
  Tab,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  Chip
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import EditIcon from '@mui/icons-material/Edit';
import DeleteIcon from '@mui/icons-material/Delete';
import AddIcon from '@mui/icons-material/Add';
import { ProductCategory, ProductStatus } from '@malaysiadish-pos/common';
import { useGetProductsQuery } from '../services/api';

const MenuPage: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  
  const { data: productsData, isLoading } = useGetProductsQuery({ 
    category: selectedCategory === 'ALL' ? undefined : selectedCategory,
    search: searchQuery || undefined
  });
  
  const handleTabChange = (event: React.SyntheticEvent, newValue: string) => {
    setSelectedCategory(newValue);
  };
  
  const getStatusChip = (status: ProductStatus) => {
    let color;
    switch (status) {
      case ProductStatus.ACTIVE:
        color = 'success';
        break;
      case ProductStatus.OUT_OF_STOCK:
        color = 'warning';
        break;
      case ProductStatus.DISCONTINUED:
        color = 'error';
        break;
      default:
        color = 'default';
    }
    
    return <Chip label={status} color={color as any} size="small" />;
  };
  
  return (
    <Box sx={{ flexGrow: 1 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4">Menu Management</Typography>
        <Button variant="contained" startIcon={<AddIcon />}>
          Add New Item
        </Button>
      </Box>
      
      <Paper sx={{ mb: 3, p: 2 }}>
        <Grid container spacing={2} alignItems="center">
          <Grid item xs={12} md={6}>
            <TextField
              fullWidth
              placeholder="Search menu items..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              InputProps={{
                startAdornment: (
                  <InputAdornment position="start">
                    <SearchIcon />
                  </InputAdornment>
                ),
              }}
            />
          </Grid>
          <Grid item xs={12} md={6}>
            <Tabs
              value={selectedCategory}
              onChange={handleTabChange}
              variant="scrollable"
              scrollButtons="auto"
            >
              <Tab label="All Items" value="ALL" />
              <Tab label="Food" value={ProductCategory.FOOD} />
              <Tab label="Beverages" value={ProductCategory.BEVERAGE} />
              <Tab label="Desserts" value={ProductCategory.DESSERT} />
              <Tab label="Combo Meals" value={ProductCategory.COMBO} />
            </Tabs>
          </Grid>
        </Grid>
      </Paper>
      
      <Paper>
        <List>
          {isLoading ? (
            <ListItem>
              <ListItemText primary="Loading menu items..." />
            </ListItem>
          ) : productsData?.data?.length === 0 ? (
            <ListItem>
              <ListItemText primary="No menu items found" />
            </ListItem>
          ) : (
            productsData?.data?.map((product) => (
              <React.Fragment key={product.id}>
                <ListItem>
                  <Box sx={{ display: 'flex', alignItems: 'center', width: 80, height: 80, mr: 2, bgcolor: 'grey.100', borderRadius: 1 }}>
                    {product.imageUrl ? (
                      <img 
                        src={product.imageUrl} 
                        alt={product.name} 
                        style={{ maxWidth: '100%', maxHeight: '100%', objectFit: 'contain' }} 
                      />
                    ) : (
                      <Box sx={{ width: '100%', height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'text.secondary' }}>
                        No Image
                      </Box>
                    )}
                  </Box>
                  <ListItemText
                    primary={
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <Typography variant="subtitle1">{product.name}</Typography>
                        <Box sx={{ ml: 2 }}>{getStatusChip(product.status)}</Box>
                      </Box>
                    }
                    secondary={
                      <>
                        <Typography variant="body2" color="text.secondary">
                          {product.description}
                        </Typography>
                        <Typography variant="body2" color="text.primary" sx={{ mt: 1 }}>
                          Category: {product.category}
                        </Typography>
                        <Typography variant="body2" color="primary" sx={{ fontWeight: 'bold' }}>
                          RM {product.price.toFixed(2)}
                        </Typography>
                      </>
                    }
                    primaryTypographyProps={{ component: 'div' }}
                    secondaryTypographyProps={{ component: 'div' }}
                  />
                  <ListItemSecondaryAction>
                    <IconButton edge="end" aria-label="edit" sx={{ mr: 1 }}>
                      <EditIcon />
                    </IconButton>
                    <IconButton edge="end" aria-label="delete">
                      <DeleteIcon />
                    </IconButton>
                  </ListItemSecondaryAction>
                </ListItem>
                <Divider />
              </React.Fragment>
            ))
          )}
        </List>
      </Paper>
    </Box>
  );
};

export default MenuPage;
