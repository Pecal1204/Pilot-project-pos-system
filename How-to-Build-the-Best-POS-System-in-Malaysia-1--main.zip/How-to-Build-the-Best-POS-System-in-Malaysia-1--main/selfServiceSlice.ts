import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { RootState } from '../../store';
import { api } from '../../services/api';

interface SelfServiceConfig {
  enabled: boolean;
  language: string;
  accessibilityMode: boolean;
  highContrastMode: boolean;
  fontSize: 'small' | 'medium' | 'large';
  screenReaderEnabled: boolean;
  touchSensitivity: 'normal' | 'high';
  idleTimeoutSeconds: number;
  requireStaffApproval: boolean;
  paymentMethods: string[];
}

interface SelfServiceState {
  config: SelfServiceConfig;
  currentStep: string;
  sessionId: string | null;
  sessionStartTime: string | null;
  cart: any[];
  isProcessing: boolean;
  error: string | null;
  staffAssistanceRequested: boolean;
  idleWarningActive: boolean;
  lastInteractionTime: string;
}

const initialState: SelfServiceState = {
  config: {
    enabled: true,
    language: 'en',
    accessibilityMode: false,
    highContrastMode: false,
    fontSize: 'medium',
    screenReaderEnabled: false,
    touchSensitivity: 'normal',
    idleTimeoutSeconds: 120,
    requireStaffApproval: true,
    paymentMethods: ['CREDIT_CARD', 'DEBIT_CARD', 'TOUCH_N_GO', 'GRABPAY', 'BOOST', 'DUITNOW_QR']
  },
  currentStep: 'welcome',
  sessionId: null,
  sessionStartTime: null,
  cart: [],
  isProcessing: false,
  error: null,
  staffAssistanceRequested: false,
  idleWarningActive: false,
  lastInteractionTime: new Date().toISOString()
};

export const selfServiceSlice = createSlice({
  name: 'selfService',
  initialState,
  reducers: {
    setConfig: (state, action: PayloadAction<Partial<SelfServiceConfig>>) => {
      state.config = {
        ...state.config,
        ...action.payload
      };
    },
    setLanguage: (state, action: PayloadAction<string>) => {
      state.config.language = action.payload;
    },
    toggleAccessibilityMode: (state) => {
      state.config.accessibilityMode = !state.config.accessibilityMode;
    },
    toggleHighContrastMode: (state) => {
      state.config.highContrastMode = !state.config.highContrastMode;
    },
    setFontSize: (state, action: PayloadAction<'small' | 'medium' | 'large'>) => {
      state.config.fontSize = action.payload;
    },
    toggleScreenReader: (state) => {
      state.config.screenReaderEnabled = !state.config.screenReaderEnabled;
    },
    setCurrentStep: (state, action: PayloadAction<string>) => {
      state.currentStep = action.payload;
      state.lastInteractionTime = new Date().toISOString();
      state.idleWarningActive = false;
    },
    startSession: (state) => {
      state.sessionId = `session-${Date.now()}`;
      state.sessionStartTime = new Date().toISOString();
      state.cart = [];
      state.currentStep = 'menu';
      state.error = null;
      state.staffAssistanceRequested = false;
      state.idleWarningActive = false;
      state.lastInteractionTime = new Date().toISOString();
    },
    endSession: (state) => {
      state.sessionId = null;
      state.sessionStartTime = null;
      state.cart = [];
      state.currentStep = 'welcome';
      state.error = null;
      state.staffAssistanceRequested = false;
      state.idleWarningActive = false;
    },
    addToCart: (state, action: PayloadAction<any>) => {
      state.cart.push(action.payload);
      state.lastInteractionTime = new Date().toISOString();
      state.idleWarningActive = false;
    },
    removeFromCart: (state, action: PayloadAction<string>) => {
      state.cart = state.cart.filter(item => item.id !== action.payload);
      state.lastInteractionTime = new Date().toISOString();
      state.idleWarningActive = false;
    },
    updateCartItem: (state, action: PayloadAction<{ id: string; updates: any }>) => {
      const index = state.cart.findIndex(item => item.id === action.payload.id);
      if (index !== -1) {
        state.cart[index] = {
          ...state.cart[index],
          ...action.payload.updates
        };
      }
      state.lastInteractionTime = new Date().toISOString();
      state.idleWarningActive = false;
    },
    clearCart: (state) => {
      state.cart = [];
      state.lastInteractionTime = new Date().toISOString();
      state.idleWarningActive = false;
    },
    setProcessing: (state, action: PayloadAction<boolean>) => {
      state.isProcessing = action.payload;
    },
    setError: (state, action: PayloadAction<string | null>) => {
      state.error = action.payload;
    },
    requestStaffAssistance: (state) => {
      state.staffAssistanceRequested = true;
      state.lastInteractionTime = new Date().toISOString();
      state.idleWarningActive = false;
    },
    clearStaffAssistanceRequest: (state) => {
      state.staffAssistanceRequested = false;
    },
    setIdleWarningActive: (state, action: PayloadAction<boolean>) => {
      state.idleWarningActive = action.payload;
    },
    updateLastInteractionTime: (state) => {
      state.lastInteractionTime = new Date().toISOString();
      state.idleWarningActive = false;
    }
  }
});

export const {
  setConfig,
  setLanguage,
  toggleAccessibilityMode,
  toggleHighContrastMode,
  setFontSize,
  toggleScreenReader,
  setCurrentStep,
  startSession,
  endSession,
  addToCart,
  removeFromCart,
  updateCartItem,
  clearCart,
  setProcessing,
  setError,
  requestStaffAssistance,
  clearStaffAssistanceRequest,
  setIdleWarningActive,
  updateLastInteractionTime
} = selfServiceSlice.actions;

// Selectors
export const selectSelfServiceConfig = (state: RootState) => state.selfService.config;
export const selectCurrentStep = (state: RootState) => state.selfService.currentStep;
export const selectSessionId = (state: RootState) => state.selfService.sessionId;
export const selectCart = (state: RootState) => state.selfService.cart;
export const selectCartTotal = (state: RootState) => 
  state.selfService.cart.reduce((total, item) => total + (item.price * item.quantity), 0);
export const selectIsProcessing = (state: RootState) => state.selfService.isProcessing;
export const selectError = (state: RootState) => state.selfService.error;
export const selectStaffAssistanceRequested = (state: RootState) => state.selfService.staffAssistanceRequested;
export const selectIdleWarningActive = (state: RootState) => state.selfService.idleWarningActive;
export const selectLastInteractionTime = (state: RootState) => state.selfService.lastInteractionTime;
export const selectLanguage = (state: RootState) => state.selfService.config.language;
export const selectAccessibilityMode = (state: RootState) => state.selfService.config.accessibilityMode;
export const selectHighContrastMode = (state: RootState) => state.selfService.config.highContrastMode;
export const selectFontSize = (state: RootState) => state.selfService.config.fontSize;
export const selectScreenReaderEnabled = (state: RootState) => state.selfService.config.screenReaderEnabled;

export default selfServiceSlice.reducer;
