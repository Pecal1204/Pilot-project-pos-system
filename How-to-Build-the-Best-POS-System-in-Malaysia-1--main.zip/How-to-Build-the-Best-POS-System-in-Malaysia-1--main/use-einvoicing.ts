import { usePOS } from '@/lib/pos-context';
import { processEInvoice } from '@/lib/einvoice';
import { useToast } from '@/hooks/use-toast';

/**
 * Custom hook for e-invoicing operations
 * Provides methods for generating and managing e-invoices
 */
export const useEInvoicing = () => {
  const { orders, generateEInvoice } = usePOS();
  const { toast } = useToast();
  
  /**
   * Generate an e-invoice for a specific order
   * @param orderId The ID of the order to generate an invoice for
   * @returns Promise resolving to the result of the e-invoice generation
   */
  const generateInvoiceForOrder = async (orderId: string) => {
    const order = orders.find(o => o.id === orderId);
    
    if (!order) {
      toast({
        title: "Error",
        description: "Order not found",
        variant: "destructive",
      });
      return { success: false, error: "Order not found" };
    }
    
    try {
      // Get customer info from order
      const customer = {
        name: order.customerName || "Walk-in Customer",
        phone: order.customerPhone,
      };
      
      // Determine payment method from order (in a real implementation)
      const paymentMethod = "card"; // Default for demo
      
      // Process the e-invoice (generate, validate, submit to IRBM, store)
      const result = await processEInvoice(order, customer, paymentMethod);
      
      if (result.success && result.invoice) {
        // Update the POS context with the e-invoice reference
        generateEInvoice(order.id);
        
        toast({
          title: "E-Invoice Generated",
          description: `Successfully generated and submitted to IRBM. Reference: ${result.referenceId}`,
        });
      } else {
        toast({
          title: "E-Invoice Generation Failed",
          description: result.errors ? result.errors.join(", ") : "Unknown error",
          variant: "destructive",
        });
      }
      
      return result;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : "Unknown error";
      
      toast({
        title: "Error",
        description: `Failed to generate e-invoice: ${errorMessage}`,
        variant: "destructive",
      });
      
      return { 
        success: false, 
        error: errorMessage 
      };
    }
  };
  
  /**
   * Download an e-invoice in the specified format
   * @param invoiceNumber The invoice number to download
   * @param format The format to download (XML, JSON, or PDF)
   */
  const downloadInvoice = (invoiceNumber: string, format: 'XML' | 'JSON' | 'PDF') => {
    // In a real implementation, this would fetch and download the file
    // For this demo, we'll just show a toast
    toast({
      title: `${format} Downloaded`,
      description: `E-Invoice ${invoiceNumber} downloaded in ${format} format`,
    });
    
    return { success: true };
  };
  
  /**
   * Get compliance statistics for e-invoicing
   * @returns Object with compliance statistics
   */
  const getComplianceStats = () => {
    // In a real implementation, this would fetch actual statistics
    // For this demo, we'll return mock data
    return {
      generatedToday: 24,
      submittedToIRBM: 24,
      complianceStatus: "Compliant",
      requirements: [
        { name: "UBL 2.1 Standard Implementation", compliant: true },
        { name: "XML/JSON Format Support", compliant: true },
        { name: "MyInvois Portal/API Integration", compliant: true },
        { name: "Real-time Validation", compliant: true },
        { name: "Secure Storage", compliant: true }
      ]
    };
  };
  
  return {
    generateInvoiceForOrder,
    downloadInvoice,
    getComplianceStats
  };
};
