import { useToast } from "@/components/ui/use-toast";

export function useCustomToast() {
  const { toast } = useToast();
  
  return {
    toast
  };
}
