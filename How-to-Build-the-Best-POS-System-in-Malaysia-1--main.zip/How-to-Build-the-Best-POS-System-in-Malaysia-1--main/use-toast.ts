import { createContext, useContext, type ReactNode } from "react"
import { toast } from "@/components/ui/toast"

type ToastProps = {
  title?: string
  description?: string
  variant?: "default" | "destructive"
}

const ToastContext = createContext<{
  toast: (props: ToastProps) => void
} | null>(null)

export function ToastProvider({
  children,
}: {
  children: ReactNode
}) {
  return (
    <ToastContext.Provider
      value={{
        toast: ({ title, description, variant = "default" }) => {
          toast({
            title,
            description,
            variant,
          })
        },
      }}
    >
      {children}
    </ToastContext.Provider>
  )
}

export function useToast() {
  const context = useContext(ToastContext)
  if (!context) {
    throw new Error("useToast must be used within a ToastProvider")
  }
  return context
}
