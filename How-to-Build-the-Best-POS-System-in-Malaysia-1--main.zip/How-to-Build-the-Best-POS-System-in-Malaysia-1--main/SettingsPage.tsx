import React from 'react';
import { Box, Typography, Paper, Grid, TextField, Button, FormControl, InputLabel, Select, MenuItem } from '@mui/material';
import { styled } from '@mui/material/styles';

const SettingsPage: React.FC = () => {
  return (
    <Box sx={{ flexGrow: 1 }}>
      <Typography variant="h4" gutterBottom>
        Settings
      </Typography>
      
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              Business Information
            </Typography>
            
            <TextField
              fullWidth
              margin="normal"
              label="Business Name"
              defaultValue="MalaysiaDish Restaurant"
            />
            
            <TextField
              fullWidth
              margin="normal"
              label="Tax ID"
              defaultValue="MY12345678"
            />
            
            <TextField
              fullWidth
              margin="normal"
              label="Address"
              defaultValue="123 Jalan Sultan, 50000 Kuala Lumpur"
              multiline
              rows={2}
            />
            
            <TextField
              fullWidth
              margin="normal"
              label="Phone Number"
              defaultValue="+60 3 1234 5678"
            />
            
            <TextField
              fullWidth
              margin="normal"
              label="Email"
              defaultValue="info@malaysiadish.com"
            />
            
            <Button variant="contained" sx={{ mt: 2 }}>
              Save Changes
            </Button>
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 3 }}>
            <Typography variant="h6" gutterBottom>
              E-Invoicing Settings
            </Typography>
            
            <FormControl fullWidth margin="normal">
              <InputLabel>E-Invoice Format</InputLabel>
              <Select
                defaultValue="XML"
                label="E-Invoice Format"
              >
                <MenuItem value="XML">XML (UBL 2.1)</MenuItem>
                <MenuItem value="JSON">JSON</MenuItem>
              </Select>
            </FormControl>
            
            <TextField
              fullWidth
              margin="normal"
              label="MyInvois API Key"
              defaultValue="••••••••••••••••"
              type="password"
            />
            
            <FormControl fullWidth margin="normal">
              <InputLabel>Submission Mode</InputLabel>
              <Select
                defaultValue="API"
                label="Submission Mode"
              >
                <MenuItem value="API">API (Automatic)</MenuItem>
                <MenuItem value="PORTAL">Portal (Manual)</MenuItem>
              </Select>
            </FormControl>
            
            <Button variant="contained" sx={{ mt: 2 }}>
              Test Connection
            </Button>
          </Paper>
          
          <Paper sx={{ p: 3, mt: 3 }}>
            <Typography variant="h6" gutterBottom>
              Tax Settings
            </Typography>
            
            <TextField
              fullWidth
              margin="normal"
              label="SST Rate (%)"
              defaultValue="6"
              type="number"
            />
            
            <TextField
              fullWidth
              margin="normal"
              label="Service Charge (%)"
              defaultValue="10"
              type="number"
            />
            
            <Button variant="contained" sx={{ mt: 2 }}>
              Save Changes
            </Button>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default SettingsPage;
