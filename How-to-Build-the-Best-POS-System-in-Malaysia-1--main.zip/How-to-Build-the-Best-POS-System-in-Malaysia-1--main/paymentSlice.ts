import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { PaymentMethod, BiometricAuthMethod } from '@malaysiadish-pos/common';
import { RootState } from '../../store';
import { api } from '../../services/api';

interface PaymentState {
  activePaymentMethod: PaymentMethod | null;
  supportedPaymentMethods: PaymentMethod[];
  biometricEnabled: boolean;
  supportedBiometricMethods: BiometricAuthMethod[];
  preferredBiometricMethod: BiometricAuthMethod | null;
  isPaymentProcessing: boolean;
  lastPaymentError: string | null;
  paymentDeviceStatus: 'connected' | 'disconnected' | 'error';
  paymentDeviceErrorMessage: string | null;
}

const initialState: PaymentState = {
  activePaymentMethod: null,
  supportedPaymentMethods: [
    PaymentMethod.CASH,
    PaymentMethod.CREDIT_CARD,
    PaymentMethod.DEBIT_CARD,
    PaymentMethod.TOUCH_N_GO,
    PaymentMethod.GRABPAY,
    PaymentMethod.BOOST,
    PaymentMethod.SHOPEEPAY,
    PaymentMethod.DUITNOW_QR,
    PaymentMethod.MAYBANK_QR,
    PaymentMethod.ALIPAY,
    PaymentMethod.WECHAT_PAY
  ],
  biometricEnabled: false,
  supportedBiometricMethods: [
    BiometricAuthMethod.FINGERPRINT,
    BiometricAuthMethod.FACIAL_RECOGNITION
  ],
  preferredBiometricMethod: null,
  isPaymentProcessing: false,
  lastPaymentError: null,
  paymentDeviceStatus: 'disconnected',
  paymentDeviceErrorMessage: null
};

export const paymentSlice = createSlice({
  name: 'payment',
  initialState,
  reducers: {
    setActivePaymentMethod: (state, action: PayloadAction<PaymentMethod | null>) => {
      state.activePaymentMethod = action.payload;
    },
    setSupportedPaymentMethods: (state, action: PayloadAction<PaymentMethod[]>) => {
      state.supportedPaymentMethods = action.payload;
    },
    setBiometricEnabled: (state, action: PayloadAction<boolean>) => {
      state.biometricEnabled = action.payload;
    },
    setPreferredBiometricMethod: (state, action: PayloadAction<BiometricAuthMethod | null>) => {
      state.preferredBiometricMethod = action.payload;
    },
    setPaymentProcessing: (state, action: PayloadAction<boolean>) => {
      state.isPaymentProcessing = action.payload;
    },
    setLastPaymentError: (state, action: PayloadAction<string | null>) => {
      state.lastPaymentError = action.payload;
    },
    setPaymentDeviceStatus: (state, action: PayloadAction<'connected' | 'disconnected' | 'error'>) => {
      state.paymentDeviceStatus = action.payload;
    },
    setPaymentDeviceErrorMessage: (state, action: PayloadAction<string | null>) => {
      state.paymentDeviceErrorMessage = action.payload;
    },
    resetPaymentState: (state) => {
      state.activePaymentMethod = null;
      state.isPaymentProcessing = false;
      state.lastPaymentError = null;
    }
  },
  extraReducers: (builder) => {
    builder
      .addMatcher(
        api.endpoints.processPayment?.matchPending,
        (state) => {
          state.isPaymentProcessing = true;
          state.lastPaymentError = null;
        }
      )
      .addMatcher(
        api.endpoints.processPayment?.matchFulfilled,
        (state) => {
          state.isPaymentProcessing = false;
          state.lastPaymentError = null;
        }
      )
      .addMatcher(
        api.endpoints.processPayment?.matchRejected,
        (state, { error }) => {
          state.isPaymentProcessing = false;
          state.lastPaymentError = error.message || 'Payment processing failed';
        }
      );
  }
});

export const {
  setActivePaymentMethod,
  setSupportedPaymentMethods,
  setBiometricEnabled,
  setPreferredBiometricMethod,
  setPaymentProcessing,
  setLastPaymentError,
  setPaymentDeviceStatus,
  setPaymentDeviceErrorMessage,
  resetPaymentState
} = paymentSlice.actions;

// Selectors
export const selectActivePaymentMethod = (state: RootState) => state.payment.activePaymentMethod;
export const selectSupportedPaymentMethods = (state: RootState) => state.payment.supportedPaymentMethods;
export const selectBiometricEnabled = (state: RootState) => state.payment.biometricEnabled;
export const selectSupportedBiometricMethods = (state: RootState) => state.payment.supportedBiometricMethods;
export const selectPreferredBiometricMethod = (state: RootState) => state.payment.preferredBiometricMethod;
export const selectIsPaymentProcessing = (state: RootState) => state.payment.isPaymentProcessing;
export const selectLastPaymentError = (state: RootState) => state.payment.lastPaymentError;
export const selectPaymentDeviceStatus = (state: RootState) => state.payment.paymentDeviceStatus;
export const selectPaymentDeviceErrorMessage = (state: RootState) => state.payment.paymentDeviceErrorMessage;

export default paymentSlice.reducer;
