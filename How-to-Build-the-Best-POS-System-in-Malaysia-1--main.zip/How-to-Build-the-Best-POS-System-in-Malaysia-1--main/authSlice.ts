import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { User, UserRole } from '@malaysiadish-pos/common';
import { RootState } from '../../store';
import { api } from '../../services/api';

interface AuthState {
  user: User | null;
  token: string | null;
  isAuthenticated: boolean;
}

// Initialize state from localStorage if available
const initialState: AuthState = {
  user: null,
  token: localStorage.getItem('token'),
  isAuthenticated: !!localStorage.getItem('token'),
};

export const authSlice = createSlice({
  name: 'auth',
  initialState,
  reducers: {
    setCredentials: (
      state,
      action: PayloadAction<{ user: User; token: string }>
    ) => {
      const { user, token } = action.payload;
      state.user = user;
      state.token = token;
      state.isAuthenticated = true;
      localStorage.setItem('token', token);
    },
    logout: (state) => {
      state.user = null;
      state.token = null;
      state.isAuthenticated = false;
      localStorage.removeItem('token');
    },
  },
  extraReducers: (builder) => {
    builder
      .addMatcher(
        api.endpoints.login.matchFulfilled,
        (state, { payload }) => {
          if (payload.data) {
            state.user = payload.data.user;
            state.token = payload.data.token;
            state.isAuthenticated = true;
            localStorage.setItem('token', payload.data.token);
          }
        }
      )
      .addMatcher(
        api.endpoints.getCurrentUser.matchFulfilled,
        (state, { payload }) => {
          if (payload.data) {
            state.user = payload.data;
            state.isAuthenticated = true;
          }
        }
      )
      .addMatcher(
        api.endpoints.getCurrentUser.matchRejected,
        (state) => {
          // If getting current user fails, log out
          state.user = null;
          state.token = null;
          state.isAuthenticated = false;
          localStorage.removeItem('token');
        }
      );
  },
});

export const { setCredentials, logout } = authSlice.actions;

// Selectors
export const selectCurrentUser = (state: RootState) => state.auth.user;
export const selectIsAuthenticated = (state: RootState) => state.auth.isAuthenticated;
export const selectUserRole = (state: RootState) => state.auth.user?.role;
export const selectIsAdmin = (state: RootState) => 
  state.auth.user?.role === UserRole.ADMIN || state.auth.user?.role === UserRole.MANAGER;

export default authSlice.reducer;
