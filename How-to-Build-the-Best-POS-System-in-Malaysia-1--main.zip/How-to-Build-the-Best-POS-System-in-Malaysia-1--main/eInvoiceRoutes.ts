import express from 'express';
import { v4 as uuidv4 } from 'uuid';
import { EInvoice, InvoiceStatus } from '@malaysiadish-pos/common';
import { eInvoiceService } from '../services/eInvoiceService';
import { orderService } from '../services/orderService';

const router = express.Router();

// Get all e-invoices with optional filtering
router.get('/', async (req, res, next) => {
  try {
    const { status, customerId, startDate, endDate, page, limit } = req.query;
    
    const filters: any = {};
    if (status) filters.status = status;
    if (customerId) filters['customerInfo.taxId'] = customerId;
    
    const dateRange = startDate && endDate ? {
      startDate: startDate as string,
      endDate: endDate as string
    } : undefined;
    
    const pagination = page && limit ? {
      page: parseInt(page as string),
      limit: parseInt(limit as string)
    } : undefined;
    
    const invoices = await eInvoiceService.getInvoices(filters, dateRange, pagination);
    res.json({
      success: true,
      data: invoices.data,
      meta: invoices.meta
    });
  } catch (error) {
    next(error);
  }
});

// Get e-invoice by ID
router.get('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const invoice = await eInvoiceService.getInvoiceById(id);
    
    if (!invoice) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'INVOICE_NOT_FOUND',
          message: `E-Invoice with ID ${id} not found`
        }
      });
    }
    
    res.json({
      success: true,
      data: invoice
    });
  } catch (error) {
    next(error);
  }
});

// Generate e-invoice from order
router.post('/generate/:orderId', async (req, res, next) => {
  try {
    const { orderId } = req.params;
    const { customerInfo } = req.body;
    
    // Get order details
    const order = await orderService.getOrderById(orderId);
    
    if (!order) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'ORDER_NOT_FOUND',
          message: `Order with ID ${orderId} not found`
        }
      });
    }
    
    // Generate e-invoice
    const invoice = await eInvoiceService.generateInvoice(order, customerInfo);
    
    res.status(201).json({
      success: true,
      data: invoice
    });
  } catch (error) {
    next(error);
  }
});

// Submit e-invoice to IRBM
router.post('/:id/submit', async (req, res, next) => {
  try {
    const { id } = req.params;
    
    // Get invoice
    const invoice = await eInvoiceService.getInvoiceById(id);
    
    if (!invoice) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'INVOICE_NOT_FOUND',
          message: `E-Invoice with ID ${id} not found`
        }
      });
    }
    
    // Check if invoice is in draft or rejected status
    if (invoice.status !== InvoiceStatus.DRAFT && invoice.status !== InvoiceStatus.REJECTED) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_INVOICE_STATUS',
          message: `E-Invoice must be in DRAFT or REJECTED status to submit, current status: ${invoice.status}`
        }
      });
    }
    
    // Submit to IRBM
    const submittedInvoice = await eInvoiceService.submitInvoice(id);
    
    res.json({
      success: true,
      data: submittedInvoice
    });
  } catch (error) {
    next(error);
  }
});

// Update e-invoice status
router.patch('/:id/status', async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    
    if (!status || !Object.values(InvoiceStatus).includes(status as InvoiceStatus)) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_STATUS',
          message: 'Invalid invoice status'
        }
      });
    }
    
    const updatedInvoice = await eInvoiceService.updateInvoiceStatus(id, status as InvoiceStatus);
    
    if (!updatedInvoice) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'INVOICE_NOT_FOUND',
          message: `E-Invoice with ID ${id} not found`
        }
      });
    }
    
    res.json({
      success: true,
      data: updatedInvoice
    });
  } catch (error) {
    next(error);
  }
});

// Cancel e-invoice
router.post('/:id/cancel', async (req, res, next) => {
  try {
    const { id } = req.params;
    const { reason } = req.body;
    
    if (!reason) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'MISSING_REASON',
          message: 'Cancellation reason is required'
        }
      });
    }
    
    const cancelledInvoice = await eInvoiceService.cancelInvoice(id, reason);
    
    if (!cancelledInvoice) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'INVOICE_NOT_FOUND',
          message: `E-Invoice with ID ${id} not found`
        }
      });
    }
    
    res.json({
      success: true,
      data: cancelledInvoice
    });
  } catch (error) {
    next(error);
  }
});

// Get e-invoice in specific format (XML/JSON)
router.get('/:id/format/:format', async (req, res, next) => {
  try {
    const { id, format } = req.params;
    
    if (format !== 'xml' && format !== 'json') {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_FORMAT',
          message: 'Format must be either xml or json'
        }
      });
    }
    
    const invoice = await eInvoiceService.getInvoiceById(id);
    
    if (!invoice) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'INVOICE_NOT_FOUND',
          message: `E-Invoice with ID ${id} not found`
        }
      });
    }
    
    const formattedInvoice = await eInvoiceService.formatInvoice(invoice, format);
    
    if (format === 'xml') {
      res.set('Content-Type', 'application/xml');
      return res.send(formattedInvoice);
    }
    
    res.json(JSON.parse(formattedInvoice));
  } catch (error) {
    next(error);
  }
});

export const eInvoiceRoutes = router;
