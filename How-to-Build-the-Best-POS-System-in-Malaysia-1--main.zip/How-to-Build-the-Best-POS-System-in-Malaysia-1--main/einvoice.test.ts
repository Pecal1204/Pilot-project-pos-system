import { describe, test, expect, vi, beforeEach } from 'vitest';

/**
 * E-Invoicing Unit Tests
 * Tests the core functionality of the e-invoicing module
 */

import { 
  generateEInvoice, 
  convertToXML, 
  convertToJSON, 
  validateEInvoice,
  submitToIRBM,
  storeEInvoice,
  processEInvoice
} from '@/lib/einvoice';

// Sample order data for testing
const sampleOrder = {
  id: 'order123',
  items: [
    {
      id: 'item1',
      name: 'Nasi Lemak Special',
      description: 'Fragrant coconut rice with sambal, fried chicken, egg, cucumber, and anchovies',
      price: 15.90,
      quantity: 2
    },
    {
      id: 'item2',
      name: 'Teh Tarik',
      description: 'Pulled milk tea, a Malaysian favorite',
      price: 4.50,
      quantity: 3
    }
  ],
  total: 45.30,
  status: 'completed',
  timestamp: new Date().toISOString(),
  customerName: 'Test Customer',
  customerPhone: '+60123456789'
};

// Sample customer data for testing
const sampleCustomer = {
  name: 'Test Customer',
  phone: '+60123456789',
  email: 'test@example.com'
};

describe('E-Invoice Generation', () => {
  test('Should generate valid e-invoice from order data', () => {
    const invoice = generateEInvoice(sampleOrder, sampleCustomer, 'card');
    
    // Check basic invoice properties
    expect(invoice).toBeDefined();
    expect(invoice.invoiceNumber).toContain('INV-123');
    expect(invoice.documentCurrencyCode).toBe('MYR');
    
    // Check supplier information
    expect(invoice.accountingSupplierParty.registrationName).toBe('MalaysiaDish Restaurant Sdn Bhd');
    expect(invoice.accountingSupplierParty.taxRegistrationID).toBe('SST-123456789');
    
    // Check customer information
    expect(invoice.accountingCustomerParty.registrationName).toBe(sampleCustomer.name);
    if (invoice.accountingCustomerParty.contact) {
      expect(invoice.accountingCustomerParty.contact.telephone).toBe(sampleCustomer.phone);
    }
    
    // Check line items
    expect(invoice.invoiceLines.length).toBe(2);
    expect(invoice.invoiceLines[0].item.name).toBe('Nasi Lemak Special');
    expect(invoice.invoiceLines[0].invoicedQuantity.value).toBe(2);
    expect(invoice.invoiceLines[0].price.priceAmount).toBe(15.90);
    
    // Check totals
    const subtotal = 15.90 * 2 + 4.50 * 3;
    const tax = subtotal * 0.06;
    const total = subtotal + tax;
    
    expect(invoice.legalMonetaryTotal.lineExtensionAmount).toBeCloseTo(subtotal, 2);
    expect(invoice.taxTotal.taxAmount).toBeCloseTo(tax, 2);
    expect(invoice.legalMonetaryTotal.payableAmount).toBeCloseTo(total, 2);
  });
  
  test('Should handle missing customer information', () => {
    const invoice = generateEInvoice(sampleOrder, { name: 'Walk-in Customer' }, 'cash');
    
    expect(invoice).toBeDefined();
    expect(invoice.accountingCustomerParty.registrationName).toBe('Walk-in Customer');
    if (invoice.accountingCustomerParty.contact) {
      expect(invoice.accountingCustomerParty.contact.telephone).toBeUndefined();
      expect(invoice.accountingCustomerParty.contact.electronicMail).toBeUndefined();
    }
  });
  
  test('Should map payment methods correctly', () => {
    const cardInvoice = generateEInvoice(sampleOrder, sampleCustomer, 'card');
    const cashInvoice = generateEInvoice(sampleOrder, sampleCustomer, 'cash');
    const ewalletInvoice = generateEInvoice(sampleOrder, sampleCustomer, 'ewallet');
    
    expect(cardInvoice.paymentMeans.paymentMeansCode).toBe('48'); // Bank card
    expect(cashInvoice.paymentMeans.paymentMeansCode).toBe('10'); // Cash
    expect(ewalletInvoice.paymentMeans.paymentMeansCode).toBe('97'); // Clearing between partners
  });
});

describe('XML/JSON Conversion', () => {
  test('Should convert e-invoice to valid XML', () => {
    const invoice = generateEInvoice(sampleOrder, sampleCustomer, 'card');
    const xml = convertToXML(invoice);
    
    expect(xml).toBeDefined();
    expect(xml).toContain('<?xml version="1.0" encoding="UTF-8"?>');
    expect(xml).toContain('<Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"');
    expect(xml).toContain(`<cbc:ID>${invoice.invoiceNumber}</cbc:ID>`);
    expect(xml).toContain('<cbc:UBLVersionID>2.1</cbc:UBLVersionID>');
    
    // Check supplier information in XML
    expect(xml).toContain(invoice.accountingSupplierParty.registrationName);
    expect(xml).toContain(invoice.accountingSupplierParty.taxRegistrationID);
    
    // Check line items in XML
    expect(xml).toContain(invoice.invoiceLines[0].item.name);
    expect(xml).toContain(invoice.invoiceLines[1].item.name);
    
    // Check totals in XML
    expect(xml).toContain(`<cbc:PayableAmount currencyID="MYR">${invoice.legalMonetaryTotal.payableAmount.toFixed(2)}</cbc:PayableAmount>`);
  });
  
  test('Should convert e-invoice to valid JSON', () => {
    const invoice = generateEInvoice(sampleOrder, sampleCustomer, 'card');
    const json = convertToJSON(invoice);
    
    expect(json).toBeDefined();
    
    const parsedJson = JSON.parse(json);
    expect(parsedJson.invoiceNumber).toBe(invoice.invoiceNumber);
    expect(parsedJson.documentCurrencyCode).toBe('MYR');
    expect(parsedJson.accountingSupplierParty.registrationName).toBe('MalaysiaDish Restaurant Sdn Bhd');
    expect(parsedJson.invoiceLines.length).toBe(2);
    expect(parsedJson.legalMonetaryTotal.payableAmount).toBeCloseTo(invoice.legalMonetaryTotal.payableAmount, 2);
  });
});

describe('E-Invoice Validation', () => {
  test('Should validate correct e-invoice', () => {
    const invoice = generateEInvoice(sampleOrder, sampleCustomer, 'card');
    const validation = validateEInvoice(invoice);
    
    expect(validation.valid).toBe(true);
    expect(validation.errors.length).toBe(0);
  });
  
  test('Should detect missing required fields', () => {
    const invoice = generateEInvoice(sampleOrder, sampleCustomer, 'card');
    
    // Create invalid invoice by removing required fields
    const invalidInvoice = { ...invoice };
    invalidInvoice.invoiceNumber = '';
    
    const validation = validateEInvoice(invalidInvoice);
    
    expect(validation.valid).toBe(false);
    expect(validation.errors.length).toBeGreaterThan(0);
    expect(validation.errors[0]).toContain('Invoice number is required');
  });
  
  test('Should validate totals calculation', () => {
    const invoice = generateEInvoice(sampleOrder, sampleCustomer, 'card');
    
    // Create invalid invoice with incorrect totals
    const invalidInvoice = { ...invoice };
    invalidInvoice.legalMonetaryTotal.lineExtensionAmount = 999.99;
    
    const validation = validateEInvoice(invalidInvoice);
    
    expect(validation.valid).toBe(false);
    expect(validation.errors.length).toBeGreaterThan(0);
    expect(validation.errors[0]).toContain('Line extension amount does not match');
  });
});

describe('IRBM API Integration', () => {
  // Mock the async function
  beforeEach(() => {
    vi.mock('@/lib/einvoice', async () => {
      const actual = await vi.importActual('@/lib/einvoice');
      return {
        ...actual as object,
        submitToIRBM: vi.fn().mockResolvedValue({
          success: true,
          referenceId: 'IRBM-12345678'
        })
      };
    });
  });

  test('Should successfully submit valid invoice to IRBM', async () => {
    const invoice = generateEInvoice(sampleOrder, sampleCustomer, 'card');
    const result = await submitToIRBM(invoice);
    
    expect(result.success).toBe(true);
    expect(result.referenceId).toBeDefined();
    expect(result.referenceId).toContain('IRBM-');
  });
});

describe('E-Invoice Storage', () => {
  test('Should store invoice successfully', () => {
    const invoice = generateEInvoice(sampleOrder, sampleCustomer, 'card');
    const result = storeEInvoice(invoice);
    
    expect(result.success).toBe(true);
    expect(result.path).toBeDefined();
    expect(result.path).toContain(invoice.invoiceNumber);
  });
  
  test('Should store in different formats', () => {
    const invoice = generateEInvoice(sampleOrder, sampleCustomer, 'card');
    
    const xmlResult = storeEInvoice(invoice, 'XML');
    const jsonResult = storeEInvoice(invoice, 'JSON');
    
    expect(xmlResult.success).toBe(true);
    expect(jsonResult.success).toBe(true);
    expect(xmlResult.path).toContain('.xml');
    expect(jsonResult.path).toContain('.json');
  });
});

describe('End-to-End Processing', () => {
  // Mock the async function
  beforeEach(() => {
    vi.mock('@/lib/einvoice', async () => {
      const actual = await vi.importActual('@/lib/einvoice');
      return {
        ...actual as object,
        processEInvoice: vi.fn().mockImplementation(async (order, customer, paymentMethod) => {
          if (!order.items || order.items.length === 0) {
            return {
              success: false,
              errors: ['At least one invoice line is required']
            };
          }
          
          const invoice = generateEInvoice(order, customer, paymentMethod);
          return {
            success: true,
            invoice,
            referenceId: 'IRBM-12345678'
          };
        })
      };
    });
  });

  test('Should process complete e-invoice workflow', async () => {
    const result = await processEInvoice(sampleOrder, sampleCustomer, 'card');
    
    expect(result.success).toBe(true);
    expect(result.invoice).toBeDefined();
    expect(result.referenceId).toBeDefined();
  });
  
  test('Should handle errors in processing workflow', async () => {
    // Create invalid order with no items
    const invalidOrder = { ...sampleOrder, items: [] };
    
    const result = await processEInvoice(invalidOrder, sampleCustomer, 'card');
    
    expect(result.success).toBe(false);
    if (result.errors) {
      expect(result.errors.length).toBeGreaterThan(0);
    }
  });
});
