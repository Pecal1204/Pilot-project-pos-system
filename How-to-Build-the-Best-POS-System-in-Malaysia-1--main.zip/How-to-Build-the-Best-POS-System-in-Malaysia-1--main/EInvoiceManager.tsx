import { useState } from 'react';
import { usePOS } from '@/lib/pos-context';
import { processEInvoice, EInvoice } from '@/lib/einvoice';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { useToast } from '@/hooks/use-toast';

interface EInvoiceManagerProps {
  orderId?: string;
}

export function EInvoiceManager({ orderId }: EInvoiceManagerProps) {
  const { orders, generateEInvoice } = usePOS();
  const { toast } = useToast();
  const [processing, setProcessing] = useState(false);
  const [currentInvoice, setCurrentInvoice] = useState<EInvoice | null>(null);
  const [referenceId, setReferenceId] = useState<string | null>(null);
  
  // Find the order if orderId is provided
  const order = orderId ? orders.find(o => o.id === orderId) : null;
  
  const handleGenerateInvoice = async () => {
    if (!order) {
      toast({
        title: "Error",
        description: "No order selected for e-invoice generation",
        variant: "destructive",
      });
      return;
    }
    
    setProcessing(true);
    
    try {
      // Get customer info from order
      const customer = {
        name: order.customerName || "Walk-in Customer",
        phone: order.customerPhone,
      };
      
      // Process the e-invoice (generate, validate, submit to IRBM, store)
      const result = await processEInvoice(
        order,
        customer,
        "card" // Default payment method, should be retrieved from actual order
      );
      
      if (result.success && result.invoice) {
        setCurrentInvoice(result.invoice);
        setReferenceId(result.referenceId || null);
        
        // Update the POS context with the e-invoice reference
        generateEInvoice(order.id);
        
        toast({
          title: "E-Invoice Generated",
          description: `Successfully generated and submitted to IRBM. Reference: ${result.referenceId}`,
        });
      } else {
        toast({
          title: "E-Invoice Generation Failed",
          description: result.errors ? result.errors.join(", ") : "Unknown error",
          variant: "destructive",
        });
      }
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to generate e-invoice",
        variant: "destructive",
      });
    } finally {
      setProcessing(false);
    }
  };
  
  const handleDownloadInvoice = (format: 'XML' | 'JSON' | 'PDF') => {
    if (!currentInvoice) return;
    
    // In a real implementation, this would generate and download the file
    // For this demo, we'll just show a toast
    toast({
      title: `${format} Downloaded`,
      description: `E-Invoice ${currentInvoice.invoiceNumber} downloaded in ${format} format`,
    });
  };
  
  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle>E-Invoice Management</CardTitle>
        <CardDescription>
          Generate and manage IRBM-compliant e-invoices (UBL 2.1)
        </CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        {order ? (
          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="font-medium">Order #{order.id.replace('order', '')}</h3>
                <p className="text-sm text-muted-foreground">
                  {new Date(order.timestamp).toLocaleString()}
                </p>
              </div>
              <Badge variant={currentInvoice ? "success" : "outline"}>
                {currentInvoice ? "E-Invoice Generated" : "Pending"}
              </Badge>
            </div>
            
            <Separator />
            
            <div className="space-y-2">
              <h4 className="font-medium">Order Details</h4>
              <div className="space-y-1">
                {order.items.map((item: any) => (
                  <div key={item.id} className="flex justify-between text-sm">
                    <span>{item.name} × {item.quantity}</span>
                    <span>RM {(item.price * item.quantity).toFixed(2)}</span>
                  </div>
                ))}
              </div>
              
              <div className="pt-2">
                <div className="flex justify-between font-medium">
                  <span>Total</span>
                  <span>RM {order.total.toFixed(2)}</span>
                </div>
              </div>
            </div>
            
            {currentInvoice && (
              <>
                <Separator />
                
                <div className="space-y-2">
                  <h4 className="font-medium">E-Invoice Information</h4>
                  <div className="grid grid-cols-2 gap-2 text-sm">
                    <div>
                      <p className="text-muted-foreground">Invoice Number</p>
                      <p>{currentInvoice.invoiceNumber}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Issue Date</p>
                      <p>{currentInvoice.issueDate}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">IRBM Reference</p>
                      <p>{referenceId || "N/A"}</p>
                    </div>
                    <div>
                      <p className="text-muted-foreground">Status</p>
                      <Badge variant="success">Submitted to IRBM</Badge>
                    </div>
                  </div>
                </div>
              </>
            )}
          </div>
        ) : (
          <div className="text-center py-6">
            <p className="text-muted-foreground">No order selected</p>
            <p className="text-sm">Select an order to generate an e-invoice</p>
          </div>
        )}
      </CardContent>
      
      <CardFooter className="flex justify-between">
        {order && !currentInvoice ? (
          <Button 
            onClick={handleGenerateInvoice} 
            disabled={processing}
            className="w-full"
          >
            {processing ? "Processing..." : "Generate E-Invoice"}
          </Button>
        ) : currentInvoice ? (
          <div className="flex gap-2 w-full">
            <Button 
              variant="outline" 
              onClick={() => handleDownloadInvoice('XML')}
              className="flex-1"
            >
              Download XML
            </Button>
            <Button 
              variant="outline" 
              onClick={() => handleDownloadInvoice('JSON')}
              className="flex-1"
            >
              Download JSON
            </Button>
            <Button 
              onClick={() => handleDownloadInvoice('PDF')}
              className="flex-1"
            >
              Download PDF
            </Button>
          </div>
        ) : (
          <Button disabled className="w-full">Generate E-Invoice</Button>
        )}
      </CardFooter>
    </Card>
  );
}
