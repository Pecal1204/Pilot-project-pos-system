import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Table, TableStatus } from '@malaysiadish-pos/common';
import { RootState } from '../../store';
import { api } from '../../services/api';

interface TableState {
  selectedTable: Table | null;
  tableLayout: {
    sections: string[];
    selectedSection: string;
  };
}

const initialState: TableState = {
  selectedTable: null,
  tableLayout: {
    sections: ['Main', 'Outdoor', 'Private', 'Bar'],
    selectedSection: 'Main',
  },
};

export const tableSlice = createSlice({
  name: 'table',
  initialState,
  reducers: {
    setSelectedTable: (state, action: PayloadAction<Table | null>) => {
      state.selectedTable = action.payload;
    },
    setSelectedSection: (state, action: PayloadAction<string>) => {
      state.tableLayout.selectedSection = action.payload;
    },
  },
  extraReducers: (builder) => {
    builder
      .addMatcher(
        api.endpoints.getTableById.matchFulfilled,
        (state, { payload }) => {
          if (payload.data) {
            state.selectedTable = payload.data;
          }
        }
      )
      .addMatcher(
        api.endpoints.updateTableStatus.matchFulfilled,
        (state, { payload }) => {
          if (payload.data && state.selectedTable && state.selectedTable.id === payload.data.id) {
            state.selectedTable = payload.data;
          }
        }
      );
  },
});

export const { setSelectedTable, setSelectedSection } = tableSlice.actions;

// Selectors
export const selectSelectedTable = (state: RootState) => state.tables.selectedTable;
export const selectTableSections = (state: RootState) => state.tables.tableLayout.sections;
export const selectSelectedSection = (state: RootState) => state.tables.tableLayout.selectedSection;

export default tableSlice.reducer;
