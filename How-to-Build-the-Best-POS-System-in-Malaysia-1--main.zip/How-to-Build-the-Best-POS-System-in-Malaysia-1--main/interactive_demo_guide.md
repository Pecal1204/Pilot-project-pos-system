# MalaysiaDish POS: Interactive Demo Guide

## 1. Introduction

This document provides a guide to the interactive demo of MalaysiaDish POS, showcasing the system's key features and capabilities. The demo is designed to illustrate how the system would function in a real-world F&B environment, highlighting its advanced features, user-friendly interfaces, and compliance with Malaysian regulations.

## 2. Demo Setup

### 2.1 Environment Requirements

To run the interactive demo, you will need:

- Modern web browser (Chrome, Firefox, Safari, or Edge)
- Internet connection
- Device with touchscreen capability (recommended for optimal experience)

### 2.2 Demo Access

The demo can be accessed through:

- **Web URL**: https://demo.malaysiadishpos.com
- **Demo Credentials**:
  - Restaurant Manager: Username: `manager` / Password: `demo2025`
  - Server/Cashier: Username: `server` / Password: `demo2025`
  - Kitchen Staff: Username: `kitchen` / Password: `demo2025`
  - Customer View: No login required (access via specific demo paths)

## 3. Demo Scenarios

The interactive demo includes several guided scenarios that showcase different aspects of the system:

### 3.1 Scenario 1: Dine-In Order Processing

This scenario demonstrates the complete flow of a dine-in order:

1. **Table Assignment**: Select an available table
2. **Order Entry**: Add items to the order with customizations
3. **Kitchen Display**: View the order on the kitchen display system
4. **Order Modification**: Add additional items to the existing order
5. **Payment Processing**: Process payment with various methods
6. **E-Invoice Generation**: Generate and view the IRBM-compliant e-invoice
7. **WhatsApp Receipt**: Send digital receipt via WhatsApp

### 3.2 Scenario 2: Self-Service Kiosk Experience

This scenario showcases the customer-facing self-service capabilities:

1. **Kiosk Interface**: Navigate the intuitive self-service menu
2. **Personalization**: View AI-powered recommendations
3. **Multilingual Support**: Switch between languages (Bahasa Malaysia, English, Chinese, Tamil)
4. **Accessibility Features**: Demonstrate accessibility options
5. **Order Customization**: Modify items and add special requests
6. **Payment**: Complete payment with contactless options
7. **Order Tracking**: Receive order status updates

### 3.3 Scenario 3: Omnichannel Order Management

This scenario demonstrates the seamless integration across channels:

1. **Online Order**: Place an order through the web ordering platform
2. **Order Synchronization**: See the order appear in the central system
3. **Inventory Update**: Observe real-time inventory adjustments
4. **Kitchen Routing**: Follow the order through preparation stages
5. **Status Updates**: Receive automated notifications about order status
6. **Pickup/Delivery Management**: Process order fulfillment
7. **Cross-Channel Reporting**: View unified reporting across channels

### 3.4 Scenario 4: AI and Analytics Features

This scenario highlights the system's advanced AI capabilities:

1. **Customer Recognition**: Identify returning customer and preferences
2. **Predictive Inventory**: View AI-powered inventory forecasts
3. **Smart Upselling**: Experience personalized recommendation engine
4. **Loyalty Program**: Interact with the AI-enhanced loyalty system
5. **Performance Dashboard**: Explore real-time business analytics
6. **Sentiment Analysis**: Review customer feedback analysis
7. **Operational Optimization**: See AI-suggested operational improvements

## 4. Key Feature Demonstrations

### 4.1 E-Invoicing Compliance

Demonstration of the system's compliance with IRBM e-invoicing requirements:

1. **Invoice Generation**: Create UBL 2.1 compliant e-invoices
2. **Format Options**: View XML and JSON format options
3. **Digital Signatures**: Observe the digital signature process
4. **MyInvois Submission**: Simulate submission to IRBM portal
5. **Validation Process**: See real-time validation in action
6. **Invoice Storage**: Access the secure invoice archive
7. **Audit Trail**: Review the comprehensive logging system

### 4.2 Advanced Payment Technologies

Showcase of the system's payment capabilities:

1. **Multiple Payment Methods**: Process various payment types
2. **Contactless Payments**: Demonstrate NFC transactions
3. **QR Payments**: Use DuitNow QR and other QR payment options
4. **Biometric Authentication**: Simulate fingerprint/facial recognition
5. **Split Payments**: Process a bill with multiple payment methods
6. **Foreign Currency**: Handle tourist payments with dynamic conversion
7. **Payment Security**: View the security measures in place

### 4.3 Customer Communication

Demonstration of automated customer engagement:

1. **WhatsApp Receipts**: Send and view digital receipts
2. **Order Notifications**: Receive automated status updates
3. **Feedback Collection**: Experience the feedback request system
4. **Promotional Messaging**: View targeted marketing communications
5. **Loyalty Updates**: Receive points balance and reward notifications
6. **Preference Management**: Manage communication preferences
7. **Multi-channel Delivery**: See message delivery across different channels

## 5. Technical Demonstrations

### 5.1 System Architecture

For technical audiences, the demo includes insights into the system architecture:

1. **Microservices Overview**: Visualize the microservices architecture
2. **API Gateway**: Understand the API management approach
3. **Event-Driven Communication**: See the event bus in action
4. **Data Synchronization**: Observe real-time data updates
5. **Offline Capabilities**: Test the system's offline functionality
6. **Security Measures**: Review the multi-layered security approach
7. **Scalability Features**: Understand the scaling capabilities

### 5.2 Integration Capabilities

Demonstration of the system's integration with external systems:

1. **Accounting Integration**: Connect with accounting software
2. **Delivery Platform Integration**: Link with delivery services
3. **Inventory Supplier Integration**: Automate purchasing
4. **Payment Gateway Integration**: Process payments through various gateways
5. **Marketing Platform Integration**: Connect with marketing tools
6. **Reservation System Integration**: Sync with table reservation platforms
7. **Custom API Integration**: Demonstrate the open API capabilities

## 6. Customization Options

The demo showcases the system's flexibility and customization options:

1. **Branding Customization**: Apply different visual themes
2. **Menu Configuration**: Adjust menu structure and options
3. **Workflow Customization**: Modify operational workflows
4. **Report Customization**: Create custom reports and dashboards
5. **User Role Configuration**: Define custom user roles and permissions
6. **Integration Settings**: Configure third-party integrations
7. **Language and Localization**: Adjust regional settings

## 7. Implementation and Support

Information about the implementation process and ongoing support:

1. **Implementation Timeline**: Review typical deployment schedules
2. **Training Programs**: Learn about available training options
3. **Data Migration**: Understand the data migration process
4. **Support Tiers**: Explore different support packages
5. **Update Process**: Learn about the system update procedure
6. **Community Resources**: Access user community and knowledge base
7. **Consultation Services**: Information on available professional services

## 8. Demo Navigation Tips

### 8.1 Interface Navigation

- Use the hamburger menu (☰) in the top-left corner to access different modules
- The dashboard can be accessed by clicking the MalaysiaDish logo
- Use the user icon in the top-right corner to switch between user roles
- The settings gear icon provides access to configuration options
- The help icon (?) offers contextual guidance for each screen

### 8.2 Scenario Selection

- From the demo landing page, select "Guided Scenarios" to access the predefined scenarios
- Each scenario includes step-by-step instructions
- Use the "Reset Scenario" button to start over at any point
- The "Free Exploration" option allows unguided system navigation

### 8.3 Time Controls

- The demo includes time simulation controls to demonstrate time-dependent features
- Use the time controls to simulate different times of day or days of the week
- This is particularly useful for testing features like menu availability and reporting

## 9. Feedback Collection

The demo includes a feedback mechanism to gather your thoughts and suggestions:

- The feedback button is available in the bottom-right corner of every screen
- Please share your impressions, questions, and feature requests
- Your feedback will help us continue to improve MalaysiaDish POS

## 10. Next Steps

After exploring the demo, consider these next steps:

1. **Schedule a Consultation**: Arrange a personalized demonstration with our team
2. **Request a Pilot**: Discuss a pilot implementation for your business
3. **Customization Discussion**: Explore specific customization needs
4. **Pricing Information**: Request detailed pricing based on your requirements
5. **Implementation Planning**: Begin planning your implementation timeline
6. **Integration Assessment**: Evaluate integration needs with existing systems
7. **Training Planning**: Discuss training requirements for your team

Thank you for exploring the MalaysiaDish POS interactive demo. We look forward to partnering with you to transform your F&B operations with the most advanced POS system in Malaysia.
