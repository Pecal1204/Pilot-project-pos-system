import { Order, OrderStatus, OrderType, PaymentStatus } from '@malaysiadish-pos/common';

// Mock database for demo purposes
let orders: Order[] = [];

export const orderService = {
  // Get all orders with optional filtering
  async getOrders(
    filters: Partial<Order> = {},
    dateRange?: { startDate: string; endDate: string },
    pagination?: { page: number; limit: number }
  ): Promise<{ data: Order[]; meta?: { page: number; limit: number; total: number; totalPages: number } }> {
    let filteredOrders = [...orders];
    
    // Apply filters
    if (filters.status) {
      filteredOrders = filteredOrders.filter(order => order.status === filters.status);
    }
    
    if (filters.type) {
      filteredOrders = filteredOrders.filter(order => order.type === filters.type);
    }
    
    if (filters.tableId) {
      filteredOrders = filteredOrders.filter(order => order.tableId === filters.tableId);
    }
    
    if (filters.customerId) {
      filteredOrders = filteredOrders.filter(order => order.customerId === filters.customerId);
    }
    
    // Apply date range filter
    if (dateRange) {
      const startDate = new Date(dateRange.startDate).getTime();
      const endDate = new Date(dateRange.endDate).getTime();
      
      filteredOrders = filteredOrders.filter(order => {
        const orderDate = new Date(order.createdAt).getTime();
        return orderDate >= startDate && orderDate <= endDate;
      });
    }
    
    // Sort by creation date (newest first)
    filteredOrders.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    
    // Apply pagination
    if (pagination) {
      const { page, limit } = pagination;
      const startIndex = (page - 1) * limit;
      const endIndex = page * limit;
      
      const paginatedOrders = filteredOrders.slice(startIndex, endIndex);
      
      return {
        data: paginatedOrders,
        meta: {
          page,
          limit,
          total: filteredOrders.length,
          totalPages: Math.ceil(filteredOrders.length / limit)
        }
      };
    }
    
    return { data: filteredOrders };
  },
  
  // Get order by ID
  async getOrderById(id: string): Promise<Order | null> {
    const order = orders.find(order => order.id === id);
    return order || null;
  },
  
  // Create new order
  async createOrder(orderData: Order): Promise<Order> {
    // Calculate tax, service charge, and total
    const taxRate = 0.06; // 6% SST
    const serviceChargeRate = 0.10; // 10% service charge
    
    const taxAmount = orderData.subtotal * taxRate;
    const serviceCharge = orderData.subtotal * serviceChargeRate;
    const total = orderData.subtotal + taxAmount + serviceCharge - (orderData.discount || 0);
    
    const newOrder: Order = {
      ...orderData,
      taxAmount,
      serviceCharge,
      total,
      restaurantId: 'default' // For demo purposes
    };
    
    orders.push(newOrder);
    return newOrder;
  },
  
  // Update order
  async updateOrder(id: string, updateData: Partial<Order>): Promise<Order | null> {
    const orderIndex = orders.findIndex(order => order.id === id);
    
    if (orderIndex === -1) {
      return null;
    }
    
    // Update the order
    const updatedOrder = {
      ...orders[orderIndex],
      ...updateData,
      updatedAt: new Date().toISOString()
    };
    
    // Recalculate totals if necessary
    if (updateData.items || updateData.discount !== undefined) {
      const taxRate = 0.06; // 6% SST
      const serviceChargeRate = 0.10; // 10% service charge
      
      updatedOrder.taxAmount = updatedOrder.subtotal * taxRate;
      updatedOrder.serviceCharge = updatedOrder.subtotal * serviceChargeRate;
      updatedOrder.total = updatedOrder.subtotal + updatedOrder.taxAmount + updatedOrder.serviceCharge - (updatedOrder.discount || 0);
    }
    
    orders[orderIndex] = updatedOrder;
    return updatedOrder;
  },
  
  // Update order status
  async updateOrderStatus(id: string, status: OrderStatus): Promise<Order | null> {
    const orderIndex = orders.findIndex(order => order.id === id);
    
    if (orderIndex === -1) {
      return null;
    }
    
    // Update status and timestamp
    orders[orderIndex] = {
      ...orders[orderIndex],
      status,
      updatedAt: new Date().toISOString()
    };
    
    return orders[orderIndex];
  },
  
  // Add payment to order
  async addPayment(id: string, payment: any): Promise<Order | null> {
    const orderIndex = orders.findIndex(order => order.id === id);
    
    if (orderIndex === -1) {
      return null;
    }
    
    const order = orders[orderIndex];
    
    // Add payment to order
    const updatedPayments = [...order.payments, payment];
    
    // Calculate total paid amount
    const totalPaid = updatedPayments.reduce((sum, payment) => sum + payment.amount, 0);
    
    // Determine payment status
    let paymentStatus = PaymentStatus.PENDING;
    
    if (totalPaid >= order.total) {
      paymentStatus = PaymentStatus.PAID;
    } else if (totalPaid > 0) {
      paymentStatus = PaymentStatus.PARTIAL;
    }
    
    // Update order
    const updatedOrder = {
      ...order,
      payments: updatedPayments,
      paymentStatus,
      updatedAt: new Date().toISOString()
    };
    
    // If fully paid, update status to COMPLETED if it was SERVED
    if (paymentStatus === PaymentStatus.PAID && order.status === OrderStatus.SERVED) {
      updatedOrder.status = OrderStatus.COMPLETED;
    }
    
    orders[orderIndex] = updatedOrder;
    return updatedOrder;
  },
  
  // Delete order (soft delete)
  async deleteOrder(id: string): Promise<{ id: string; restaurantId?: string } | null> {
    const orderIndex = orders.findIndex(order => order.id === id);
    
    if (orderIndex === -1) {
      return null;
    }
    
    const { id: orderId, restaurantId } = orders[orderIndex];
    
    // Remove order from array (in a real app, this would be a soft delete)
    orders = orders.filter(order => order.id !== id);
    
    return { id: orderId, restaurantId };
  }
};
