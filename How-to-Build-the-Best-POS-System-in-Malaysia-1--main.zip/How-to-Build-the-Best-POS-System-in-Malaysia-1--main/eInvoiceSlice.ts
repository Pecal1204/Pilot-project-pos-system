import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { EInvoice, InvoiceStatus } from '@malaysiadish-pos/common';
import { RootState } from '../../store';
import { api } from '../../services/api';

interface EInvoiceState {
  currentInvoice: EInvoice | null;
  isInvoiceModalOpen: boolean;
  selectedInvoiceId: string | null;
  invoiceFilter: {
    status: InvoiceStatus | 'ALL';
    dateRange: {
      startDate: string | null;
      endDate: string | null;
    };
  };
}

const initialState: EInvoiceState = {
  currentInvoice: null,
  isInvoiceModalOpen: false,
  selectedInvoiceId: null,
  invoiceFilter: {
    status: 'ALL',
    dateRange: {
      startDate: null,
      endDate: null,
    },
  },
};

export const eInvoiceSlice = createSlice({
  name: 'eInvoice',
  initialState,
  reducers: {
    setCurrentInvoice: (state, action: PayloadAction<EInvoice | null>) => {
      state.currentInvoice = action.payload;
    },
    setInvoiceModalOpen: (state, action: PayloadAction<boolean>) => {
      state.isInvoiceModalOpen = action.payload;
    },
    setSelectedInvoiceId: (state, action: PayloadAction<string | null>) => {
      state.selectedInvoiceId = action.payload;
    },
    setInvoiceFilter: (state, action: PayloadAction<Partial<EInvoiceState['invoiceFilter']>>) => {
      state.invoiceFilter = {
        ...state.invoiceFilter,
        ...action.payload,
      };
    },
    setInvoiceDateRange: (state, action: PayloadAction<{ startDate: string | null; endDate: string | null }>) => {
      state.invoiceFilter.dateRange = action.payload;
    },
  },
  // Will be expanded when API endpoints for e-invoicing are implemented
  extraReducers: (builder) => {
    // Example of how we'll handle API responses
    // builder
    //   .addMatcher(
    //     api.endpoints.getInvoiceById.matchFulfilled,
    //     (state, { payload }) => {
    //       if (payload.data && state.selectedInvoiceId === payload.data.id) {
    //         state.currentInvoice = payload.data;
    //       }
    //     }
    //   )
  },
});

export const {
  setCurrentInvoice,
  setInvoiceModalOpen,
  setSelectedInvoiceId,
  setInvoiceFilter,
  setInvoiceDateRange,
} = eInvoiceSlice.actions;

// Selectors
export const selectCurrentInvoice = (state: RootState) => state.eInvoice.currentInvoice;
export const selectIsInvoiceModalOpen = (state: RootState) => state.eInvoice.isInvoiceModalOpen;
export const selectSelectedInvoiceId = (state: RootState) => state.eInvoice.selectedInvoiceId;
export const selectInvoiceFilter = (state: RootState) => state.eInvoice.invoiceFilter;

export default eInvoiceSlice.reducer;
