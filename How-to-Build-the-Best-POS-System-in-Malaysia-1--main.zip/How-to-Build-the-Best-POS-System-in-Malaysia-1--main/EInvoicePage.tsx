import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Typography, 
  Paper, 
  Grid, 
  Button, 
  Divider, 
  List, 
  ListItem, 
  ListItemText, 
  Tabs,
  Tab,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  CircularProgress,
  Alert,
  IconButton
} from '@mui/material';
import ReceiptIcon from '@mui/icons-material/Receipt';
import PrintIcon from '@mui/icons-material/Print';
import EmailIcon from '@mui/icons-material/Email';
import WhatsAppIcon from '@mui/icons-material/WhatsApp';
import { InvoiceStatus } from '@malaysiadish-pos/common';
import { useAppDispatch, useAppSelector } from '../hooks/reduxHooks';
import { 
  setSelectedInvoiceId,
  setCurrentInvoice,
  setInvoiceModalOpen,
  selectSelectedInvoiceId,
  selectIsInvoiceModalOpen,
  selectInvoiceFilter,
  setInvoiceFilter
} from '../features/einvoice/eInvoiceSlice';
import { api } from '../services/api';

// Extend the API with e-invoice endpoints
const extendedApi = api.injectEndpoints({
  endpoints: (builder) => ({
    getInvoices: builder.query({
      query: (params) => ({
        url: '/einvoices',
        params,
      }),
      providesTags: ['EInvoice'],
    }),
    getInvoiceById: builder.query({
      query: (id) => `/einvoices/${id}`,
      providesTags: (result, error, id) => [{ type: 'EInvoice', id }],
    }),
    generateInvoice: builder.mutation({
      query: ({ orderId, customerInfo }) => ({
        url: `/einvoices/generate/${orderId}`,
        method: 'POST',
        body: { customerInfo },
      }),
      invalidatesTags: ['EInvoice'],
    }),
    submitInvoice: builder.mutation({
      query: (id) => ({
        url: `/einvoices/${id}/submit`,
        method: 'POST',
      }),
      invalidatesTags: (result, error, id) => [{ type: 'EInvoice', id }],
    }),
    updateInvoiceStatus: builder.mutation({
      query: ({ id, status }) => ({
        url: `/einvoices/${id}/status`,
        method: 'PATCH',
        body: { status },
      }),
      invalidatesTags: (result, error, { id }) => [{ type: 'EInvoice', id }],
    }),
    cancelInvoice: builder.mutation({
      query: ({ id, reason }) => ({
        url: `/einvoices/${id}/cancel`,
        method: 'POST',
        body: { reason },
      }),
      invalidatesTags: (result, error, { id }) => [{ type: 'EInvoice', id }],
    }),
    getInvoiceFormat: builder.query({
      query: ({ id, format }) => `/einvoices/${id}/format/${format}`,
    }),
  }),
});

export const {
  useGetInvoicesQuery,
  useGetInvoiceByIdQuery,
  useGenerateInvoiceMutation,
  useSubmitInvoiceMutation,
  useUpdateInvoiceStatusMutation,
  useCancelInvoiceMutation,
  useGetInvoiceFormatQuery,
} = extendedApi;

const EInvoicePage: React.FC = () => {
  const dispatch = useAppDispatch();
  const selectedInvoiceId = useAppSelector(selectSelectedInvoiceId);
  const isInvoiceModalOpen = useAppSelector(selectIsInvoiceModalOpen);
  const invoiceFilter = useAppSelector(selectInvoiceFilter);
  
  const [tabValue, setTabValue] = useState(0);
  const [cancelReason, setCancelReason] = useState('');
  const [showCancelDialog, setShowCancelDialog] = useState(false);
  const [customerInfo, setCustomerInfo] = useState({
    name: '',
    address: '',
    taxId: '',
    email: '',
    phone: ''
  });
  const [orderId, setOrderId] = useState('');
  const [showGenerateDialog, setShowGenerateDialog] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  
  // Get all invoices
  const { data: invoicesData, isLoading: isLoadingInvoices } = useGetInvoicesQuery({
    status: tabValue === 0 ? undefined : 
           tabValue === 1 ? InvoiceStatus.DRAFT :
           tabValue === 2 ? InvoiceStatus.SUBMITTED :
           tabValue === 3 ? InvoiceStatus.VALIDATED :
           tabValue === 4 ? InvoiceStatus.REJECTED : undefined
  });
  
  // Get selected invoice details
  const { data: selectedInvoiceData } = useGetInvoiceByIdQuery(selectedInvoiceId || '', {
    skip: !selectedInvoiceId
  });
  
  // Mutations
  const [generateInvoice, { isLoading: isGenerating }] = useGenerateInvoiceMutation();
  const [submitInvoice, { isLoading: isSubmitting }] = useSubmitInvoiceMutation();
  const [updateInvoiceStatus] = useUpdateInvoiceStatusMutation();
  const [cancelInvoice, { isLoading: isCancelling }] = useCancelInvoiceMutation();
  
  // Set current invoice when selected invoice data changes
  useEffect(() => {
    if (selectedInvoiceData?.data) {
      dispatch(setCurrentInvoice(selectedInvoiceData.data));
    }
  }, [selectedInvoiceData, dispatch]);
  
  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };
  
  const handleSelectInvoice = (invoiceId: string) => {
    dispatch(setSelectedInvoiceId(invoiceId));
  };
  
  const handleOpenGenerateDialog = () => {
    setShowGenerateDialog(true);
    setErrorMessage(null);
    setCustomerInfo({
      name: '',
      address: '',
      taxId: '',
      email: '',
      phone: ''
    });
    setOrderId('');
  };
  
  const handleCloseGenerateDialog = () => {
    setShowGenerateDialog(false);
  };
  
  const handleGenerateInvoice = async () => {
    if (!orderId) {
      setErrorMessage('Order ID is required');
      return;
    }
    
    try {
      const result = await generateInvoice({
        orderId,
        customerInfo: {
          name: customerInfo.name || 'Walk-in Customer',
          address: customerInfo.address,
          taxId: customerInfo.taxId,
          email: customerInfo.email,
          phone: customerInfo.phone
        }
      }).unwrap();
      
      if (result.data) {
        dispatch(setSelectedInvoiceId(result.data.id));
        handleCloseGenerateDialog();
      }
    } catch (error: any) {
      setErrorMessage(error.data?.error?.message || 'Failed to generate invoice');
    }
  };
  
  const handleSubmitInvoice = async (id: string) => {
    try {
      await submitInvoice(id).unwrap();
    } catch (error: any) {
      console.error('Failed to submit invoice:', error);
    }
  };
  
  const handleOpenCancelDialog = () => {
    setShowCancelDialog(true);
    setCancelReason('');
  };
  
  const handleCloseCancelDialog = () => {
    setShowCancelDialog(false);
  };
  
  const handleCancelInvoice = async () => {
    if (!selectedInvoiceId || !cancelReason) return;
    
    try {
      await cancelInvoice({
        id: selectedInvoiceId,
        reason: cancelReason
      }).unwrap();
      
      handleCloseCancelDialog();
    } catch (error: any) {
      console.error('Failed to cancel invoice:', error);
    }
  };
  
  const handleDownloadInvoice = (id: string, format: 'xml' | 'json') => {
    // Create a temporary link to download the file
    const link = document.createElement('a');
    link.href = `${import.meta.env.VITE_API_URL || 'http://localhost:3001/api'}/einvoices/${id}/format/${format}`;
    link.download = `invoice-${id}.${format}`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };
  
  const getStatusChip = (status: InvoiceStatus) => {
    let color;
    switch (status) {
      case InvoiceStatus.DRAFT:
        color = 'default';
        break;
      case InvoiceStatus.ISSUED:
        color = 'primary';
        break;
      case InvoiceStatus.SUBMITTED:
        color = 'warning';
        break;
      case InvoiceStatus.VALIDATED:
        color = 'success';
        break;
      case InvoiceStatus.REJECTED:
        color = 'error';
        break;
      case InvoiceStatus.CANCELLED:
        color = 'error';
        break;
      default:
        color = 'default';
    }
    
    return <Chip label={status} color={color as any} size="small" />;
  };
  
  return (
    <Box sx={{ flexGrow: 1 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 3 }}>
        <Typography variant="h4">E-Invoices</Typography>
        <Button 
          variant="contained" 
          startIcon={<ReceiptIcon />}
          onClick={handleOpenGenerateDialog}
        >
          Generate New E-Invoice
        </Button>
      </Box>
      
      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
        <Tabs value={tabValue} onChange={handleTabChange}>
          <Tab label="All Invoices" />
          <Tab label="Draft" />
          <Tab label="Submitted" />
          <Tab label="Validated" />
          <Tab label="Rejected" />
        </Tabs>
      </Box>
      
      <Grid container spacing={3}>
        {/* Left side - Invoices list */}
        <Grid item xs={12} md={7}>
          <Paper sx={{ p: 2 }}>
            {isLoadingInvoices ? (
              <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
                <CircularProgress />
              </Box>
            ) : invoicesData?.data?.length === 0 ? (
              <Box sx={{ p: 3, textAlign: 'center' }}>
                <Typography variant="body1" color="text.secondary">
                  No invoices found
                </Typography>
              </Box>
            ) : (
              <List>
                {invoicesData?.data?.map((invoice) => (
                  <ListItem 
                    key={invoice.id}
                    button
                    selected={selectedInvoiceId === invoice.id}
                    onClick={() => handleSelectInvoice(invoice.id)}
                    sx={{ mb: 1, border: 1, borderColor: 'divider', borderRadius: 1 }}
                  >
                    <ListItemText
                      primary={
                        <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                          <Typography variant="subtitle1">{invoice.invoiceNumber}</Typography>
                          {getStatusChip(invoice.status)}
                        </Box>
                      }
                      secondary={
                        <>
                          <Typography variant="body2" color="text.secondary">
                            Customer: {invoice.customerInfo.name}
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            Date: {new Date(invoice.issueDate).toLocaleDateString()}
                          </Typography>
                          <Typography variant="body2" color="primary" sx={{ fontWeight: 'bold' }}>
                            RM {invoice.total.toFixed(2)}
                          </Typography>
                        </>
                      }
                      primaryTypographyProps={{ component: 'div' }}
                      secondaryTypographyProps={{ component: 'div' }}
                    />
                  </ListItem>
                ))}
              </List>
            )}
          </Paper>
        </Grid>
        
        {/* Right side - Invoice details */}
        <Grid item xs={12} md={5}>
          <Paper sx={{ p: 2, position: 'sticky', top: 88 }}>
            {selectedInvoiceData?.data ? (
              <>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                  <Typography variant="h6">
                    Invoice #{selectedInvoiceData.data.invoiceNumber}
                  </Typography>
                  <Box>
                    {getStatusChip(selectedInvoiceData.data.status)}
                  </Box>
                </Box>
                
                <Box sx={{ mb: 2 }}>
                  <Typography variant="body2" color="text.secondary">
                    Order: {selectedInvoiceData.data.orderId}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Date: {new Date(selectedInvoiceData.data.issueDate).toLocaleDateString()}
                  </Typography>
                  {selectedInvoiceData.data.submissionId && (
                    <Typography variant="body2" color="text.secondary">
                      Submission ID: {selectedInvoiceData.data.submissionId}
                    </Typography>
                  )}
                </Box>
                
                <Divider sx={{ my: 2 }} />
                
                <Typography variant="subtitle2" gutterBottom>
                  Customer Information
                </Typography>
                
                <Box sx={{ mb: 2 }}>
                  <Typography variant="body2">
                    {selectedInvoiceData.data.customerInfo.name}
                  </Typography>
                  {selectedInvoiceData.data.customerInfo.address && (
                    <Typography variant="body2" color="text.secondary">
                      {selectedInvoiceData.data.customerInfo.address}
                    </Typography>
                  )}
                  {selectedInvoiceData.data.customerInfo.taxId && (
                    <Typography variant="body2" color="text.secondary">
                      Tax ID: {selectedInvoiceData.data.customerInfo.taxId}
                    </Typography>
                  )}
                  {selectedInvoiceData.data.customerInfo.email && (
                    <Typography variant="body2" color="text.secondary">
                      Email: {selectedInvoiceData.data.customerInfo.email}
                    </Typography>
                  )}
                  {selectedInvoiceData.data.customerInfo.phone && (
                    <Typography variant="body2" color="text.secondary">
                      Phone: {selectedInvoiceData.data.customerInfo.phone}
                    </Typography>
                  )}
                </Box>
                
                <Divider sx={{ my: 2 }} />
                
                <Typography variant="subtitle2" gutterBottom>
                  Items
                </Typography>
                
                <List dense>
                  {selectedInvoiceData.data.items.map((item, index) => (
                    <ListItem key={index}>
                      <ListItemText
                        primary={`${item.quantity}x ${item.description}`}
                        secondary={`RM ${item.unitPrice.toFixed(2)} each`}
                      />
                      <Typography variant="body2">
                        RM {item.subtotal.toFixed(2)}
                      </Typography>
                    </ListItem>
                  ))}
                </List>
                
                <Divider sx={{ my: 2 }} />
                
                <Box sx={{ mb: 2 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                    <Typography variant="body2">Subtotal</Typography>
                    <Typography variant="body2">
                      RM {selectedInvoiceData.data.subtotal.toFixed(2)}
                    </Typography>
                  </Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                    <Typography variant="body2" color="text.secondary">
                      Service Charge
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      RM {selectedInvoiceData.data.serviceCharge.toFixed(2)}
                    </Typography>
                  </Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                    <Typography variant="body2" color="text.secondary">
                      Tax (SST)
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      RM {selectedInvoiceData.data.taxAmount.toFixed(2)}
                    </Typography>
                  </Box>
                  {selectedInvoiceData.data.discount > 0 && (
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                      <Typography var
(Content truncated due to size limit. Use line ranges to read in chunks)