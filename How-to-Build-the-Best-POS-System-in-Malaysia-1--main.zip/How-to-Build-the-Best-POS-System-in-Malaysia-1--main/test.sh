#!/bin/bash

# MalaysiaDish POS System Test Script
# This script runs tests for all major components of the MalaysiaDish POS system

echo "Starting MalaysiaDish POS System Tests..."
echo "----------------------------------------"

# Create test results directory
mkdir -p /home/ubuntu/malaysiadish_pos/test_results

# Function to log test results
log_test() {
  local component=$1
  local test_name=$2
  local status=$3
  local details=$4
  
  echo "[$component] $test_name: $status"
  echo "[$component] $test_name: $status - $details" >> /home/ubuntu/malaysiadish_pos/test_results/test_log.txt
}

# Test API Server
echo "Testing API Server..."
cd /home/ubuntu/malaysiadish_pos/packages/api-server

# Check if server starts properly
echo "Starting API server for testing..."
node -e "
const app = require('./src/index.js');
const server = app.listen(3001, '0.0.0.0', () => {
  console.log('Server started successfully for testing');
  setTimeout(() => {
    server.close(() => {
      console.log('Server closed after test');
    });
  }, 5000);
});" > /dev/null 2>&1

if [ $? -eq 0 ]; then
  log_test "API Server" "Startup" "PASS" "Server starts without errors"
else
  log_test "API Server" "Startup" "FAIL" "Server failed to start"
fi

# Test API endpoints
echo "Testing API endpoints..."
curl -s http://localhost:3001/health > /dev/null
if [ $? -eq 0 ]; then
  log_test "API Server" "Health Endpoint" "PASS" "Health endpoint is accessible"
else
  log_test "API Server" "Health Endpoint" "FAIL" "Health endpoint is not accessible"
fi

# Test E-Invoicing Module
echo "Testing E-Invoicing Module..."
# Validate UBL 2.1 compliance
if grep -q "UBL 2.1" /home/ubuntu/malaysiadish_pos/packages/api-server/src/routes/eInvoiceRoutes.ts; then
  log_test "E-Invoicing" "UBL 2.1 Compliance" "PASS" "UBL 2.1 standard is implemented"
else
  log_test "E-Invoicing" "UBL 2.1 Compliance" "FAIL" "UBL 2.1 standard not found in implementation"
fi

# Check for IRBM integration
if grep -q "IRBM" /home/ubuntu/malaysiadish_pos/packages/api-server/src/routes/eInvoiceRoutes.ts; then
  log_test "E-Invoicing" "IRBM Integration" "PASS" "IRBM integration is implemented"
else
  log_test "E-Invoicing" "IRBM Integration" "FAIL" "IRBM integration not found in implementation"
fi

# Test Payment Module
echo "Testing Payment Module..."
# Check for EMV compliance
if grep -q "EMV" /home/ubuntu/malaysiadish_pos/packages/api-server/src/routes/paymentRoutes.ts; then
  log_test "Payments" "EMV Compliance" "PASS" "EMV compliance is implemented"
else
  log_test "Payments" "EMV Compliance" "FAIL" "EMV compliance not found in implementation"
fi

# Check for biometric authentication
if grep -q "biometric" /home/ubuntu/malaysiadish_pos/packages/api-server/src/routes/paymentRoutes.ts; then
  log_test "Payments" "Biometric Authentication" "PASS" "Biometric authentication is implemented"
else
  log_test "Payments" "Biometric Authentication" "FAIL" "Biometric authentication not found in implementation"
fi

# Test AI Module
echo "Testing AI Module..."
# Check for personalization features
if grep -q "personalized" /home/ubuntu/malaysiadish_pos/packages/api-server/src/routes/aiRoutes.ts; then
  log_test "AI" "Personalization" "PASS" "Personalization features are implemented"
else
  log_test "AI" "Personalization" "FAIL" "Personalization features not found in implementation"
fi

# Check for inventory prediction
if grep -q "predictive" /home/ubuntu/malaysiadish_pos/packages/api-server/src/routes/aiRoutes.ts; then
  log_test "AI" "Inventory Prediction" "PASS" "Inventory prediction is implemented"
else
  log_test "AI" "Inventory Prediction" "FAIL" "Inventory prediction not found in implementation"
fi

# Test Self-Service Module
echo "Testing Self-Service Module..."
# Check for accessibility features
if grep -q "accessibility" /home/ubuntu/malaysiadish_pos/packages/pos-terminal/src/pages/SelfServiceKiosk.tsx; then
  log_test "Self-Service" "Accessibility" "PASS" "Accessibility features are implemented"
else
  log_test "Self-Service" "Accessibility" "FAIL" "Accessibility features not found in implementation"
fi

# Check for multilingual support
if grep -q "language" /home/ubuntu/malaysiadish_pos/packages/pos-terminal/src/pages/SelfServiceKiosk.tsx; then
  log_test "Self-Service" "Multilingual Support" "PASS" "Multilingual support is implemented"
else
  log_test "Self-Service" "Multilingual Support" "FAIL" "Multilingual support not found in implementation"
fi

# Test Omnichannel Module
echo "Testing Omnichannel Module..."
# Check for real-time sync
if grep -q "realTimeSync" /home/ubuntu/malaysiadish_pos/packages/pos-terminal/src/features/omnichannel/omnichannelSlice.ts; then
  log_test "Omnichannel" "Real-Time Sync" "PASS" "Real-time sync is implemented"
else
  log_test "Omnichannel" "Real-Time Sync" "FAIL" "Real-time sync not found in implementation"
fi

# Check for multiple channel support
if grep -q "channels" /home/ubuntu/malaysiadish_pos/packages/pos-terminal/src/features/omnichannel/omnichannelSlice.ts; then
  log_test "Omnichannel" "Multiple Channels" "PASS" "Multiple channel support is implemented"
else
  log_test "Omnichannel" "Multiple Channels" "FAIL" "Multiple channel support not found in implementation"
fi

# Test Communication Module
echo "Testing Communication Module..."
# Check for WhatsApp integration
if grep -q "whatsapp" /home/ubuntu/malaysiadish_pos/packages/api-server/src/routes/communicationRoutes.ts; then
  log_test "Communication" "WhatsApp Integration" "PASS" "WhatsApp integration is implemented"
else
  log_test "Communication" "WhatsApp Integration" "FAIL" "WhatsApp integration not found in implementation"
fi

# Check for receipt templates
if grep -q "receipt" /home/ubuntu/malaysiadish_pos/packages/api-server/src/routes/communicationRoutes.ts; then
  log_test "Communication" "Receipt Templates" "PASS" "Receipt templates are implemented"
else
  log_test "Communication" "Receipt Templates" "FAIL" "Receipt templates not found in implementation"
fi

# Generate test summary
echo "Generating test summary..."
passed=$(grep -c "PASS" /home/ubuntu/malaysiadish_pos/test_results/test_log.txt)
failed=$(grep -c "FAIL" /home/ubuntu/malaysiadish_pos/test_results/test_log.txt)
total=$((passed + failed))

echo "----------------------------------------"
echo "Test Summary:"
echo "Total Tests: $total"
echo "Passed: $passed"
echo "Failed: $failed"
echo "Success Rate: $(( (passed * 100) / total ))%"
echo "----------------------------------------"

echo "Test Summary:" > /home/ubuntu/malaysiadish_pos/test_results/summary.txt
echo "Total Tests: $total" >> /home/ubuntu/malaysiadish_pos/test_results/summary.txt
echo "Passed: $passed" >> /home/ubuntu/malaysiadish_pos/test_results/summary.txt
echo "Failed: $failed" >> /home/ubuntu/malaysiadish_pos/test_results/summary.txt
echo "Success Rate: $(( (passed * 100) / total ))%" >> /home/ubuntu/malaysiadish_pos/test_results/summary.txt

echo "Tests completed. Results saved to /home/ubuntu/malaysiadish_pos/test_results/"
