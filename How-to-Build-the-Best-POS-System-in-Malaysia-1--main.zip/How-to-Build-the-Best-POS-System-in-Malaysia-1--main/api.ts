import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';
import { ApiResponse, Order, OrderStatus, Payment, Product, Table, User } from '@malaysiadish-pos/common';

// Define our API service using RTK Query
export const api = createApi({
  reducerPath: 'api',
  baseQuery: fetchBaseQuery({ 
    baseUrl: import.meta.env.VITE_API_URL || 'http://localhost:3001/api',
    prepareHeaders: (headers, { getState }) => {
      // Add auth token if available
      const token = (getState() as any).auth.token;
      if (token) {
        headers.set('authorization', `Bearer ${token}`);
      }
      return headers;
    },
  }),
  tagTypes: ['Order', 'Table', 'Product', 'User'],
  endpoints: (builder) => ({
    // Order endpoints
    getOrders: builder.query<ApiResponse<Order[]>, { status?: OrderStatus; tableId?: string; page?: number; limit?: number }>({
      query: (params) => ({
        url: '/orders',
        params,
      }),
      providesTags: (result) => 
        result?.data
          ? [
              ...result.data.map(({ id }) => ({ type: 'Order' as const, id })),
              { type: 'Order', id: 'LIST' },
            ]
          : [{ type: 'Order', id: 'LIST' }],
    }),
    
    getOrderById: builder.query<ApiResponse<Order>, string>({
      query: (id) => `/orders/${id}`,
      providesTags: (result, error, id) => [{ type: 'Order', id }],
    }),
    
    createOrder: builder.mutation<ApiResponse<Order>, Partial<Order>>({
      query: (order) => ({
        url: '/orders',
        method: 'POST',
        body: order,
      }),
      invalidatesTags: [{ type: 'Order', id: 'LIST' }],
    }),
    
    updateOrder: builder.mutation<ApiResponse<Order>, { id: string; order: Partial<Order> }>({
      query: ({ id, order }) => ({
        url: `/orders/${id}`,
        method: 'PUT',
        body: order,
      }),
      invalidatesTags: (result, error, { id }) => [{ type: 'Order', id }],
    }),
    
    updateOrderStatus: builder.mutation<ApiResponse<Order>, { id: string; status: OrderStatus }>({
      query: ({ id, status }) => ({
        url: `/orders/${id}/status`,
        method: 'PATCH',
        body: { status },
      }),
      invalidatesTags: (result, error, { id }) => [{ type: 'Order', id }],
    }),
    
    addPayment: builder.mutation<ApiResponse<Order>, { id: string; payment: Partial<Payment> }>({
      query: ({ id, payment }) => ({
        url: `/orders/${id}/payments`,
        method: 'POST',
        body: payment,
      }),
      invalidatesTags: (result, error, { id }) => [{ type: 'Order', id }],
    }),
    
    deleteOrder: builder.mutation<ApiResponse<{ message: string }>, string>({
      query: (id) => ({
        url: `/orders/${id}`,
        method: 'DELETE',
      }),
      invalidatesTags: [{ type: 'Order', id: 'LIST' }],
    }),
    
    // Table endpoints
    getTables: builder.query<ApiResponse<Table[]>, void>({
      query: () => '/tables',
      providesTags: (result) =>
        result?.data
          ? [
              ...result.data.map(({ id }) => ({ type: 'Table' as const, id })),
              { type: 'Table', id: 'LIST' },
            ]
          : [{ type: 'Table', id: 'LIST' }],
    }),
    
    getTableById: builder.query<ApiResponse<Table>, string>({
      query: (id) => `/tables/${id}`,
      providesTags: (result, error, id) => [{ type: 'Table', id }],
    }),
    
    updateTableStatus: builder.mutation<ApiResponse<Table>, { id: string; status: string }>({
      query: ({ id, status }) => ({
        url: `/tables/${id}/status`,
        method: 'PATCH',
        body: { status },
      }),
      invalidatesTags: (result, error, { id }) => [{ type: 'Table', id }],
    }),
    
    // Product endpoints
    getProducts: builder.query<ApiResponse<Product[]>, { category?: string; search?: string }>({
      query: (params) => ({
        url: '/products',
        params,
      }),
      providesTags: (result) =>
        result?.data
          ? [
              ...result.data.map(({ id }) => ({ type: 'Product' as const, id })),
              { type: 'Product', id: 'LIST' },
            ]
          : [{ type: 'Product', id: 'LIST' }],
    }),
    
    getProductById: builder.query<ApiResponse<Product>, string>({
      query: (id) => `/products/${id}`,
      providesTags: (result, error, id) => [{ type: 'Product', id }],
    }),
    
    // User endpoints
    login: builder.mutation<ApiResponse<{ user: User; token: string }>, { username: string; password: string }>({
      query: (credentials) => ({
        url: '/users/login',
        method: 'POST',
        body: credentials,
      }),
    }),
    
    getCurrentUser: builder.query<ApiResponse<User>, void>({
      query: () => '/users/me',
      providesTags: ['User'],
    }),
  }),
});

// Export hooks for usage in components
export const {
  useGetOrdersQuery,
  useGetOrderByIdQuery,
  useCreateOrderMutation,
  useUpdateOrderMutation,
  useUpdateOrderStatusMutation,
  useAddPaymentMutation,
  useDeleteOrderMutation,
  useGetTablesQuery,
  useGetTableByIdQuery,
  useUpdateTableStatusMutation,
  useGetProductsQuery,
  useGetProductByIdQuery,
  useLoginMutation,
  useGetCurrentUserQuery,
} = api;
