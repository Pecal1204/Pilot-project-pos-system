import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Grid, 
  Paper, 
  Typography, 
  Button, 
  Divider, 
  List, 
  ListItem, 
  ListItemText, 
  IconButton,
  Chip,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  CircularProgress,
  Tab,
  Tabs,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow
} from '@mui/material';
import RestaurantIcon from '@mui/icons-material/Restaurant';
import ReceiptIcon from '@mui/icons-material/Receipt';
import { OrderStatus, PaymentStatus } from '@malaysiadish-pos/common';
import { useAppDispatch, useAppSelector } from '../hooks/reduxHooks';
import { 
  setSelectedOrderId,
  setActiveOrder,
  setPaymentModalOpen,
  selectSelectedOrderId,
  selectIsPaymentModalOpen
} from '../features/orders/orderSlice';
import { 
  useGetOrdersQuery,
  useGetOrderByIdQuery,
  useUpdateOrderStatusMutation,
  useAddPaymentMutation
} from '../services/api';
import { selectCurrentUser } from '../features/auth/authSlice';

const TablesPage: React.FC = () => {
  const dispatch = useAppDispatch();
  const selectedOrderId = useAppSelector(selectSelectedOrderId);
  const isPaymentModalOpen = useAppSelector(selectIsPaymentModalOpen);
  const currentUser = useAppSelector(selectCurrentUser);
  
  const [tabValue, setTabValue] = useState(0);
  const [paymentMethod, setPaymentMethod] = useState('CASH');
  const [paymentAmount, setPaymentAmount] = useState('');
  
  // Get all orders
  const { data: ordersData, isLoading: isLoadingOrders } = useGetOrdersQuery({
    status: tabValue === 0 ? OrderStatus.CONFIRMED : undefined
  });
  
  // Get selected order details
  const { data: selectedOrderData } = useGetOrderByIdQuery(selectedOrderId || '', {
    skip: !selectedOrderId
  });
  
  const [updateOrderStatus] = useUpdateOrderStatusMutation();
  const [addPayment] = useAddPaymentMutation();
  
  // Set active order when selected order data changes
  useEffect(() => {
    if (selectedOrderData?.data) {
      dispatch(setActiveOrder(selectedOrderData.data));
    }
  }, [selectedOrderData, dispatch]);
  
  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };
  
  const handleSelectOrder = (orderId: string) => {
    dispatch(setSelectedOrderId(orderId));
  };
  
  const handleUpdateStatus = async (orderId: string, status: OrderStatus) => {
    try {
      await updateOrderStatus({ id: orderId, status }).unwrap();
    } catch (error) {
      console.error('Failed to update order status:', error);
    }
  };
  
  const handleOpenPaymentModal = () => {
    if (selectedOrderData?.data) {
      const remainingAmount = selectedOrderData.data.total - 
        selectedOrderData.data.payments.reduce((sum, payment) => sum + payment.amount, 0);
      setPaymentAmount(remainingAmount.toFixed(2));
      dispatch(setPaymentModalOpen(true));
    }
  };
  
  const handleClosePaymentModal = () => {
    dispatch(setPaymentModalOpen(false));
  };
  
  const handleAddPayment = async () => {
    if (!selectedOrderId || !paymentAmount) return;
    
    try {
      await addPayment({
        id: selectedOrderId,
        payment: {
          amount: parseFloat(paymentAmount),
          method: paymentMethod,
          receivedBy: currentUser?.id || 'unknown'
        }
      }).unwrap();
      
      // Reset form
      setPaymentMethod('CASH');
      setPaymentAmount('');
      
      // Close modal (handled by orderSlice extraReducer)
    } catch (error) {
      console.error('Failed to add payment:', error);
    }
  };
  
  const getStatusChip = (status: OrderStatus) => {
    let color;
    switch (status) {
      case OrderStatus.DRAFT:
        color = 'default';
        break;
      case OrderStatus.CONFIRMED:
        color = 'primary';
        break;
      case OrderStatus.PREPARING:
        color = 'warning';
        break;
      case OrderStatus.READY:
        color = 'info';
        break;
      case OrderStatus.SERVED:
        color = 'success';
        break;
      case OrderStatus.COMPLETED:
        color = 'success';
        break;
      case OrderStatus.CANCELLED:
        color = 'error';
        break;
      default:
        color = 'default';
    }
    
    return <Chip label={status} color={color as any} size="small" />;
  };
  
  const getPaymentStatusChip = (status: PaymentStatus) => {
    let color;
    switch (status) {
      case PaymentStatus.PENDING:
        color = 'default';
        break;
      case PaymentStatus.PARTIAL:
        color = 'warning';
        break;
      case PaymentStatus.PAID:
        color = 'success';
        break;
      case PaymentStatus.REFUNDED:
        color = 'info';
        break;
      case PaymentStatus.FAILED:
        color = 'error';
        break;
      default:
        color = 'default';
    }
    
    return <Chip label={status} color={color as any} size="small" />;
  };
  
  return (
    <Box sx={{ flexGrow: 1 }}>
      <Typography variant="h4" gutterBottom>
        Tables & Orders
      </Typography>
      
      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
        <Tabs value={tabValue} onChange={handleTabChange}>
          <Tab label="Active Orders" />
          <Tab label="All Orders" />
        </Tabs>
      </Box>
      
      <Grid container spacing={3}>
        {/* Left side - Orders list */}
        <Grid item xs={12} md={7}>
          <Paper sx={{ p: 2 }}>
            {isLoadingOrders ? (
              <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
                <CircularProgress />
              </Box>
            ) : (
              <TableContainer>
                <Table>
                  <TableHead>
                    <TableRow>
                      <TableCell>Order #</TableCell>
                      <TableCell>Type</TableCell>
                      <TableCell>Table</TableCell>
                      <TableCell>Status</TableCell>
                      <TableCell>Payment</TableCell>
                      <TableCell>Total</TableCell>
                      <TableCell>Actions</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {ordersData?.data?.length === 0 ? (
                      <TableRow>
                        <TableCell colSpan={7} align="center">
                          <Box sx={{ py: 3 }}>
                            <Typography variant="body1" color="text.secondary">
                              No orders found
                            </Typography>
                          </Box>
                        </TableCell>
                      </TableRow>
                    ) : (
                      ordersData?.data?.map((order) => (
                        <TableRow 
                          key={order.id}
                          selected={selectedOrderId === order.id}
                          onClick={() => handleSelectOrder(order.id)}
                          sx={{ cursor: 'pointer' }}
                        >
                          <TableCell>{order.orderNumber}</TableCell>
                          <TableCell>{order.type}</TableCell>
                          <TableCell>{order.tableId || '-'}</TableCell>
                          <TableCell>{getStatusChip(order.status)}</TableCell>
                          <TableCell>{getPaymentStatusChip(order.paymentStatus)}</TableCell>
                          <TableCell>RM {order.total.toFixed(2)}</TableCell>
                          <TableCell>
                            <Button 
                              size="small" 
                              variant="outlined"
                              onClick={(e) => {
                                e.stopPropagation();
                                handleSelectOrder(order.id);
                              }}
                            >
                              View
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))
                    )}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </Paper>
        </Grid>
        
        {/* Right side - Order details */}
        <Grid item xs={12} md={5}>
          <Paper sx={{ p: 2, position: 'sticky', top: 88 }}>
            {selectedOrderData?.data ? (
              <>
                <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
                  <Typography variant="h6">
                    Order #{selectedOrderData.data.orderNumber}
                  </Typography>
                  <Box>
                    {getStatusChip(selectedOrderData.data.status)}
                    {' '}
                    {getPaymentStatusChip(selectedOrderData.data.paymentStatus)}
                  </Box>
                </Box>
                
                <Box sx={{ mb: 2 }}>
                  <Typography variant="body2" color="text.secondary">
                    Type: {selectedOrderData.data.type}
                  </Typography>
                  {selectedOrderData.data.tableId && (
                    <Typography variant="body2" color="text.secondary">
                      Table: {selectedOrderData.data.tableId}
                    </Typography>
                  )}
                  {selectedOrderData.data.customerName && (
                    <Typography variant="body2" color="text.secondary">
                      Customer: {selectedOrderData.data.customerName}
                    </Typography>
                  )}
                  <Typography variant="body2" color="text.secondary">
                    Created: {new Date(selectedOrderData.data.createdAt).toLocaleString()}
                  </Typography>
                </Box>
                
                <Divider sx={{ my: 2 }} />
                
                <Typography variant="subtitle2" gutterBottom>
                  Items
                </Typography>
                
                <List dense>
                  {selectedOrderData.data.items.map((item, index) => (
                    <ListItem key={index}>
                      <ListItemText
                        primary={`${item.quantity}x ${item.name}`}
                        secondary={item.notes}
                      />
                      <Typography variant="body2">
                        RM {(item.quantity * item.unitPrice).toFixed(2)}
                      </Typography>
                    </ListItem>
                  ))}
                </List>
                
                <Divider sx={{ my: 2 }} />
                
                <Box sx={{ mb: 2 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                    <Typography variant="body2">Subtotal</Typography>
                    <Typography variant="body2">
                      RM {selectedOrderData.data.subtotal.toFixed(2)}
                    </Typography>
                  </Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                    <Typography variant="body2" color="text.secondary">
                      Service Charge
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      RM {selectedOrderData.data.serviceCharge.toFixed(2)}
                    </Typography>
                  </Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                    <Typography variant="body2" color="text.secondary">
                      Tax
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      RM {selectedOrderData.data.taxAmount.toFixed(2)}
                    </Typography>
                  </Box>
                  {selectedOrderData.data.discount > 0 && (
                    <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                      <Typography variant="body2" color="text.secondary">
                        Discount
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        -RM {selectedOrderData.data.discount.toFixed(2)}
                      </Typography>
                    </Box>
                  )}
                </Box>
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
                  <Typography variant="subtitle1">Total</Typography>
                  <Typography variant="subtitle1">
                    RM {selectedOrderData.data.total.toFixed(2)}
                  </Typography>
                </Box>
                
                {selectedOrderData.data.payments.length > 0 && (
                  <>
                    <Typography variant="subtitle2" gutterBottom>
                      Payments
                    </Typography>
                    
                    <List dense>
                      {selectedOrderData.data.payments.map((payment, index) => (
                        <ListItem key={index}>
                          <ListItemText
                            primary={payment.method}
                            secondary={new Date(payment.timestamp).toLocaleString()}
                          />
                          <Typography variant="body2">
                            RM {payment.amount.toFixed(2)}
                          </Typography>
                        </ListItem>
                      ))}
                    </List>
                    
                    <Divider sx={{ my: 2 }} />
                  </>
                )}
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                  <Typography variant="subtitle1">
                    {selectedOrderData.data.paymentStatus === PaymentStatus.PAID
                      ? 'Paid'
                      : 'Balance Due'}
                  </Typography>
                  <Typography variant="subtitle1">
                    RM {(
                      selectedOrderData.data.total -
                      selectedOrderData.data.payments.reduce((sum, payment) => sum + payment.amount, 0)
                    ).toFixed(2)}
                  </Typography>
                </Box>
                
                <Box sx={{ mt: 3, display: 'flex', flexWrap: 'wrap', gap: 1 }}>
                  {/* Status update buttons */}
                  {selectedOrderData.data.status === OrderStatus.CONFIRMED && (
                    <Button
                      variant="outlined"
                      onClick={() => handleUpdateStatus(selectedOrderData.data.id, OrderStatus.PREPARING)}
                    >
                      Start Preparing
                    </Button>
                  )}
                  
                  {selectedOrderData.data.status === OrderStatus.PREPARING && (
                    <Button
                      variant="outlined"
                      onClick={() => handleUpdateStatus(selectedOrderData.data.id, OrderStatus.READY)}
                    >
                      Mark as Ready
                    </Button>
                  )}
                  
                  {selectedOrderData.data.status === OrderStatus.READY && (
                    <Button
                      variant="outlined"
                      onClick={() => handleUpdateStatus(selectedOrderData.data.id, OrderStatus.SERVED)}
                    >
                      Mark as Served
                    </Button>
                  )}
                  
                  {/* Payment button */}
                  {selectedOrderData.data.paymentStatus !== PaymentStatus.PAID && (
                    <Button
                      variant="contained"
    
(Content truncated due to size limit. Use line ranges to read in chunks)