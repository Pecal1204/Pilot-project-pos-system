import express from 'express';
import { v4 as uuidv4 } from 'uuid';
import { Order, OrderStatus, OrderType, PaymentStatus } from '@malaysiadish-pos/common';
import { orderService } from '../services/orderService';
import { io } from '../index';

const router = express.Router();

// Get all orders with optional filtering
router.get('/', async (req, res, next) => {
  try {
    const { status, type, tableId, customerId, startDate, endDate, page, limit } = req.query;
    
    const filters: any = {};
    if (status) filters.status = status;
    if (type) filters.type = type;
    if (tableId) filters.tableId = tableId;
    if (customerId) filters.customerId = customerId;
    
    const dateRange = startDate && endDate ? {
      startDate: startDate as string,
      endDate: endDate as string
    } : undefined;
    
    const pagination = page && limit ? {
      page: parseInt(page as string),
      limit: parseInt(limit as string)
    } : undefined;
    
    const orders = await orderService.getOrders(filters, dateRange, pagination);
    res.json({
      success: true,
      data: orders.data,
      meta: orders.meta
    });
  } catch (error) {
    next(error);
  }
});

// Get order by ID
router.get('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const order = await orderService.getOrderById(id);
    
    if (!order) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'ORDER_NOT_FOUND',
          message: `Order with ID ${id} not found`
        }
      });
    }
    
    res.json({
      success: true,
      data: order
    });
  } catch (error) {
    next(error);
  }
});

// Create new order
router.post('/', async (req, res, next) => {
  try {
    const { type, tableId, customerId, customerName, customerPhone, items, notes, createdBy } = req.body;
    
    // Basic validation
    if (!type || !Array.isArray(items) || items.length === 0) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_ORDER_DATA',
          message: 'Order must include type and at least one item'
        }
      });
    }
    
    // Create order object
    const newOrder: Partial<Order> = {
      id: uuidv4(),
      orderNumber: generateOrderNumber(),
      type: type as OrderType,
      status: OrderStatus.DRAFT,
      items: items.map(item => ({
        ...item,
        id: uuidv4()
      })),
      subtotal: calculateSubtotal(items),
      taxAmount: 0, // Will be calculated by service
      serviceCharge: 0, // Will be calculated by service
      discount: 0,
      total: 0, // Will be calculated by service
      payments: [],
      paymentStatus: PaymentStatus.PENDING,
      tableId,
      customerId,
      customerName,
      customerPhone,
      notes,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      createdBy
    };
    
    const createdOrder = await orderService.createOrder(newOrder as Order);
    
    // Emit socket event
    if (tableId) {
      io.to(`table:${tableId}`).emit('order:created', createdOrder);
    }
    io.to(`restaurant:${createdOrder.restaurantId || 'default'}`).emit('order:created', createdOrder);
    
    res.status(201).json({
      success: true,
      data: createdOrder
    });
  } catch (error) {
    next(error);
  }
});

// Update order
router.put('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    const updateData = req.body;
    
    const existingOrder = await orderService.getOrderById(id);
    if (!existingOrder) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'ORDER_NOT_FOUND',
          message: `Order with ID ${id} not found`
        }
      });
    }
    
    // Prevent updating certain fields directly
    delete updateData.id;
    delete updateData.orderNumber;
    delete updateData.createdAt;
    delete updateData.createdBy;
    
    // Update timestamp
    updateData.updatedAt = new Date().toISOString();
    
    // If items are updated, recalculate subtotal
    if (updateData.items) {
      updateData.subtotal = calculateSubtotal(updateData.items);
      // Total will be recalculated by service
    }
    
    const updatedOrder = await orderService.updateOrder(id, updateData);
    
    // Emit socket event
    if (updatedOrder.tableId) {
      io.to(`table:${updatedOrder.tableId}`).emit('order:updated', updatedOrder);
    }
    io.to(`restaurant:${updatedOrder.restaurantId || 'default'}`).emit('order:updated', updatedOrder);
    
    // If status changed to CONFIRMED, notify kitchen
    if (updateData.status === OrderStatus.CONFIRMED && existingOrder.status !== OrderStatus.CONFIRMED) {
      io.to(`kitchen:${updatedOrder.restaurantId || 'default'}`).emit('order:new', updatedOrder);
    }
    
    res.json({
      success: true,
      data: updatedOrder
    });
  } catch (error) {
    next(error);
  }
});

// Update order status
router.patch('/:id/status', async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    
    if (!status || !Object.values(OrderStatus).includes(status as OrderStatus)) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_STATUS',
          message: 'Invalid order status'
        }
      });
    }
    
    const updatedOrder = await orderService.updateOrderStatus(id, status as OrderStatus);
    
    if (!updatedOrder) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'ORDER_NOT_FOUND',
          message: `Order with ID ${id} not found`
        }
      });
    }
    
    // Emit socket event
    if (updatedOrder.tableId) {
      io.to(`table:${updatedOrder.tableId}`).emit('order:status_updated', {
        orderId: id,
        status: status
      });
    }
    io.to(`restaurant:${updatedOrder.restaurantId || 'default'}`).emit('order:status_updated', {
      orderId: id,
      status: status
    });
    
    res.json({
      success: true,
      data: updatedOrder
    });
  } catch (error) {
    next(error);
  }
});

// Add payment to order
router.post('/:id/payments', async (req, res, next) => {
  try {
    const { id } = req.params;
    const { amount, method, transactionId, receivedBy } = req.body;
    
    if (!amount || !method || !receivedBy) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_PAYMENT_DATA',
          message: 'Payment must include amount, method, and receivedBy'
        }
      });
    }
    
    const payment = {
      id: uuidv4(),
      orderId: id,
      amount: parseFloat(amount),
      method,
      status: PaymentStatus.PAID,
      transactionId,
      timestamp: new Date().toISOString(),
      receivedBy
    };
    
    const updatedOrder = await orderService.addPayment(id, payment);
    
    if (!updatedOrder) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'ORDER_NOT_FOUND',
          message: `Order with ID ${id} not found`
        }
      });
    }
    
    // Emit socket event
    if (updatedOrder.tableId) {
      io.to(`table:${updatedOrder.tableId}`).emit('order:payment_added', {
        orderId: id,
        payment
      });
    }
    io.to(`restaurant:${updatedOrder.restaurantId || 'default'}`).emit('order:payment_added', {
      orderId: id,
      payment
    });
    
    res.json({
      success: true,
      data: updatedOrder
    });
  } catch (error) {
    next(error);
  }
});

// Delete order (soft delete)
router.delete('/:id', async (req, res, next) => {
  try {
    const { id } = req.params;
    
    const result = await orderService.deleteOrder(id);
    
    if (!result) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'ORDER_NOT_FOUND',
          message: `Order with ID ${id} not found`
        }
      });
    }
    
    // Emit socket event
    io.to(`restaurant:${result.restaurantId || 'default'}`).emit('order:deleted', { orderId: id });
    
    res.json({
      success: true,
      data: { message: `Order ${id} deleted successfully` }
    });
  } catch (error) {
    next(error);
  }
});

// Helper functions
function generateOrderNumber(): string {
  const date = new Date();
  const year = date.getFullYear().toString().slice(-2);
  const month = (date.getMonth() + 1).toString().padStart(2, '0');
  const day = date.getDate().toString().padStart(2, '0');
  const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
  
  return `ORD-${year}${month}${day}-${random}`;
}

function calculateSubtotal(items: any[]): number {
  return items.reduce((total, item) => {
    const itemTotal = (item.unitPrice * item.quantity) - (item.discount || 0);
    const modifiersTotal = (item.modifiers || []).reduce((sum, mod) => sum + mod.price, 0) * item.quantity;
    return total + itemTotal + modifiersTotal;
  }, 0);
}

export const orderRoutes = router;
