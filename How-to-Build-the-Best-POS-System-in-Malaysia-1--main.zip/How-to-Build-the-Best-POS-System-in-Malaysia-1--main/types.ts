// Common types for the MalaysiaDish POS system

// ==========================================
// Order Types
// ==========================================

export enum OrderStatus {
  DRAFT = 'DRAFT',
  CONFIRMED = 'CONFIRMED',
  PREPARING = 'PREPARING',
  READY = 'READY',
  SERVED = 'SERVED',
  COMPLETED = 'COMPLETED',
  CANCELLED = 'CANCELLED'
}

export enum OrderType {
  DINE_IN = 'DINE_IN',
  TAKEAWAY = 'TAKEAWAY',
  DELIVERY = 'DELIVERY',
  ONLINE = 'ONLINE'
}

export enum PaymentStatus {
  PENDING = 'PENDING',
  PARTIAL = 'PARTIAL',
  PAID = 'PAID',
  REFUNDED = 'REFUNDED',
  FAILED = 'FAILED'
}

export enum PaymentMethod {
  CASH = 'CASH',
  CREDIT_CARD = 'CREDIT_CARD',
  DEBIT_CARD = 'DEBIT_CARD',
  TOUCH_N_GO = 'TOUCH_N_GO',
  GRABPAY = 'GRABPAY',
  BOOST = 'BOOST',
  SHOPEEPAY = 'SHOPEEPAY',
  FAVEPAY = 'FAVEPAY',
  DUITNOW_QR = 'DUITNOW_QR',
  LOYALTY_POINTS = 'LOYALTY_POINTS',
  GIFT_CARD = 'GIFT_CARD',
  SPLIT = 'SPLIT'
}

export interface OrderItem {
  id: string;
  productId: string;
  name: string;
  quantity: number;
  unitPrice: number;
  discount: number;
  subtotal: number;
  notes?: string;
  modifiers: OrderItemModifier[];
  status: OrderItemStatus;
}

export enum OrderItemStatus {
  PENDING = 'PENDING',
  IN_PROGRESS = 'IN_PROGRESS',
  READY = 'READY',
  SERVED = 'SERVED',
  CANCELLED = 'CANCELLED'
}

export interface OrderItemModifier {
  id: string;
  name: string;
  price: number;
}

export interface Payment {
  id: string;
  orderId: string;
  amount: number;
  method: PaymentMethod;
  status: PaymentStatus;
  transactionId?: string;
  timestamp: string;
  receivedBy: string;
}

export interface Order {
  id: string;
  orderNumber: string;
  type: OrderType;
  status: OrderStatus;
  items: OrderItem[];
  subtotal: number;
  taxAmount: number;
  serviceCharge: number;
  discount: number;
  total: number;
  payments: Payment[];
  paymentStatus: PaymentStatus;
  tableId?: string;
  customerId?: string;
  customerName?: string;
  customerPhone?: string;
  notes?: string;
  createdAt: string;
  updatedAt: string;
  createdBy: string;
}

// ==========================================
// Product Types
// ==========================================

export enum ProductCategory {
  FOOD = 'FOOD',
  BEVERAGE = 'BEVERAGE',
  DESSERT = 'DESSERT',
  COMBO = 'COMBO',
  OTHER = 'OTHER'
}

export enum ProductStatus {
  ACTIVE = 'ACTIVE',
  OUT_OF_STOCK = 'OUT_OF_STOCK',
  DISCONTINUED = 'DISCONTINUED'
}

export interface ProductModifierOption {
  id: string;
  name: string;
  price: number;
  isDefault: boolean;
}

export interface ProductModifierGroup {
  id: string;
  name: string;
  required: boolean;
  multiSelect: boolean;
  minSelect: number;
  maxSelect: number;
  options: ProductModifierOption[];
}

export interface Product {
  id: string;
  name: string;
  description: string;
  category: ProductCategory;
  price: number;
  discountedPrice?: number;
  imageUrl?: string;
  status: ProductStatus;
  modifierGroups: ProductModifierGroup[];
  tags: string[];
  allergens: string[];
  isRecommended: boolean;
  isNew: boolean;
  createdAt: string;
  updatedAt: string;
}

// ==========================================
// Table Types
// ==========================================

export enum TableStatus {
  AVAILABLE = 'AVAILABLE',
  OCCUPIED = 'OCCUPIED',
  RESERVED = 'RESERVED',
  DIRTY = 'DIRTY',
  MAINTENANCE = 'MAINTENANCE'
}

export interface Table {
  id: string;
  number: string;
  capacity: number;
  status: TableStatus;
  currentOrderId?: string;
  section: string;
  positionX: number;
  positionY: number;
}

// ==========================================
// User Types
// ==========================================

export enum UserRole {
  ADMIN = 'ADMIN',
  MANAGER = 'MANAGER',
  CASHIER = 'CASHIER',
  WAITER = 'WAITER',
  KITCHEN = 'KITCHEN',
  CUSTOMER = 'CUSTOMER'
}

export interface User {
  id: string;
  username: string;
  fullName: string;
  role: UserRole;
  email?: string;
  phone?: string;
  isActive: boolean;
  lastLogin?: string;
  createdAt: string;
}

// ==========================================
// Customer Types
// ==========================================

export interface Customer {
  id: string;
  name: string;
  phone?: string;
  email?: string;
  loyaltyPoints: number;
  loyaltyTier: string;
  birthdate?: string;
  preferences?: Record<string, any>;
  lastVisit?: string;
  totalSpent: number;
  visitCount: number;
  createdAt: string;
  updatedAt: string;
}

// ==========================================
// E-Invoice Types
// ==========================================

export enum InvoiceStatus {
  DRAFT = 'DRAFT',
  ISSUED = 'ISSUED',
  SUBMITTED = 'SUBMITTED',
  VALIDATED = 'VALIDATED',
  REJECTED = 'REJECTED',
  CANCELLED = 'CANCELLED'
}

export interface EInvoice {
  id: string;
  invoiceNumber: string;
  orderId: string;
  customerInfo: {
    name: string;
    address?: string;
    taxId?: string;
    email?: string;
    phone?: string;
  };
  businessInfo: {
    name: string;
    address: string;
    taxId: string;
    email: string;
    phone: string;
  };
  items: {
    description: string;
    quantity: number;
    unitPrice: number;
    discount: number;
    subtotal: number;
    taxRate: number;
    taxAmount: number;
  }[];
  subtotal: number;
  taxAmount: number;
  serviceCharge: number;
  discount: number;
  total: number;
  paymentMethod: string;
  status: InvoiceStatus;
  issueDate: string;
  dueDate?: string;
  notes?: string;
  submissionId?: string;
  validationStatus?: string;
  validationMessage?: string;
  createdAt: string;
  updatedAt: string;
}

// ==========================================
// API Response Types
// ==========================================

export interface ApiResponse<T> {
  success: boolean;
  data?: T;
  error?: {
    code: string;
    message: string;
    details?: any;
  };
  meta?: {
    page?: number;
    limit?: number;
    total?: number;
    totalPages?: number;
  };
}

// ==========================================
// Utility Types
// ==========================================

export interface Pagination {
  page: number;
  limit: number;
}

export interface DateRange {
  startDate: string;
  endDate: string;
}
