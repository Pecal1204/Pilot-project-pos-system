import express from 'express';
import { v4 as uuidv4 } from 'uuid';
import { PaymentMethod, BiometricAuthMethod, PaymentStatus } from '@malaysiadish-pos/common';
import { orderService } from '../services/orderService';

const router = express.Router();

// Process payment
router.post('/process', async (req, res, next) => {
  try {
    const { 
      orderId, 
      amount, 
      method, 
      cardDetails,
      qrDetails,
      biometricAuth,
      deviceId
    } = req.body;
    
    if (!orderId || !amount || !method) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_PAYMENT_REQUEST',
          message: 'Order ID, amount, and payment method are required'
        }
      });
    }
    
    // Get order details to verify amount
    const order = await orderService.getOrderById(orderId);
    
    if (!order) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'ORDER_NOT_FOUND',
          message: `Order with ID ${orderId} not found`
        }
      });
    }
    
    // Calculate remaining amount to be paid
    const totalPaid = order.payments.reduce((sum, payment) => sum + payment.amount, 0);
    const remainingAmount = order.total - totalPaid;
    
    if (amount > remainingAmount) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'PAYMENT_AMOUNT_EXCEEDS_REMAINING',
          message: `Payment amount ${amount} exceeds remaining amount ${remainingAmount}`
        }
      });
    }
    
    // Process payment based on method
    let paymentResult;
    
    switch (method) {
      case PaymentMethod.CASH:
        paymentResult = await processCashPayment(amount);
        break;
      case PaymentMethod.CREDIT_CARD:
      case PaymentMethod.DEBIT_CARD:
        if (!cardDetails) {
          return res.status(400).json({
            success: false,
            error: {
              code: 'MISSING_CARD_DETAILS',
              message: 'Card details are required for card payments'
            }
          });
        }
        paymentResult = await processCardPayment(amount, method, cardDetails, biometricAuth);
        break;
      case PaymentMethod.TOUCH_N_GO:
      case PaymentMethod.GRABPAY:
      case PaymentMethod.BOOST:
      case PaymentMethod.SHOPEEPAY:
      case PaymentMethod.DUITNOW_QR:
      case PaymentMethod.MAYBANK_QR:
      case PaymentMethod.ALIPAY:
      case PaymentMethod.WECHAT_PAY:
        if (!qrDetails) {
          return res.status(400).json({
            success: false,
            error: {
              code: 'MISSING_QR_DETAILS',
              message: 'QR details are required for e-wallet payments'
            }
          });
        }
        paymentResult = await processEWalletPayment(amount, method, qrDetails);
        break;
      default:
        return res.status(400).json({
          success: false,
          error: {
            code: 'UNSUPPORTED_PAYMENT_METHOD',
            message: `Payment method ${method} is not supported`
          }
        });
    }
    
    if (!paymentResult.success) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'PAYMENT_PROCESSING_FAILED',
          message: paymentResult.errorMessage
        }
      });
    }
    
    // Add payment to order
    const payment = {
      id: uuidv4(),
      amount,
      method,
      receivedBy: req.body.userId || 'unknown',
      timestamp: new Date().toISOString(),
      transactionId: paymentResult.transactionId,
      status: PaymentStatus.COMPLETED,
      details: {
        ...paymentResult.details
      }
    };
    
    const updatedOrder = await orderService.addPayment(orderId, payment);
    
    res.json({
      success: true,
      data: {
        payment,
        order: updatedOrder
      }
    });
  } catch (error) {
    next(error);
  }
});

// Get payment device status
router.get('/device-status', (req, res) => {
  // In a real implementation, this would check the actual payment device status
  // For demo purposes, we'll simulate a connected device
  res.json({
    success: true,
    data: {
      status: 'connected',
      deviceId: 'TERM-001',
      batteryLevel: 95,
      firmwareVersion: '2.3.1',
      lastSyncTime: new Date().toISOString()
    }
  });
});

// Verify biometric authentication
router.post('/biometric-verify', (req, res) => {
  const { method, biometricData } = req.body;
  
  if (!method || !biometricData) {
    return res.status(400).json({
      success: false,
      error: {
        code: 'INVALID_BIOMETRIC_REQUEST',
        message: 'Biometric method and data are required'
      }
    });
  }
  
  // In a real implementation, this would verify the biometric data
  // For demo purposes, we'll simulate a successful verification
  const isVerified = Math.random() > 0.1; // 90% success rate
  
  if (isVerified) {
    res.json({
      success: true,
      data: {
        verified: true,
        method,
        timestamp: new Date().toISOString()
      }
    });
  } else {
    res.status(401).json({
      success: false,
      error: {
        code: 'BIOMETRIC_VERIFICATION_FAILED',
        message: 'Biometric verification failed'
      }
    });
  }
});

// Generate QR code for payment
router.post('/generate-qr', async (req, res, next) => {
  try {
    const { orderId, amount, method } = req.body;
    
    if (!orderId || !amount || !method) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_QR_REQUEST',
          message: 'Order ID, amount, and payment method are required'
        }
      });
    }
    
    // In a real implementation, this would generate a QR code for the specified payment method
    // For demo purposes, we'll simulate a QR code generation
    const qrData = {
      orderId,
      amount,
      method,
      merchantId: 'MALAYSIADISH-001',
      timestamp: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 15 * 60 * 1000).toISOString(), // 15 minutes expiry
      reference: `REF-${Math.floor(Math.random() * 1000000).toString().padStart(6, '0')}`
    };
    
    // In a real implementation, this would be an actual QR code image or data
    const qrCode = `data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAQAAAAEAAQMAAABmvDolAAAABlBMVEX///8AAABVwtN+AAACT0lEQVR42uyYMY7jMAxFCRRapMgRfAQdwUfQ0XkEH8FH0BFUuEiRQCCZkSVbMztZYFGkWKfxi/7nL1Lk5+fn5+fn5+fn5+fn9x+dqmf+dmb/MbOvs89/6B5gK7Cj2VFtNVu5HdWOZkezo9oRYEXtaHYUO6oNsKPa0WwHO6od1XawHeyodjTbwY5qR7Md7Kh2NNvBjmpHsx3sqHY028GOakez4+TT7Nt2nHyafduOk0+zb9tx8mn2bTtOPs2+bcfJp9m37Tj5NPu2HSefZt+24+TT7Nt2nHyafduOk0+zb9tx8mn2bTtOPs2+bcfJp9m37Tj5NPu2HSefZt+24+TT7Nt2nHyafduOk0+zb9tx8mn2bTtOPs2+bcfJp9m37Tj5NPu2HSefZt+24+TT7Nt2nHyafduOk0+zb9tx8mn2bTtOPs2+bcfJp9m37Tj5NPu2HSefZt+24+TT7Nt2nHyafduOk0+zb9tx8mn2bTtOPs2+bcfJp9m37Tj5NPu2HSefZt+24+TT7Nt2nHyafduOk0+zb9tx8mn2bTtOPs2+bcfJp9m37Tj5NPu2HSefZt+24+TT7Nt2nHyafduOk0+zb9tx8mn2bTtOPs2+bcfJp9m37Tj5NPu2HSefZt+24+TT7Nt2nHyafduOk0+zb9tx8mn2bTtOPs2+bcfJp9m37Tj5NPu2HSefZt+24+TT7Nt2nHyafduOk0+zb9tx8mn2bTtOPs2+bcfJp9m37Tj5NPu2HSefZt+24+TT7Nt2nHyafduOk0+zb9tx8mn2bTtOPs2+bcfJp9m37Tj5NPu2HSefZt+2/wLvmYVSRZXmzAAAAABJRU5ErkJggg==`;
    
    res.json({
      success: true,
      data: {
        qrCode,
        qrData
      }
    });
  } catch (error) {
    next(error);
  }
});

// Check payment status (for QR code payments)
router.get('/status/:referenceId', (req, res) => {
  const { referenceId } = req.params;
  
  // In a real implementation, this would check the actual payment status
  // For demo purposes, we'll simulate a payment status
  const statuses = ['pending', 'completed', 'failed'];
  const randomStatus = statuses[Math.floor(Math.random() * statuses.length)];
  
  res.json({
    success: true,
    data: {
      referenceId,
      status: randomStatus,
      timestamp: new Date().toISOString()
    }
  });
});

// Refund payment
router.post('/refund', async (req, res, next) => {
  try {
    const { orderId, paymentId, amount, reason } = req.body;
    
    if (!orderId || !paymentId || !amount) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_REFUND_REQUEST',
          message: 'Order ID, payment ID, and amount are required'
        }
      });
    }
    
    // Get order details
    const order = await orderService.getOrderById(orderId);
    
    if (!order) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'ORDER_NOT_FOUND',
          message: `Order with ID ${orderId} not found`
        }
      });
    }
    
    // Find payment
    const payment = order.payments.find(p => p.id === paymentId);
    
    if (!payment) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'PAYMENT_NOT_FOUND',
          message: `Payment with ID ${paymentId} not found`
        }
      });
    }
    
    if (amount > payment.amount) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'REFUND_AMOUNT_EXCEEDS_PAYMENT',
          message: `Refund amount ${amount} exceeds payment amount ${payment.amount}`
        }
      });
    }
    
    // In a real implementation, this would process the refund with the payment provider
    // For demo purposes, we'll simulate a successful refund
    const refundResult = {
      success: true,
      transactionId: `REF-${Math.floor(Math.random() * 1000000).toString().padStart(6, '0')}`,
      timestamp: new Date().toISOString()
    };
    
    // Update payment status
    const updatedOrder = await orderService.updatePaymentStatus(
      orderId, 
      paymentId, 
      PaymentStatus.REFUNDED,
      {
        refundAmount: amount,
        refundReason: reason,
        refundTransactionId: refundResult.transactionId,
        refundTimestamp: refundResult.timestamp
      }
    );
    
    res.json({
      success: true,
      data: {
        refund: {
          amount,
          transactionId: refundResult.transactionId,
          timestamp: refundResult.timestamp
        },
        order: updatedOrder
      }
    });
  } catch (error) {
    next(error);
  }
});

// Mock payment processing functions
async function processCashPayment(amount) {
  // Cash payments are always successful
  return {
    success: true,
    transactionId: `CASH-${Math.floor(Math.random() * 1000000).toString().padStart(6, '0')}`,
    details: {
      cashReceived: amount,
      changeGiven: 0
    }
  };
}

async function processCardPayment(amount, method, cardDetails, biometricAuth) {
  // Validate card details (in a real implementation, this would be more comprehensive)
  if (!cardDetails.last4Digits) {
    return {
      success: false,
      errorMessage: 'Invalid card details'
    };
  }
  
  // Check if biometric authentication is required and provided
  if (cardDetails.requiresBiometric && !biometricAuth) {
    return {
      success: false,
      errorMessage: 'Biometric authentication required'
    };
  }
  
  // In a real implementation, this would process the card payment with a payment gateway
  // For demo purposes, we'll simulate a successful payment
  const isSuccessful = Math.random() > 0.1; // 90% success rate
  
  if (isSuccessful) {
    return {
      success: true,
      transactionId: `CARD-${Math.floor(Math.random() * 1000000).toString().padStart(6, '0')}`,
      details: {
        cardType: cardDetails.cardType,
        last4Digits: cardDetails.last4Digits,
        authCode: Math.floor(Math.random() * 1000000).toString().padStart(6, '0'),
        isContactless: cardDetails.isContactless || false,
        isEMV: cardDetails.isEMV || true,
        biometricVerified: biometricAuth ? true : false
      }
    };
  } else {
    return {
      success: false,
      errorMessage: 'Card payment declined'
    };
  }
}

async function processEWalletPayment(amount, method, qrDetails) {
  // Validate QR details
  if (!qrDetails.referenceId) {
    return {
      success: false,
      errorMessage: 'Invalid QR details'
    };
  }
  
  // In a real implementation, this would process the e-wallet payment with a payment gateway
  // For demo purposes, we'll simulate a successful payment
  const isSuccessful = Math.random() > 0.1; // 90% success rate
  
  if (isSuccessful) {
    return {
      success: true,
      transactionId: `${method}-${Math.floor(Math.random() * 1000000).toString().padStart(6, '0')}`,
      details: {
        walletType: method,
        referenceId: qrDetails.referenceId,
        customerAccount: qrDetails.customerAccount || 'Unknown'
      }
    };
  } else {
    return {
      success: false,
      errorMessage: 'E-wallet payment failed'
    };
  }
}

export const paymentRoutes = router;
