import { createContext, useContext, useState, ReactNode } from 'react';

// Define types for our mock data
export interface MenuItem {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  imageUrl?: string;
  tags?: string[];
}

export interface CartItem extends MenuItem {
  quantity: number;
}

export interface Order {
  id: string;
  items: CartItem[];
  total: number;
  status: 'pending' | 'preparing' | 'ready' | 'completed';
  timestamp: string;
  tableNumber?: string;
  customerName?: string;
  customerPhone?: string;
}

export interface Table {
  id: string;
  number: string;
  seats: number;
  status: 'available' | 'occupied' | 'reserved';
  currentOrderId?: string;
}

export interface AIRecommendation {
  id: string;
  productId: string;
  productName: string;
  recommendationType: 'upsell' | 'cross-sell' | 'popular' | 'personalized';
  confidence: number;
  reason: string;
}

// Define the context type
interface POSContextType {
  // Menu state
  menuItems: MenuItem[];
  
  // Cart state
  cart: CartItem[];
  addToCart: (item: MenuItem) => void;
  removeFromCart: (itemId: string) => void;
  updateCartItemQuantity: (itemId: string, quantity: number) => void;
  clearCart: () => void;
  
  // Orders state
  orders: Order[];
  createOrder: (tableNumber?: string, customerName?: string, customerPhone?: string) => Order;
  updateOrderStatus: (orderId: string, status: Order['status']) => void;
  
  // Tables state
  tables: Table[];
  updateTableStatus: (tableId: string, status: Table['status'], orderId?: string) => void;
  
  // AI recommendations
  recommendations: AIRecommendation[];
  
  // E-Invoice state
  generateEInvoice: (orderId: string) => { invoiceNumber: string; url: string };
  
  // Payment state
  processPayment: (orderId: string, method: string, amount: number) => { success: boolean; transactionId: string };
  
  // Self-service state
  selfServiceMode: boolean;
  toggleSelfServiceMode: () => void;
  
  // WhatsApp receipt
  sendWhatsAppReceipt: (orderId: string, phoneNumber: string) => { success: boolean; messageId: string };
}

// Create the context with a default value
const POSContext = createContext<POSContextType | undefined>(undefined);

// Sample menu items
const sampleMenuItems: MenuItem[] = [
  {
    id: 'item1',
    name: 'Nasi Lemak Special',
    description: 'Fragrant coconut rice with sambal, fried chicken, egg, cucumber, and anchovies',
    price: 15.90,
    category: 'Main Dish',
    imageUrl: '/images/nasi-lemak.jpg',
    tags: ['popular', 'spicy']
  },
  {
    id: 'item2',
    name: 'Roti Canai',
    description: 'Flaky flatbread served with curry dipping sauce',
    price: 3.50,
    category: 'Appetizer',
    imageUrl: '/images/roti-canai.jpg',
    tags: ['popular', 'vegetarian']
  },
  {
    id: 'item3',
    name: 'Teh Tarik',
    description: 'Pulled milk tea, a Malaysian favorite',
    price: 4.50,
    category: 'Beverage',
    imageUrl: '/images/teh-tarik.jpg',
    tags: ['popular', 'hot']
  },
  {
    id: 'item4',
    name: 'Satay Ayam',
    description: 'Grilled chicken skewers with peanut sauce',
    price: 12.90,
    category: 'Appetizer',
    imageUrl: '/images/satay-ayam.jpg',
    tags: ['popular', 'grilled']
  },
  {
    id: 'item5',
    name: 'Char Kway Teow',
    description: 'Stir-fried rice noodles with prawns, bean sprouts, and chives',
    price: 14.50,
    category: 'Main Dish',
    imageUrl: '/images/char-kway-teow.jpg',
    tags: ['spicy', 'seafood']
  },
  {
    id: 'item6',
    name: 'Cendol',
    description: 'Iced dessert with green rice flour jelly, coconut milk, and palm sugar',
    price: 7.90,
    category: 'Dessert',
    imageUrl: '/images/cendol.jpg',
    tags: ['sweet', 'cold']
  },
  {
    id: 'item7',
    name: 'Mee Goreng Mamak',
    description: 'Spicy fried noodles with tofu, potatoes, and vegetables',
    price: 13.90,
    category: 'Main Dish',
    imageUrl: '/images/mee-goreng.jpg',
    tags: ['spicy', 'vegetarian']
  },
  {
    id: 'item8',
    name: 'Iced Lemon Tea',
    description: 'Refreshing iced tea with fresh lemon',
    price: 5.50,
    category: 'Beverage',
    imageUrl: '/images/iced-lemon-tea.jpg',
    tags: ['cold', 'refreshing']
  }
];

// Sample tables
const sampleTables: Table[] = [
  { id: 'table1', number: '1', seats: 2, status: 'available' },
  { id: 'table2', number: '2', seats: 2, status: 'occupied', currentOrderId: 'order1' },
  { id: 'table3', number: '3', seats: 4, status: 'available' },
  { id: 'table4', number: '4', seats: 4, status: 'reserved' },
  { id: 'table5', number: '5', seats: 6, status: 'available' },
  { id: 'table6', number: '6', seats: 6, status: 'available' },
];

// Sample recommendations
const sampleRecommendations: AIRecommendation[] = [
  {
    id: 'rec1',
    productId: 'item1',
    productName: 'Nasi Lemak Special',
    recommendationType: 'popular',
    confidence: 0.95,
    reason: 'Most ordered item this month'
  },
  {
    id: 'rec2',
    productId: 'item3',
    productName: 'Teh Tarik',
    recommendationType: 'cross-sell',
    confidence: 0.85,
    reason: 'Frequently ordered with Nasi Lemak'
  },
  {
    id: 'rec3',
    productId: 'item6',
    productName: 'Cendol',
    recommendationType: 'upsell',
    confidence: 0.75,
    reason: 'Popular dessert pairing'
  }
];

// Sample orders
const sampleOrders: Order[] = [
  {
    id: 'order1',
    items: [
      { ...sampleMenuItems[0], quantity: 1 },
      { ...sampleMenuItems[2], quantity: 2 }
    ],
    total: 15.90 + (4.50 * 2),
    status: 'preparing',
    timestamp: new Date().toISOString(),
    tableNumber: '2'
  }
];

// Provider component
export const POSProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  // State
  const [menuItems] = useState<MenuItem[]>(sampleMenuItems);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [orders, setOrders] = useState<Order[]>(sampleOrders);
  const [tables, setTables] = useState<Table[]>(sampleTables);
  const [recommendations] = useState<AIRecommendation[]>(sampleRecommendations);
  const [selfServiceMode, setSelfServiceMode] = useState(false);
  
  // Cart functions
  const addToCart = (item: MenuItem) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(cartItem => cartItem.id === item.id);
      
      if (existingItem) {
        return prevCart.map(cartItem => 
          cartItem.id === item.id 
            ? { ...cartItem, quantity: cartItem.quantity + 1 } 
            : cartItem
        );
      } else {
        return [...prevCart, { ...item, quantity: 1 }];
      }
    });
  };
  
  const removeFromCart = (itemId: string) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(cartItem => cartItem.id === itemId);
      
      if (existingItem && existingItem.quantity > 1) {
        return prevCart.map(cartItem => 
          cartItem.id === itemId 
            ? { ...cartItem, quantity: cartItem.quantity - 1 } 
            : cartItem
        );
      } else {
        return prevCart.filter(cartItem => cartItem.id !== itemId);
      }
    });
  };
  
  const updateCartItemQuantity = (itemId: string, quantity: number) => {
    if (quantity <= 0) {
      setCart(prevCart => prevCart.filter(cartItem => cartItem.id !== itemId));
    } else {
      setCart(prevCart => 
        prevCart.map(cartItem => 
          cartItem.id === itemId 
            ? { ...cartItem, quantity } 
            : cartItem
        )
      );
    }
  };
  
  const clearCart = () => {
    setCart([]);
  };
  
  // Order functions
  const createOrder = (tableNumber?: string, customerName?: string, customerPhone?: string): Order => {
    const total = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    
    const newOrder: Order = {
      id: `order${orders.length + 1}`,
      items: [...cart],
      total,
      status: 'pending',
      timestamp: new Date().toISOString(),
      tableNumber,
      customerName,
      customerPhone
    };
    
    setOrders(prevOrders => [...prevOrders, newOrder]);
    clearCart();
    
    // If table number is provided, update table status
    if (tableNumber) {
      const tableId = tables.find(table => table.number === tableNumber)?.id;
      if (tableId) {
        updateTableStatus(tableId, 'occupied', newOrder.id);
      }
    }
    
    return newOrder;
  };
  
  const updateOrderStatus = (orderId: string, status: Order['status']) => {
    setOrders(prevOrders => 
      prevOrders.map(order => 
        order.id === orderId 
          ? { ...order, status } 
          : order
      )
    );
    
    // If order is completed, update table status
    if (status === 'completed') {
      const order = orders.find(o => o.id === orderId);
      if (order?.tableNumber) {
        const tableId = tables.find(table => table.number === order.tableNumber)?.id;
        if (tableId) {
          updateTableStatus(tableId, 'available');
        }
      }
    }
  };
  
  // Table functions
  const updateTableStatus = (tableId: string, status: Table['status'], orderId?: string) => {
    setTables(prevTables => 
      prevTables.map(table => 
        table.id === tableId 
          ? { ...table, status, currentOrderId: orderId } 
          : table
      )
    );
  };
  
  // E-Invoice function
  const generateEInvoice = (orderId: string) => {
    // In a real implementation, this would call the backend API
    return {
      invoiceNumber: `INV-${Math.floor(Math.random() * 10000)}`,
      url: `/invoices/${orderId}.pdf`
    };
  };
  
  // Payment function
  const processPayment = (_orderId: string, _method: string, _amount: number) => {
    // In a real implementation, this would call the backend API
    return {
      success: true,
      transactionId: `TXN-${Math.floor(Math.random() * 10000)}`
    };
  };
  
  // Self-service function
  const toggleSelfServiceMode = () => {
    setSelfServiceMode(prev => !prev);
  };
  
  // WhatsApp receipt function
  const sendWhatsAppReceipt = (_orderId: string, _phoneNumber: string) => {
    // In a real implementation, this would call the backend API
    return {
      success: true,
      messageId: `MSG-${Math.floor(Math.random() * 10000)}`
    };
  };
  
  // Context value
  const value: POSContextType = {
    menuItems,
    cart,
    addToCart,
    removeFromCart,
    updateCartItemQuantity,
    clearCart,
    orders,
    createOrder,
    updateOrderStatus,
    tables,
    updateTableStatus,
    recommendations,
    generateEInvoice,
    processPayment,
    selfServiceMode,
    toggleSelfServiceMode,
    sendWhatsAppReceipt
  };
  
  return <POSContext.Provider value={value}>{children}</POSContext.Provider>;
};

// Custom hook to use the POS context
export const usePOS = () => {
  const context = useContext(POSContext);
  if (context === undefined) {
    throw new Error('usePOS must be used within a POSProvider');
  }
  return context;
};
