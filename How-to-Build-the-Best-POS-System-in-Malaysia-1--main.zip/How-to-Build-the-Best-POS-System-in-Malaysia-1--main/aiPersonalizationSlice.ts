import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { RootState } from '../../store';
import { api } from '../../services/api';

interface AIRecommendation {
  id: string;
  productId: string;
  productName: string;
  recommendationType: 'upsell' | 'cross-sell' | 'popular' | 'personalized';
  confidence: number;
  reason: string;
  createdAt: string;
}

interface CustomerPreference {
  id: string;
  customerId: string;
  category: string;
  item: string;
  frequency: number;
  lastOrdered: string;
}

interface AIPersonalizationState {
  recommendations: AIRecommendation[];
  customerPreferences: CustomerPreference[];
  isLoadingRecommendations: boolean;
  recommendationError: string | null;
  aiEnabled: boolean;
  personalizationLevel: 'off' | 'basic' | 'advanced';
  currentCustomerId: string | null;
}

const initialState: AIPersonalizationState = {
  recommendations: [],
  customerPreferences: [],
  isLoadingRecommendations: false,
  recommendationError: null,
  aiEnabled: true,
  personalizationLevel: 'advanced',
  currentCustomerId: null
};

export const aiPersonalizationSlice = createSlice({
  name: 'aiPersonalization',
  initialState,
  reducers: {
    setRecommendations: (state, action: PayloadAction<AIRecommendation[]>) => {
      state.recommendations = action.payload;
    },
    setCustomerPreferences: (state, action: PayloadAction<CustomerPreference[]>) => {
      state.customerPreferences = action.payload;
    },
    setAIEnabled: (state, action: PayloadAction<boolean>) => {
      state.aiEnabled = action.payload;
    },
    setPersonalizationLevel: (state, action: PayloadAction<'off' | 'basic' | 'advanced'>) => {
      state.personalizationLevel = action.payload;
    },
    setCurrentCustomerId: (state, action: PayloadAction<string | null>) => {
      state.currentCustomerId = action.payload;
    },
    clearRecommendations: (state) => {
      state.recommendations = [];
    }
  },
  extraReducers: (builder) => {
    builder
      .addMatcher(
        api.endpoints.getRecommendations?.matchPending,
        (state) => {
          state.isLoadingRecommendations = true;
          state.recommendationError = null;
        }
      )
      .addMatcher(
        api.endpoints.getRecommendations?.matchFulfilled,
        (state, { payload }) => {
          state.isLoadingRecommendations = false;
          state.recommendations = payload.data;
        }
      )
      .addMatcher(
        api.endpoints.getRecommendations?.matchRejected,
        (state, { error }) => {
          state.isLoadingRecommendations = false;
          state.recommendationError = error.message || 'Failed to load recommendations';
        }
      );
  }
});

export const {
  setRecommendations,
  setCustomerPreferences,
  setAIEnabled,
  setPersonalizationLevel,
  setCurrentCustomerId,
  clearRecommendations
} = aiPersonalizationSlice.actions;

// Selectors
export const selectRecommendations = (state: RootState) => state.aiPersonalization.recommendations;
export const selectCustomerPreferences = (state: RootState) => state.aiPersonalization.customerPreferences;
export const selectIsLoadingRecommendations = (state: RootState) => state.aiPersonalization.isLoadingRecommendations;
export const selectRecommendationError = (state: RootState) => state.aiPersonalization.recommendationError;
export const selectAIEnabled = (state: RootState) => state.aiPersonalization.aiEnabled;
export const selectPersonalizationLevel = (state: RootState) => state.aiPersonalization.personalizationLevel;
export const selectCurrentCustomerId = (state: RootState) => state.aiPersonalization.currentCustomerId;

export default aiPersonalizationSlice.reducer;
