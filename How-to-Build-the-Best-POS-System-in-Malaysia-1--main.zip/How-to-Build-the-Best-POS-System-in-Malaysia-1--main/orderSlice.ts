import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { Order, OrderItem, OrderStatus, PaymentStatus } from '@malaysiadish-pos/common';
import { RootState } from '../../store';
import { api } from '../../services/api';

interface OrderState {
  activeOrder: Order | null;
  draftItems: OrderItem[];
  isOrderModalOpen: boolean;
  isPaymentModalOpen: boolean;
  selectedOrderId: string | null;
  orderFilter: {
    status: OrderStatus | 'ALL';
    tableId: string | null;
  };
}

const initialState: OrderState = {
  activeOrder: null,
  draftItems: [],
  isOrderModalOpen: false,
  isPaymentModalOpen: false,
  selectedOrderId: null,
  orderFilter: {
    status: 'ALL',
    tableId: null,
  },
};

export const orderSlice = createSlice({
  name: 'order',
  initialState,
  reducers: {
    setActiveOrder: (state, action: PayloadAction<Order | null>) => {
      state.activeOrder = action.payload;
    },
    addDraftItem: (state, action: PayloadAction<OrderItem>) => {
      // Check if item already exists in draft
      const existingItemIndex = state.draftItems.findIndex(
        item => item.productId === action.payload.productId &&
               JSON.stringify(item.modifiers) === JSON.stringify(action.payload.modifiers)
      );
      
      if (existingItemIndex >= 0) {
        // Increment quantity if item exists
        state.draftItems[existingItemIndex].quantity += action.payload.quantity;
        state.draftItems[existingItemIndex].subtotal = 
          state.draftItems[existingItemIndex].quantity * 
          state.draftItems[existingItemIndex].unitPrice;
      } else {
        // Add new item
        state.draftItems.push(action.payload);
      }
    },
    updateDraftItem: (state, action: PayloadAction<{ index: number; item: Partial<OrderItem> }>) => {
      const { index, item } = action.payload;
      if (index >= 0 && index < state.draftItems.length) {
        state.draftItems[index] = {
          ...state.draftItems[index],
          ...item,
        };
        
        // Recalculate subtotal if quantity or price changed
        if (item.quantity !== undefined || item.unitPrice !== undefined) {
          state.draftItems[index].subtotal = 
            state.draftItems[index].quantity * 
            state.draftItems[index].unitPrice;
        }
      }
    },
    removeDraftItem: (state, action: PayloadAction<number>) => {
      state.draftItems = state.draftItems.filter((_, index) => index !== action.payload);
    },
    clearDraftItems: (state) => {
      state.draftItems = [];
    },
    setOrderModalOpen: (state, action: PayloadAction<boolean>) => {
      state.isOrderModalOpen = action.payload;
    },
    setPaymentModalOpen: (state, action: PayloadAction<boolean>) => {
      state.isPaymentModalOpen = action.payload;
    },
    setSelectedOrderId: (state, action: PayloadAction<string | null>) => {
      state.selectedOrderId = action.payload;
    },
    setOrderFilter: (state, action: PayloadAction<Partial<OrderState['orderFilter']>>) => {
      state.orderFilter = {
        ...state.orderFilter,
        ...action.payload,
      };
    },
  },
  extraReducers: (builder) => {
    builder
      // When an order is successfully fetched, set it as active order
      .addMatcher(
        api.endpoints.getOrderById.matchFulfilled,
        (state, { payload }) => {
          if (payload.data && state.selectedOrderId === payload.data.id) {
            state.activeOrder = payload.data;
          }
        }
      )
      // When a new order is created, clear draft items
      .addMatcher(
        api.endpoints.createOrder.matchFulfilled,
        (state) => {
          state.draftItems = [];
          state.isOrderModalOpen = false;
        }
      )
      // When order status is updated, update active order if it matches
      .addMatcher(
        api.endpoints.updateOrderStatus.matchFulfilled,
        (state, { payload }) => {
          if (payload.data && state.activeOrder && state.activeOrder.id === payload.data.id) {
            state.activeOrder = payload.data;
          }
        }
      )
      // When payment is added, update active order if it matches
      .addMatcher(
        api.endpoints.addPayment.matchFulfilled,
        (state, { payload }) => {
          if (payload.data && state.activeOrder && state.activeOrder.id === payload.data.id) {
            state.activeOrder = payload.data;
            state.isPaymentModalOpen = false;
          }
        }
      );
  },
});

export const {
  setActiveOrder,
  addDraftItem,
  updateDraftItem,
  removeDraftItem,
  clearDraftItems,
  setOrderModalOpen,
  setPaymentModalOpen,
  setSelectedOrderId,
  setOrderFilter,
} = orderSlice.actions;

// Selectors
export const selectActiveOrder = (state: RootState) => state.orders.activeOrder;
export const selectDraftItems = (state: RootState) => state.orders.draftItems;
export const selectIsOrderModalOpen = (state: RootState) => state.orders.isOrderModalOpen;
export const selectIsPaymentModalOpen = (state: RootState) => state.orders.isPaymentModalOpen;
export const selectSelectedOrderId = (state: RootState) => state.orders.selectedOrderId;
export const selectOrderFilter = (state: RootState) => state.orders.orderFilter;

// Calculate draft total
export const selectDraftTotal = (state: RootState) => {
  const subtotal = state.orders.draftItems.reduce((sum, item) => sum + item.subtotal, 0);
  const taxRate = 0.06; // 6% SST
  const serviceChargeRate = 0.10; // 10% service charge
  
  const taxAmount = subtotal * taxRate;
  const serviceCharge = subtotal * serviceChargeRate;
  const total = subtotal + taxAmount + serviceCharge;
  
  return {
    subtotal,
    taxAmount,
    serviceCharge,
    total,
  };
};

// Check if active order is paid
export const selectIsOrderPaid = (state: RootState) => {
  return state.orders.activeOrder?.paymentStatus === PaymentStatus.PAID;
};

export default orderSlice.reducer;
