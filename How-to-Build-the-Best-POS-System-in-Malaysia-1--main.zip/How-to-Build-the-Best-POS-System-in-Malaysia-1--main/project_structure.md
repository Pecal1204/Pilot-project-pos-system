# MalaysiaDish POS: Project Structure

## Project Organization

```
malaysiadish_pos/
├── packages/                  # Monorepo packages
│   ├── common/                # Shared utilities, types, and components
│   ├── pos-terminal/          # Main POS terminal application
│   ├── self-service-kiosk/    # Self-service kiosk interface
│   ├── management-dashboard/  # Admin and management dashboard
│   ├── kitchen-display/       # Kitchen display system
│   └── api-server/            # Backend API and services
├── services/                  # Microservices
│   ├── order-service/         # Order management service
│   ├── inventory-service/     # Inventory management service
│   ├── customer-service/      # Customer management service
│   ├── payment-service/       # Payment processing service
│   ├── e-invoice-service/     # E-invoicing service (IRBM compliant)
│   ├── ai-service/            # AI personalization and analytics
│   └── communication-service/ # Customer communication service
├── database/                  # Database scripts and migrations
│   ├── schema/                # Database schema definitions
│   ├── migrations/            # Database migrations
│   └── seed-data/             # Seed data for development
├── docker/                    # Docker configuration
│   ├── development/           # Development environment
│   └── demo/                  # Demo environment
├── docs/                      # Documentation
│   ├── api/                   # API documentation
│   ├── user-guides/           # User guides
│   └── development/           # Development guides
└── scripts/                   # Build and utility scripts
```

## Key Components

### Frontend Applications

1. **POS Terminal Application**
   - Main interface for staff to process orders
   - Table management
   - Order entry and modification
   - Payment processing
   - Receipt generation

2. **Self-Service Kiosk Interface**
   - Customer-facing ordering interface
   - Accessibility features
   - Multilingual support
   - Payment integration

3. **Management Dashboard**
   - Sales and performance analytics
   - Inventory management
   - Staff management
   - Configuration settings

4. **Kitchen Display System**
   - Order queue management
   - Preparation status tracking
   - Timing and alerts

### Backend Services

1. **Order Service**
   - Order creation and management
   - Order status tracking
   - Order history

2. **Inventory Service**
   - Stock level tracking
   - Ingredient management
   - Predictive inventory

3. **Customer Service**
   - Customer profiles
   - Loyalty program
   - Preferences management

4. **Payment Service**
   - Payment processing
   - Transaction management
   - Security and compliance

5. **E-Invoice Service**
   - IRBM-compliant e-invoicing
   - UBL 2.1 standard implementation
   - Digital signatures

6. **AI Service**
   - Customer personalization
   - Predictive analytics
   - Recommendation engine

7. **Communication Service**
   - WhatsApp integration
   - Notification management
   - Feedback collection

## Development Workflow

1. **Local Development**
   - Docker Compose for local environment
   - Hot reloading for frontend applications
   - Automated API documentation

2. **Testing Strategy**
   - Unit tests for individual components
   - Integration tests for service interactions
   - End-to-end tests for critical flows

3. **Deployment Process**
   - Build and package applications
   - Deploy containers
   - Database migrations
   - Configuration management

## Initial Development Focus

For the initial prototype, we will focus on:

1. Core POS terminal functionality
2. Basic inventory management
3. E-invoicing compliance
4. Simple payment processing
5. Essential customer management

Advanced features like AI personalization, omnichannel integration, and WhatsApp communication will be implemented progressively after the core functionality is stable.
