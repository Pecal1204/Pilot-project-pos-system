import { Order, EInvoice, InvoiceStatus } from '@malaysiadish-pos/common';
import { v4 as uuidv4 } from 'uuid';
import { XMLBuilder, XMLParser } from 'fast-xml-parser';

// Mock database for demo purposes
let invoices: EInvoice[] = [];

// Business information (would be configurable in a real system)
const businessInfo = {
  name: 'MalaysiaDish Restaurant',
  address: '123 Jalan Sultan, 50000 Kuala Lumpur',
  taxId: 'MY12345678',
  email: 'info@malaysiadish.com',
  phone: '+60 3 1234 5678',
};

export const eInvoiceService = {
  // Get all invoices with optional filtering
  async getInvoices(
    filters: Partial<EInvoice> = {},
    dateRange?: { startDate: string; endDate: string },
    pagination?: { page: number; limit: number }
  ): Promise<{ data: EInvoice[]; meta?: { page: number; limit: number; total: number; totalPages: number } }> {
    let filteredInvoices = [...invoices];
    
    // Apply filters
    if (filters.status) {
      filteredInvoices = filteredInvoices.filter(invoice => invoice.status === filters.status);
    }
    
    if (filters['customerInfo.taxId']) {
      filteredInvoices = filteredInvoices.filter(invoice => 
        invoice.customerInfo.taxId === filters['customerInfo.taxId']
      );
    }
    
    // Apply date range filter
    if (dateRange) {
      const startDate = new Date(dateRange.startDate).getTime();
      const endDate = new Date(dateRange.endDate).getTime();
      
      filteredInvoices = filteredInvoices.filter(invoice => {
        const invoiceDate = new Date(invoice.issueDate).getTime();
        return invoiceDate >= startDate && invoiceDate <= endDate;
      });
    }
    
    // Sort by issue date (newest first)
    filteredInvoices.sort((a, b) => new Date(b.issueDate).getTime() - new Date(a.issueDate).getTime());
    
    // Apply pagination
    if (pagination) {
      const { page, limit } = pagination;
      const startIndex = (page - 1) * limit;
      const endIndex = page * limit;
      
      const paginatedInvoices = filteredInvoices.slice(startIndex, endIndex);
      
      return {
        data: paginatedInvoices,
        meta: {
          page,
          limit,
          total: filteredInvoices.length,
          totalPages: Math.ceil(filteredInvoices.length / limit)
        }
      };
    }
    
    return { data: filteredInvoices };
  },
  
  // Get invoice by ID
  async getInvoiceById(id: string): Promise<EInvoice | null> {
    const invoice = invoices.find(invoice => invoice.id === id);
    return invoice || null;
  },
  
  // Generate invoice from order
  async generateInvoice(order: Order, customerInfo?: any): Promise<EInvoice> {
    const invoiceNumber = this.generateInvoiceNumber();
    const issueDate = new Date().toISOString();
    
    // Map order items to invoice items
    const items = order.items.map(item => ({
      description: item.name,
      quantity: item.quantity,
      unitPrice: item.unitPrice,
      discount: item.discount || 0,
      subtotal: item.subtotal,
      taxRate: 0.06, // 6% SST
      taxAmount: item.subtotal * 0.06
    }));
    
    // Create invoice
    const invoice: EInvoice = {
      id: uuidv4(),
      invoiceNumber,
      orderId: order.id,
      customerInfo: customerInfo || {
        name: order.customerName || 'Walk-in Customer',
        address: '',
        taxId: '',
        email: '',
        phone: order.customerPhone || ''
      },
      businessInfo,
      items,
      subtotal: order.subtotal,
      taxAmount: order.taxAmount,
      serviceCharge: order.serviceCharge,
      discount: order.discount || 0,
      total: order.total,
      paymentMethod: order.payments.length > 0 ? order.payments[0].method : 'UNKNOWN',
      status: InvoiceStatus.DRAFT,
      issueDate,
      notes: order.notes || '',
      createdAt: issueDate,
      updatedAt: issueDate
    };
    
    // Save invoice
    invoices.push(invoice);
    
    return invoice;
  },
  
  // Submit invoice to IRBM (simulated)
  async submitInvoice(id: string): Promise<EInvoice | null> {
    const invoiceIndex = invoices.findIndex(invoice => invoice.id === id);
    
    if (invoiceIndex === -1) {
      return null;
    }
    
    // In a real implementation, this would call the IRBM API
    // For demo purposes, we'll simulate a successful submission
    
    const submissionId = `SUB-${Math.floor(Math.random() * 1000000).toString().padStart(6, '0')}`;
    
    // Update invoice
    invoices[invoiceIndex] = {
      ...invoices[invoiceIndex],
      status: InvoiceStatus.SUBMITTED,
      submissionId,
      updatedAt: new Date().toISOString()
    };
    
    // Simulate validation delay (in a real system, this would be handled by a webhook or polling)
    setTimeout(() => {
      if (invoiceIndex < invoices.length) {
        invoices[invoiceIndex] = {
          ...invoices[invoiceIndex],
          status: InvoiceStatus.VALIDATED,
          validationStatus: 'SUCCESS',
          validationMessage: 'Invoice validated successfully',
          updatedAt: new Date().toISOString()
        };
      }
    }, 5000);
    
    return invoices[invoiceIndex];
  },
  
  // Update invoice status
  async updateInvoiceStatus(id: string, status: InvoiceStatus): Promise<EInvoice | null> {
    const invoiceIndex = invoices.findIndex(invoice => invoice.id === id);
    
    if (invoiceIndex === -1) {
      return null;
    }
    
    // Update status and timestamp
    invoices[invoiceIndex] = {
      ...invoices[invoiceIndex],
      status,
      updatedAt: new Date().toISOString()
    };
    
    return invoices[invoiceIndex];
  },
  
  // Cancel invoice
  async cancelInvoice(id: string, reason: string): Promise<EInvoice | null> {
    const invoiceIndex = invoices.findIndex(invoice => invoice.id === id);
    
    if (invoiceIndex === -1) {
      return null;
    }
    
    // Update invoice
    invoices[invoiceIndex] = {
      ...invoices[invoiceIndex],
      status: InvoiceStatus.CANCELLED,
      notes: `${invoices[invoiceIndex].notes}\nCancellation reason: ${reason}`,
      updatedAt: new Date().toISOString()
    };
    
    return invoices[invoiceIndex];
  },
  
  // Format invoice as XML or JSON (UBL 2.1 compliant)
  async formatInvoice(invoice: EInvoice, format: 'xml' | 'json'): Promise<string> {
    // Convert invoice to UBL 2.1 format
    const ublInvoice = this.convertToUBL(invoice);
    
    if (format === 'xml') {
      // Convert to XML
      const builder = new XMLBuilder({
        attributeNamePrefix: '@_',
        ignoreAttributes: false,
        format: true,
        indentBy: '  ',
        suppressEmptyNodes: true
      });
      
      return builder.build(ublInvoice);
    } else {
      // Return JSON string
      return JSON.stringify(ublInvoice, null, 2);
    }
  },
  
  // Helper methods
  generateInvoiceNumber(): string {
    const date = new Date();
    const year = date.getFullYear().toString();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
    
    return `INV-${year}${month}${day}-${random}`;
  },
  
  // Convert invoice to UBL 2.1 format
  convertToUBL(invoice: EInvoice): any {
    // This is a simplified version of UBL 2.1 format
    // In a real implementation, this would be more comprehensive
    return {
      'Invoice': {
        '@_xmlns': 'urn:oasis:names:specification:ubl:schema:xsd:Invoice-2',
        '@_xmlns:cac': 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2',
        '@_xmlns:cbc': 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2',
        'cbc:UBLVersionID': '2.1',
        'cbc:ID': invoice.invoiceNumber,
        'cbc:IssueDate': invoice.issueDate.split('T')[0], // YYYY-MM-DD
        'cbc:InvoiceTypeCode': '380', // Commercial invoice
        'cbc:DocumentCurrencyCode': 'MYR',
        'cac:AccountingSupplierParty': {
          'cac:Party': {
            'cac:PartyName': {
              'cbc:Name': invoice.businessInfo.name
            },
            'cac:PostalAddress': {
              'cbc:StreetName': invoice.businessInfo.address,
              'cbc:CountrySubentity': 'Kuala Lumpur',
              'cac:Country': {
                'cbc:IdentificationCode': 'MY'
              }
            },
            'cac:PartyTaxScheme': {
              'cbc:CompanyID': invoice.businessInfo.taxId,
              'cac:TaxScheme': {
                'cbc:ID': 'SST'
              }
            },
            'cac:Contact': {
              'cbc:Telephone': invoice.businessInfo.phone,
              'cbc:ElectronicMail': invoice.businessInfo.email
            }
          }
        },
        'cac:AccountingCustomerParty': {
          'cac:Party': {
            'cac:PartyName': {
              'cbc:Name': invoice.customerInfo.name
            },
            ...(invoice.customerInfo.address ? {
              'cac:PostalAddress': {
                'cbc:StreetName': invoice.customerInfo.address,
                'cac:Country': {
                  'cbc:IdentificationCode': 'MY'
                }
              }
            } : {}),
            ...(invoice.customerInfo.taxId ? {
              'cac:PartyTaxScheme': {
                'cbc:CompanyID': invoice.customerInfo.taxId,
                'cac:TaxScheme': {
                  'cbc:ID': 'SST'
                }
              }
            } : {}),
            'cac:Contact': {
              ...(invoice.customerInfo.phone ? { 'cbc:Telephone': invoice.customerInfo.phone } : {}),
              ...(invoice.customerInfo.email ? { 'cbc:ElectronicMail': invoice.customerInfo.email } : {})
            }
          }
        },
        'cac:PaymentMeans': {
          'cbc:PaymentMeansCode': '1', // Cash
          'cbc:PaymentMeansDescription': invoice.paymentMethod
        },
        'cac:TaxTotal': {
          'cbc:TaxAmount': {
            '@_currencyID': 'MYR',
            '#text': invoice.taxAmount.toFixed(2)
          },
          'cac:TaxSubtotal': {
            'cbc:TaxableAmount': {
              '@_currencyID': 'MYR',
              '#text': invoice.subtotal.toFixed(2)
            },
            'cbc:TaxAmount': {
              '@_currencyID': 'MYR',
              '#text': invoice.taxAmount.toFixed(2)
            },
            'cac:TaxCategory': {
              'cbc:Percent': '6',
              'cac:TaxScheme': {
                'cbc:ID': 'SST'
              }
            }
          }
        },
        'cac:LegalMonetaryTotal': {
          'cbc:LineExtensionAmount': {
            '@_currencyID': 'MYR',
            '#text': invoice.subtotal.toFixed(2)
          },
          'cbc:TaxExclusiveAmount': {
            '@_currencyID': 'MYR',
            '#text': invoice.subtotal.toFixed(2)
          },
          'cbc:TaxInclusiveAmount': {
            '@_currencyID': 'MYR',
            '#text': (invoice.subtotal + invoice.taxAmount).toFixed(2)
          },
          'cbc:AllowanceTotalAmount': {
            '@_currencyID': 'MYR',
            '#text': invoice.discount.toFixed(2)
          },
          'cbc:ChargeTotalAmount': {
            '@_currencyID': 'MYR',
            '#text': invoice.serviceCharge.toFixed(2)
          },
          'cbc:PayableAmount': {
            '@_currencyID': 'MYR',
            '#text': invoice.total.toFixed(2)
          }
        },
        'cac:InvoiceLine': invoice.items.map((item, index) => ({
          'cbc:ID': (index + 1).toString(),
          'cbc:InvoicedQuantity': item.quantity.toString(),
          'cbc:LineExtensionAmount': {
            '@_currencyID': 'MYR',
            '#text': item.subtotal.toFixed(2)
          },
          'cac:Item': {
            'cbc:Name': item.description,
            'cac:ClassifiedTaxCategory': {
              'cbc:Percent': '6',
              'cac:TaxScheme': {
                'cbc:ID': 'SST'
              }
            }
          },
          'cac:Price': {
            'cbc:PriceAmount': {
              '@_currencyID': 'MYR',
              '#text': item.unitPrice.toFixed(2)
            },
            'cbc:BaseQuantity': '1'
          }
        }))
      }
    };
  }
};
