import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { RootState } from '../../store';
import { api } from '../../services/api';

interface InventoryItem {
  id: string;
  productId: string;
  productName: string;
  currentStock: number;
  minimumStock: number;
  optimumStock: number;
  unitOfMeasure: string;
  costPrice: number;
  expiryDate?: string;
  lastRestockDate: string;
  locationCode: string;
  status: 'in_stock' | 'low_stock' | 'out_of_stock' | 'expired';
}

interface PredictiveInventoryData {
  productId: string;
  productName: string;
  predictedDemand: number;
  confidenceScore: number;
  suggestedOrderQuantity: number;
  seasonalFactors: {
    factor: string;
    impact: number;
  }[];
  historicalTrend: {
    period: string;
    demand: number;
  }[];
}

interface InventoryAlert {
  id: string;
  type: 'low_stock' | 'out_of_stock' | 'expiring_soon' | 'expired' | 'price_change' | 'demand_spike';
  productId: string;
  productName: string;
  message: string;
  severity: 'info' | 'warning' | 'critical';
  timestamp: string;
  isRead: boolean;
}

interface InventoryManagementState {
  inventoryItems: InventoryItem[];
  predictiveData: PredictiveInventoryData[];
  alerts: InventoryAlert[];
  isLoadingInventory: boolean;
  inventoryError: string | null;
  aiPredictionEnabled: boolean;
  lastInventorySync: string | null;
  selectedInventoryItemId: string | null;
}

const initialState: InventoryManagementState = {
  inventoryItems: [],
  predictiveData: [],
  alerts: [],
  isLoadingInventory: false,
  inventoryError: null,
  aiPredictionEnabled: true,
  lastInventorySync: null,
  selectedInventoryItemId: null
};

export const inventoryManagementSlice = createSlice({
  name: 'inventoryManagement',
  initialState,
  reducers: {
    setInventoryItems: (state, action: PayloadAction<InventoryItem[]>) => {
      state.inventoryItems = action.payload;
    },
    setPredictiveData: (state, action: PayloadAction<PredictiveInventoryData[]>) => {
      state.predictiveData = action.payload;
    },
    setInventoryAlerts: (state, action: PayloadAction<InventoryAlert[]>) => {
      state.alerts = action.payload;
    },
    addInventoryAlert: (state, action: PayloadAction<InventoryAlert>) => {
      state.alerts.unshift(action.payload);
    },
    markAlertAsRead: (state, action: PayloadAction<string>) => {
      const alert = state.alerts.find(a => a.id === action.payload);
      if (alert) {
        alert.isRead = true;
      }
    },
    markAllAlertsAsRead: (state) => {
      state.alerts.forEach(alert => {
        alert.isRead = true;
      });
    },
    setAIPredictionEnabled: (state, action: PayloadAction<boolean>) => {
      state.aiPredictionEnabled = action.payload;
    },
    setLastInventorySync: (state, action: PayloadAction<string>) => {
      state.lastInventorySync = action.payload;
    },
    setSelectedInventoryItemId: (state, action: PayloadAction<string | null>) => {
      state.selectedInventoryItemId = action.payload;
    },
    updateInventoryItem: (state, action: PayloadAction<Partial<InventoryItem> & { id: string }>) => {
      const index = state.inventoryItems.findIndex(item => item.id === action.payload.id);
      if (index !== -1) {
        state.inventoryItems[index] = {
          ...state.inventoryItems[index],
          ...action.payload
        };
      }
    }
  },
  extraReducers: (builder) => {
    builder
      .addMatcher(
        api.endpoints.getInventoryItems?.matchPending,
        (state) => {
          state.isLoadingInventory = true;
          state.inventoryError = null;
        }
      )
      .addMatcher(
        api.endpoints.getInventoryItems?.matchFulfilled,
        (state, { payload }) => {
          state.isLoadingInventory = false;
          state.inventoryItems = payload.data;
          state.lastInventorySync = new Date().toISOString();
        }
      )
      .addMatcher(
        api.endpoints.getInventoryItems?.matchRejected,
        (state, { error }) => {
          state.isLoadingInventory = false;
          state.inventoryError = error.message || 'Failed to load inventory data';
        }
      )
      .addMatcher(
        api.endpoints.getPredictiveInventoryData?.matchFulfilled,
        (state, { payload }) => {
          state.predictiveData = payload.data;
        }
      )
      .addMatcher(
        api.endpoints.getInventoryAlerts?.matchFulfilled,
        (state, { payload }) => {
          state.alerts = payload.data;
        }
      );
  }
});

export const {
  setInventoryItems,
  setPredictiveData,
  setInventoryAlerts,
  addInventoryAlert,
  markAlertAsRead,
  markAllAlertsAsRead,
  setAIPredictionEnabled,
  setLastInventorySync,
  setSelectedInventoryItemId,
  updateInventoryItem
} = inventoryManagementSlice.actions;

// Selectors
export const selectInventoryItems = (state: RootState) => state.inventoryManagement.inventoryItems;
export const selectPredictiveData = (state: RootState) => state.inventoryManagement.predictiveData;
export const selectInventoryAlerts = (state: RootState) => state.inventoryManagement.alerts;
export const selectUnreadAlertCount = (state: RootState) => 
  state.inventoryManagement.alerts.filter(a => !a.isRead).length;
export const selectIsLoadingInventory = (state: RootState) => state.inventoryManagement.isLoadingInventory;
export const selectInventoryError = (state: RootState) => state.inventoryManagement.inventoryError;
export const selectAIPredictionEnabled = (state: RootState) => state.inventoryManagement.aiPredictionEnabled;
export const selectLastInventorySync = (state: RootState) => state.inventoryManagement.lastInventorySync;
export const selectSelectedInventoryItemId = (state: RootState) => state.inventoryManagement.selectedInventoryItemId;
export const selectSelectedInventoryItem = (state: RootState) => {
  const id = state.inventoryManagement.selectedInventoryItemId;
  return id ? state.inventoryManagement.inventoryItems.find(item => item.id === id) || null : null;
};
export const selectLowStockItems = (state: RootState) => 
  state.inventoryManagement.inventoryItems.filter(item => item.status === 'low_stock');
export const selectOutOfStockItems = (state: RootState) => 
  state.inventoryManagement.inventoryItems.filter(item => item.status === 'out_of_stock');

export default inventoryManagementSlice.reducer;
