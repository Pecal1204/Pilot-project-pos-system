# E-Invoicing Implementation Design

This document outlines the technical design for implementing IRBM-compliant e-invoicing in the MalaysiaDish POS system to meet the July 1, 2025 mandatory requirement.

## 1. Architecture Overview

The e-invoicing implementation will follow a modular design with these key components:

1. **E-Invoice Generator** - Creates UBL 2.1 compliant invoices in XML/JSON format
2. **IRBM API Client** - Handles communication with MyInvois Portal/API
3. **Validation Service** - Validates invoices before submission
4. **Secure Storage** - Manages encrypted storage of e-invoices
5. **Audit Trail** - Tracks all invoice operations for compliance

## 2. UBL 2.1 Standard Implementation

### Data Structure
The e-invoice will implement the Universal Business Language (UBL) 2.1 standard with the following structure:

```typescript
interface EInvoice {
  // Invoice Header
  invoiceNumber: string;
  issueDate: string;
  dueDate: string;
  invoiceTypeCode: string;
  documentCurrencyCode: string;
  
  // Supplier Information
  accountingSupplierParty: {
    registrationName: string;
    companyID: string;
    taxRegistrationID: string;
    address: Address;
    contact: Contact;
  };
  
  // Customer Information
  accountingCustomerParty: {
    registrationName: string;
    companyID?: string;
    taxRegistrationID?: string;
    address?: Address;
    contact?: Contact;
  };
  
  // Tax Information
  taxTotal: {
    taxAmount: number;
    taxSubtotals: TaxSubtotal[];
  };
  
  // Line Items
  invoiceLines: InvoiceLine[];
  
  // Payment Information
  paymentMeans: PaymentMeans;
  
  // Totals
  legalMonetaryTotal: {
    lineExtensionAmount: number;
    taxExclusiveAmount: number;
    taxInclusiveAmount: number;
    payableAmount: number;
  };
  
  // Digital Signature
  signature?: Signature;
}
```

### XML/JSON Generation
The system will support both XML and JSON formats as required by IRBM:

1. **XML Generation**
   - Use XML libraries to create properly formatted UBL 2.1 documents
   - Include proper namespaces and schema references
   - Implement XML Digital Signature for document integrity

2. **JSON Generation**
   - Create JSON structure following UBL 2.1 mapping
   - Ensure all required fields are included
   - Implement JSON Web Signature for document integrity

## 3. MyInvois Portal/API Integration

### Authentication
The system will implement secure authentication with the IRBM MyInvois API:

1. **API Credentials Management**
   - Secure storage of API keys/credentials
   - Automatic token refresh mechanism
   - Role-based access to credential management

2. **Request Signing**
   - Implementation of required request signing mechanism
   - Timestamp validation
   - Nonce generation for request uniqueness

### API Client
The API client will handle all communication with IRBM systems:

1. **Endpoints**
   - Invoice submission endpoint
   - Validation status endpoint
   - Invoice retrieval endpoint
   - Error handling endpoint

2. **Request/Response Handling**
   - Proper formatting of API requests
   - Response parsing and error handling
   - Retry logic for failed requests
   - Rate limiting compliance

## 4. Real-time Validation System

### Pre-submission Validation
Before submitting to IRBM, invoices will be validated locally:

1. **Schema Validation**
   - Validate against UBL 2.1 schema
   - Check for required fields
   - Validate data types and formats

2. **Business Rule Validation**
   - Check for logical consistency
   - Validate tax calculations
   - Ensure compliance with Malaysian tax rules

### Post-submission Validation
After submission to IRBM, the system will:

1. **Process Validation Responses**
   - Handle success/failure responses
   - Store validation results
   - Update invoice status

2. **Error Correction Workflow**
   - Identify validation errors
   - Guide users through correction process
   - Resubmit corrected invoices

## 5. Secure Storage Solution

### Encryption
All e-invoices will be securely stored with:

1. **Data Encryption**
   - AES-256 encryption for stored invoices
   - Secure key management
   - Encrypted transmission

2. **Access Control**
   - Role-based access to invoice data
   - Audit logging for all access attempts
   - Time-limited access tokens

### Retention Policy
The system will implement retention policies compliant with Malaysian regulations:

1. **Retention Period**
   - Store invoices for the required 7-year period
   - Implement secure archiving for older invoices
   - Provide retrieval mechanism for audits

2. **Data Integrity**
   - Regular integrity checks
   - Backup and recovery procedures
   - Tamper detection mechanisms

## 6. Integration with POS Workflow

### Invoice Generation Triggers
E-invoices will be generated at these points:

1. **Checkout Completion**
   - Generate e-invoice upon payment confirmation
   - Submit to IRBM in real-time
   - Provide customer with compliant receipt

2. **Batch Processing**
   - Support for batch generation of invoices
   - Scheduled submission for offline transactions
   - Reconciliation with payment records

### User Interface
The POS interface will be enhanced with:

1. **Invoice Management**
   - View and search e-invoices
   - Check submission status
   - Resend/correct failed submissions

2. **Reporting**
   - E-invoice compliance reporting
   - Submission success rate monitoring
   - Error tracking and analysis

## 7. Implementation Timeline

The e-invoicing implementation will follow this timeline:

1. **Phase 1 (Week 1-2)**
   - UBL 2.1 data structure implementation
   - Basic invoice generation

2. **Phase 2 (Week 3-4)**
   - MyInvois API client development
   - Authentication implementation

3. **Phase 3 (Week 5-6)**
   - Validation system implementation
   - Error handling and correction workflows

4. **Phase 4 (Week 7-8)**
   - Secure storage implementation
   - UI integration and testing

## 8. Testing Strategy

The implementation will be tested with:

1. **Unit Testing**
   - Test each component in isolation
   - Validate data structure compliance
   - Verify calculation accuracy

2. **Integration Testing**
   - Test API communication
   - Validate end-to-end workflows
   - Verify error handling

3. **Compliance Testing**
   - Validate against IRBM test environment
   - Verify UBL 2.1 compliance
   - Test digital signature verification

This design ensures full compliance with Malaysia's mandatory e-invoicing requirements while maintaining security, reliability, and user experience.
