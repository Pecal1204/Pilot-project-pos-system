import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { RootState } from '../../store';

interface UIState {
  sidebarOpen: boolean;
  darkMode: boolean;
  activeDialog: string | null;
  notifications: {
    id: string;
    type: 'info' | 'success' | 'warning' | 'error';
    message: string;
    read: boolean;
  }[];
  loading: {
    [key: string]: boolean;
  };
  errors: {
    [key: string]: string | null;
  };
}

const initialState: UIState = {
  sidebarOpen: true,
  darkMode: false,
  activeDialog: null,
  notifications: [],
  loading: {},
  errors: {},
};

export const uiSlice = createSlice({
  name: 'ui',
  initialState,
  reducers: {
    toggleSidebar: (state) => {
      state.sidebarOpen = !state.sidebarOpen;
    },
    setSidebarOpen: (state, action: PayloadAction<boolean>) => {
      state.sidebarOpen = action.payload;
    },
    toggleDarkMode: (state) => {
      state.darkMode = !state.darkMode;
    },
    setDarkMode: (state, action: PayloadAction<boolean>) => {
      state.darkMode = action.payload;
    },
    openDialog: (state, action: PayloadAction<string>) => {
      state.activeDialog = action.payload;
    },
    closeDialog: (state) => {
      state.activeDialog = null;
    },
    addNotification: (state, action: PayloadAction<Omit<UIState['notifications'][0], 'id' | 'read'>>) => {
      state.notifications.push({
        id: Date.now().toString(),
        ...action.payload,
        read: false,
      });
    },
    markNotificationAsRead: (state, action: PayloadAction<string>) => {
      const notification = state.notifications.find(n => n.id === action.payload);
      if (notification) {
        notification.read = true;
      }
    },
    clearNotifications: (state) => {
      state.notifications = [];
    },
    setLoading: (state, action: PayloadAction<{ key: string; isLoading: boolean }>) => {
      state.loading[action.payload.key] = action.payload.isLoading;
    },
    setError: (state, action: PayloadAction<{ key: string; error: string | null }>) => {
      state.errors[action.payload.key] = action.payload.error;
    },
    clearError: (state, action: PayloadAction<string>) => {
      state.errors[action.payload] = null;
    },
    clearAllErrors: (state) => {
      state.errors = {};
    },
  },
});

export const {
  toggleSidebar,
  setSidebarOpen,
  toggleDarkMode,
  setDarkMode,
  openDialog,
  closeDialog,
  addNotification,
  markNotificationAsRead,
  clearNotifications,
  setLoading,
  setError,
  clearError,
  clearAllErrors,
} = uiSlice.actions;

// Selectors
export const selectSidebarOpen = (state: RootState) => state.ui.sidebarOpen;
export const selectDarkMode = (state: RootState) => state.ui.darkMode;
export const selectActiveDialog = (state: RootState) => state.ui.activeDialog;
export const selectNotifications = (state: RootState) => state.ui.notifications;
export const selectUnreadNotificationsCount = (state: RootState) => 
  state.ui.notifications.filter(n => !n.read).length;
export const selectIsLoading = (key: string) => (state: RootState) => 
  !!state.ui.loading[key];
export const selectError = (key: string) => (state: RootState) => 
  state.ui.errors[key];

export default uiSlice.reducer;
