# POS System Project Structure

## Root Directory

```
/
├── frontend/             # Client-facing UI application
├── backend/              # Server application and APIs
├── database/             # Database scripts and migrations
├── docs/                 # Documentation
├── config/               # Configuration files
├── scripts/              # Utility scripts
├── localization/         # Language files
├── tests/                # Test suites
└── README.md             # Project overview
```

## Frontend Structure

```
/frontend/
├── public/               # Static files
│   ├── images/           # Image assets
│   ├── fonts/            # Font files
│   └── icons/            # Icon assets
├── src/
│   ├── components/       # Reusable UI components
│   │   ├── common/       # Shared components
│   │   ├── pos/          # POS-specific components
│   │   ├── admin/        # Admin panel components
│   │   └── reports/      # Reporting components
│   ├── pages/            # Application pages
│   │   ├── login/        # Authentication pages
│   │   ├── pos/          # Main POS interface
│   │   ├── inventory/    # Inventory management
│   │   ├── customers/    # Customer management
│   │   ├── transactions/ # Transaction history
│   │   └── reports/      # Reporting interface
│   ├── hooks/            # Custom React hooks
│   ├── context/          # React context providers
│   ├── services/         # API service integrations
│   ├── utils/            # Utility functions
│   ├── styles/           # Global styles
│   ├── localization/     # Frontend translations
│   └── App.js            # Main application component
├── package.json          # Dependencies
└── README.md             # Frontend documentation
```

## Backend Structure

```
/backend/
├── src/
│   ├── api/              # API routes
│   │   ├── products/     # Product endpoints
│   │   ├── sales/        # Sales endpoints
│   │   ├── users/        # User management endpoints
│   │   ├── customers/    # Customer endpoints
│   │   ├── reports/      # Reporting endpoints
│   │   └── payments/     # Payment processing endpoints
│   ├── controllers/      # Request handlers
│   ├── models/           # Data models
│   ├── services/         # Business logic
│   │   ├── tax/          # Malaysian SST calculation
│   │   ├── receipt/      # Receipt generation
│   │   └── payment/      # Payment gateway integrations
│   ├── middleware/       # Express middleware
│   ├── utils/            # Utility functions
│   ├── config/           # Environment configuration
│   └── server.js         # Main server file
├── package.json          # Dependencies
└── README.md             # Backend documentation
```

## Database Structure

```
/database/
├── migrations/           # Database migration scripts
├── seeds/                # Seed data
├── schemas/              # Database schema definitions
└── README.md             # Database documentation
```

## Localization Files

```
/localization/
├── ms-MY/                # Malay translations
├── en-MY/                # Malaysian English translations
├── zh-MY/                # Chinese translations
└── README.md             # Localization guide
```

## Documentation

```
/docs/
├── api/                  # API documentation
├── user-guide/           # End-user documentation
├── admin-guide/          # Administrator documentation
├── developer-guide/      # Developer documentation
├── malaysian-compliance/ # Compliance documentation
└── payment-integrations/ # Payment gateway integration guides
```

## Configuration

```
/config/
├── app.config.js         # Application configuration
├── database.config.js    # Database configuration
├── payment.config.js     # Payment gateway configuration
└── tax.config.js         # Malaysian tax configuration
```

## Tests

```
/tests/
├── unit/                 # Unit tests
├── integration/          # Integration tests
├── e2e/                  # End-to-end tests
└── fixtures/             # Test data
```

</qodoArtifact>
