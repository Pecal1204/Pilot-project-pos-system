# Malaysian Payment Gateway Integration Guide

## Overview of Malaysian Payment Landscape

Malaysia has a diverse payment ecosystem with various options that a comprehensive POS system should support:

1. **Card Payments**: Credit and debit cards (Visa, Mastercard, MyDebit)
2. **E-Wallets**: Growing rapidly in popularity
3. **QR Payments**: Unified under DuitNow QR
4. **Online Banking**: Direct bank transfers
5. **Buy-Now-Pay-Later (BNPL)**: Emerging payment option

## Major Payment Gateways in Malaysia

### 1. iPay88

**Overview**: One of the most established payment gateways in Malaysia, supporting 100+ payment options.

**Integration Options**:

- RESTful API
- Payment SDK (Android, iOS)
- Hosted payment page

**Key Features**:

- Multi-currency support
- Recurring payment options
- Comprehensive fraud detection
- Transaction status updates via webhook
- Supports almost all Malaysian banks and e-wallets

**Sample Integration Code**:

```javascript
// Server-side code (Node.js example)
const crypto = require('crypto');

// Generate signature for iPay88
function generateSignature(merchantCode, refNo, amount, currency, payload) {
  const data = merchantCode + refNo + amount.replace('.', '') + currency + payload;
  return crypto.createHash('sha256').update(data + merchantKey).digest('hex');
}

// Prepare payment request
function createPaymentRequest(orderDetails) {
  const payload = {
    MerchantCode: process.env.IPAY88_MERCHANT_CODE,
    PaymentId: '2', // Credit card payment
    RefNo: orderDetails.referenceNumber,
    Amount: orderDetails.amount.toFixed(2),
    Currency: 'MYR',
    ProdDesc: orderDetails.description,
    UserName: orderDetails.customerName,
    UserEmail: orderDetails.customerEmail,
    UserContact: orderDetails.customerPhone,
    Remark: orderDetails.remarks,
    Lang: 'UTF-8',
    SignatureType: 'SHA256',
    Signature: '',
    ResponseURL: 'https://your-domain.com/payment/ipay88/response',
    BackendURL: 'https://your-domain.com/payment/ipay88/backend'
  };
  
  payload.Signature = generateSignature(
    payload.MerchantCode, 
    payload.RefNo, 
    payload.Amount, 
    payload.Currency, 
    merchantKey
  );
  
  return payload;
}
```

### 2. GHL eGHL (formerly known as eGHL)

**Overview**: Regional payment gateway with strong presence in Malaysia and Southeast Asia.

**Integration Options**:

- RESTful API
- JavaScript SDK
- Seamless integration options

**Key Features**:

- Wide range of payment methods
- Tokenization for recurring payments
- Robust security features
- Multi-currency support

**Sample Integration Code**:

```javascript
// Server-side code (Node.js example)
const axios = require('axios');
const crypto = require('crypto');

async function initiateEghlPayment(orderDetails) {
  // Prepare payment request
  const paymentData = {
    TransactionType: 'SALE',
    ServiceID: process.env.EGHL_SERVICE_ID,
    PaymentID: orderDetails.referenceNumber,
    OrderNumber: orderDetails.orderNumber,
    PaymentDesc: orderDetails.description,
    MerchantReturnURL: 'https://your-domain.com/payment/eghl/return',
    Amount: orderDetails.amount.toFixed(2),
    CurrencyCode: 'MYR',
    CustIP: orderDetails.customerIp,
    CustName: orderDetails.customerName,
    CustEmail: orderDetails.customerEmail,
    CustPhone: orderDetails.customerPhone,
    MerchantName: 'Your Business Name',
    PageTimeout: 780,
    PymtMethod: 'ANY',
    Language: 'EN'
  };

  // Generate hash
  const stringToHash = paymentData.ServiceID +
    paymentData.PaymentID +
    paymentData.MerchantReturnURL +
    paymentData.Amount +
    paymentData.CurrencyCode;
  
  paymentData.HashValue = crypto
    .createHash('sha256')
    .update(stringToHash + process.env.EGHL_PASSWORD)
    .digest('hex');

  // Send request to eGHL
  const response = await axios.post(
    'https://api.eghl.com/eGHL/api/payment',
    paymentData
  );
  
  return response.data;
}
```

### 3. Senang Pay

**Overview**: Affordable option popular among SMEs and startups.

**Integration Options**:

- RESTful API
- Simple integration

**Key Features**:

- FPX (online banking)
- Credit/debit card processing
- Low barrier to entry
- Simple pricing structure

**Sample Integration Code**:

```javascript
// Frontend code with redirects
function createSenangPayForm(orderDetails) {
  const merchantId = 'YOUR_MERCHANT_ID';
  const secretKey = 'YOUR_SECRET_KEY';
  
  // Create hash
  const hash = CryptoJS.MD5(
    secretKey + 
    orderDetails.orderNumber + 
    orderDetails.amount.toFixed(2) + 
    'MYR'
  ).toString();
  
  // Prepare form data
  const form = document.createElement('form');
  form.method = 'POST';
  form.action = 'https://app.senangpay.my/payment/' + merchantId;
  
  // Add fields
  const fields = {
    'detail': orderDetails.description,
    'amount': orderDetails.amount.toFixed(2),
    'order_id': orderDetails.orderNumber,
    'name': orderDetails.customerName,
    'email': orderDetails.customerEmail,
    'phone': orderDetails.customerPhone,
    'hash': hash
  };
  
  for (const key in fields) {
    const input = document.createElement('input');
    input.type = 'hidden';
    input.name = key;
    input.value = fields[key];
    form.appendChild(input);
  }
  
  document.body.appendChild(form);
  form.submit();
}
```

### 4. MOLPay / Razer Merchant Services

**Overview**: Part of Razer Fintech, comprehensive payment solution with wide adoption.

**Integration Options**:

- RESTful API
- Mobile SDK
- Hosted payment page

**Key Features**:

- Extensive payment options
- Advanced security features
- Cross-border payment capabilities
- Supports Malaysian e-wallets and bank cards

**Sample Integration Code**:

```javascript
// Server-side code (Node.js example)
const crypto = require('crypto');

function generateMolpaySignature(orderData, secretKey) {
  const signatureString = 
    orderData.merchant_id + 
    orderData.order_id + 
    orderData.amount + 
    orderData.currency;
  
  return crypto
    .createHash('md5')
    .update(signatureString + secretKey)
    .digest('hex');
}

function createMolpayPaymentRequest(orderDetails) {
  const orderData = {
    merchant_id: process.env.MOLPAY_MERCHANT_ID,
    order_id: orderDetails.orderNumber,
    amount: orderDetails.amount.toFixed(2),
    currency: 'MYR',
    bill_name: orderDetails.customerName,
    bill_email: orderDetails.customerEmail,
    bill_mobile: orderDetails.customerPhone,
    bill_desc: orderDetails.description,
    country: 'MY',
    vcode: '',
    return_url: 'https://your-domain.com/payment/molpay/return',
    callback_url: 'https://your-domain.com/payment/molpay/callback'
  };
  
  orderData.vcode = generateMolpaySignature(
    orderData, 
    process.env.MOLPAY_SECRET_KEY
  );
  
  return orderData;
}
```

### 5. Revenue Monster

**Overview**: Offers comprehensive payment solutions with strong e-wallet focus.

**Integration Options**:

- RESTful API
- SDK integration
- Unified QR payments

**Key Features**:

- Unified e-wallet platform
- Support for major e-wallets (Touch 'n Go, Boost, GrabPay)
- DuitNow QR integration
- Loyalty program capabilities

**Sample Integration Code**:

```javascript
// Server-side code (Node.js example)
const axios = require('axios');
const crypto = require('crypto');

async function createRevenueMonsterPayment(orderDetails) {
  // Prepare request body
  const requestBody = {
    order: {
      id: orderDetails.orderNumber,
      title: "Payment for Order #" + orderDetails.orderNumber,
      detail: orderDetails.description,
      amount: Math.round(orderDetails.amount * 100), // In cents
      currencyType: "MYR",
      additionalData: JSON.stringify({
        customerName: orderDetails.customerName,
        customerEmail: orderDetails.customerEmail
      })
    },
    customer: {
      userId: orderDetails.customerId,
      email: orderDetails.customerEmail,
      phoneNumber: orderDetails.customerPhone
    },
    method: [], // Leave empty for all methods or specify methods
    type: "WEB_PAYMENT",
    redirectUrl: "https://your-domain.com/payment/callback",
    notifyUrl: "https://your-domain.com/payment/notify",
    layoutVersion: "v2"
  };

  // Generate signature
  const method = "post";
  const uri = "/v3/payment/online";
  const nonceStr = generateRandomString(32);
  const signType = "sha256";
  const timestamp = Math.floor(Date.now() / 1000);
  
  const data = method + uri + timestamp + nonceStr + signType + JSON.stringify(requestBody);
  const signature = crypto
    .createHmac('sha256', process.env.RM_PRIVATE_KEY)
    .update(data)
    .digest('base64');

  // Make API request
  const response = await axios({
    method: 'post',
    url: 'https://open.revenuemonster.my/v3/payment/online',
    headers: {
      'Authorization': 'Bearer ' + accessToken,
      'X-Nonce-Str': nonceStr,
      'X-Signature': signature,
      'X-Timestamp': timestamp,
      'Content-Type': 'application/json'
    },
    data: requestBody
  });

  return response.data;
}

function generateRandomString(length) {
  return crypto.randomBytes(length).toString('hex').slice(0, length);
}
```

## E-Wallet Integration in Malaysia

### Major E-Wallets to Support

1. **Touch 'n Go eWallet**
   - Largest e-wallet in Malaysia
   - Supports DuitNow QR
   - Accessible via major payment gateways

2. **Boost**
   - Popular e-wallet with cashback features
   - Direct API available for large merchants
   - Accessible via iPay88, Revenue Monster

3. **GrabPay**
   - Connected to the Grab ecosystem
   - Popular among Grab users
   - Accessible via multiple payment gateways

4. **MAE by Maybank**
   - Bank-backed e-wallet
   - Integrated with Maybank accounts
   - Supports DuitNow QR

### DuitNow QR Integration

DuitNow QR is Malaysia's unified QR code standard that allows payments across different banks and e-wallets.

**Implementation Approaches**:

1. **Dynamic QR**: Generate unique QR codes for each transaction

   ```javascript
   // Sample code for generating dynamic DuitNow QR via PayNet API
   async function generateDuitNowQR(amount, referenceId) {
     const response = await axios.post(
       'https://api.paynet.my/duitnow/v1/qr/dynamic',
       {
         amount: amount.toFixed(2),
         referenceId: referenceId,
         expiryMinutes: 5,
         merchantName: 'Your Business Name',
         pointOfInitiation: 'DYNAMIC'
       },
       {
         headers: {
           'Authorization': 'Bearer ' + accessToken,
           'Content-Type': 'application/json'
         }
       }
     );
     
     return response.data.qrCode;
   }
   ```

2. **Static QR**: Fixed QR code for your merchant (customer enters amount)
   - Can be printed and displayed at counter
   - Available through DuitNow QR merchant registration

## Considerations for Malaysian Market

1. **SST Handling**: Ensure payment amounts include proper Sales and Service Tax (SST) calculations

2. **Multi-currency Support**: While MYR is primary, consider supporting USD, SGD, and other currencies for tourists

3. **Receipt Requirements**: Malaysian tax authorities require specific receipt information for official receipts

4. **Settlement Times**: Understand the settlement cycles for different payment methods:
   - Card payments: T+1 or T+2 days
   - E-wallets: Varies by provider (1-3 business days)
   - Online banking: Usually T+1

5. **Fees Structure**:
   - Credit cards: 1.5-3% MDR (Merchant Discount Rate)
   - Debit cards: 0.5-1% MDR
   - E-wallets: 1-2% typically
   - FPX (online banking): Fixed fee (RM0.50-RM1.00)

## Implementation Best Practices

1. **Unified Payment API**: Create an abstraction layer in your system that handles different payment gateways through a common interface

2. **Webhook Reliability**: Implement idempotent webhook handling to prevent duplicate processing

3. **Payment Status Reconciliation**: Daily reconciliation of payment statuses with gateway reports

4. **Secure Credential Storage**: Use environment variables or secure vaults for API keys

5. **Comprehensive Logging**: Log all payment attempts, successes, and failures for troubleshooting

6. **Error Handling**: Graceful handling of payment failures with clear customer communication

7. **Testing Environments**: Utilize sandbox environments provided by payment gateways before going live
