import express from 'express';
import { v4 as uuidv4 } from 'uuid';
import { Product, ProductCategory } from '@malaysiadish-pos/common';

const router = express.Router();

// Mock AI service for recommendations and personalization
const aiService = {
  // Get personalized recommendations for a customer
  getPersonalizedRecommendations: (customerId, orderHistory, currentCart) => {
    // In a real implementation, this would use ML models to generate recommendations
    // For demo purposes, we'll return mock recommendations
    return [
      {
        id: uuidv4(),
        productId: 'prod-001',
        productName: 'Nasi Lemak Special',
        recommendationType: 'personalized',
        confidence: 0.89,
        reason: 'Based on previous orders and preferences',
        createdAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        productId: 'prod-015',
        productName: 'Teh Tarik',
        recommendationType: 'personalized',
        confidence: 0.78,
        reason: 'Frequently ordered with current items',
        createdAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        productId: 'prod-008',
        productName: 'Satay Ayam',
        recommendationType: 'personalized',
        confidence: 0.72,
        reason: 'Matches taste profile',
        createdAt: new Date().toISOString()
      }
    ];
  },
  
  // Get popular items based on overall sales
  getPopularItems: () => {
    return [
      {
        id: uuidv4(),
        productId: 'prod-001',
        productName: 'Nasi Lemak Special',
        recommendationType: 'popular',
        confidence: 0.95,
        reason: 'Most ordered item this month',
        createdAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        productId: 'prod-003',
        productName: 'Roti Canai',
        recommendationType: 'popular',
        confidence: 0.92,
        reason: 'Top 3 most ordered items',
        createdAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        productId: 'prod-015',
        productName: 'Teh Tarik',
        recommendationType: 'popular',
        confidence: 0.90,
        reason: 'Most popular beverage',
        createdAt: new Date().toISOString()
      }
    ];
  },
  
  // Get upsell recommendations based on current cart
  getUpsellRecommendations: (cart) => {
    return [
      {
        id: uuidv4(),
        productId: 'prod-022',
        productName: 'Upgrade to Set Meal',
        recommendationType: 'upsell',
        confidence: 0.85,
        reason: 'Add drink and side for RM5 more',
        createdAt: new Date().toISOString()
      }
    ];
  },
  
  // Get cross-sell recommendations based on current cart
  getCrossSellRecommendations: (cart) => {
    return [
      {
        id: uuidv4(),
        productId: 'prod-012',
        productName: 'Cendol',
        recommendationType: 'cross-sell',
        confidence: 0.76,
        reason: 'Popular dessert pairing',
        createdAt: new Date().toISOString()
      },
      {
        id: uuidv4(),
        productId: 'prod-018',
        productName: 'Keropok Lekor',
        recommendationType: 'cross-sell',
        confidence: 0.68,
        reason: 'Frequently bought together',
        createdAt: new Date().toISOString()
      }
    ];
  },
  
  // Get customer preferences based on order history
  getCustomerPreferences: (customerId) => {
    // In a real implementation, this would analyze customer order history
    // For demo purposes, we'll return mock preferences
    return [
      {
        id: uuidv4(),
        customerId,
        category: 'spice_level',
        item: 'medium',
        frequency: 8,
        lastOrdered: new Date().toISOString()
      },
      {
        id: uuidv4(),
        customerId,
        category: 'favorite_category',
        item: ProductCategory.FOOD,
        frequency: 12,
        lastOrdered: new Date().toISOString()
      },
      {
        id: uuidv4(),
        customerId,
        category: 'favorite_item',
        item: 'Nasi Lemak Special',
        frequency: 5,
        lastOrdered: new Date().toISOString()
      }
    ];
  },
  
  // Get predictive inventory data
  getPredictiveInventoryData: () => {
    // In a real implementation, this would use ML models to predict inventory needs
    // For demo purposes, we'll return mock predictive data
    return [
      {
        productId: 'prod-001',
        productName: 'Nasi Lemak Special',
        predictedDemand: 45,
        confidenceScore: 0.88,
        suggestedOrderQuantity: 50,
        seasonalFactors: [
          { factor: 'weekend', impact: 1.2 },
          { factor: 'holiday', impact: 1.5 }
        ],
        historicalTrend: [
          { period: '2025-05-16', demand: 42 },
          { period: '2025-05-17', demand: 48 },
          { period: '2025-05-18', demand: 52 },
          { period: '2025-05-19', demand: 38 },
          { period: '2025-05-20', demand: 40 },
          { period: '2025-05-21', demand: 43 },
          { period: '2025-05-22', demand: 41 }
        ]
      },
      {
        productId: 'prod-003',
        productName: 'Roti Canai',
        predictedDemand: 60,
        confidenceScore: 0.92,
        suggestedOrderQuantity: 70,
        seasonalFactors: [
          { factor: 'weekend', impact: 1.3 },
          { factor: 'morning', impact: 1.8 }
        ],
        historicalTrend: [
          { period: '2025-05-16', demand: 58 },
          { period: '2025-05-17', demand: 65 },
          { period: '2025-05-18', demand: 70 },
          { period: '2025-05-19', demand: 52 },
          { period: '2025-05-20', demand: 55 },
          { period: '2025-05-21', demand: 57 },
          { period: '2025-05-22', demand: 56 }
        ]
      },
      {
        productId: 'prod-015',
        productName: 'Teh Tarik',
        predictedDemand: 80,
        confidenceScore: 0.90,
        suggestedOrderQuantity: 90,
        seasonalFactors: [
          { factor: 'weekend', impact: 1.1 },
          { factor: 'morning', impact: 1.4 },
          { factor: 'evening', impact: 1.2 }
        ],
        historicalTrend: [
          { period: '2025-05-16', demand: 78 },
          { period: '2025-05-17', demand: 85 },
          { period: '2025-05-18', demand: 88 },
          { period: '2025-05-19', demand: 75 },
          { period: '2025-05-20', demand: 76 },
          { period: '2025-05-21', demand: 79 },
          { period: '2025-05-22', demand: 77 }
        ]
      }
    ];
  },
  
  // Get inventory alerts
  getInventoryAlerts: () => {
    // In a real implementation, this would analyze inventory levels and trends
    // For demo purposes, we'll return mock alerts
    return [
      {
        id: uuidv4(),
        type: 'low_stock',
        productId: 'prod-008',
        productName: 'Satay Ayam',
        message: 'Stock below minimum threshold (5 units remaining)',
        severity: 'warning',
        timestamp: new Date().toISOString(),
        isRead: false
      },
      {
        id: uuidv4(),
        type: 'out_of_stock',
        productId: 'prod-012',
        productName: 'Cendol',
        message: 'Item is out of stock',
        severity: 'critical',
        timestamp: new Date().toISOString(),
        isRead: false
      },
      {
        id: uuidv4(),
        type: 'expiring_soon',
        productId: 'prod-025',
        productName: 'Santan (Coconut Milk)',
        message: 'Expires in 2 days',
        severity: 'warning',
        timestamp: new Date().toISOString(),
        isRead: false
      },
      {
        id: uuidv4(),
        type: 'demand_spike',
        productId: 'prod-001',
        productName: 'Nasi Lemak Special',
        message: 'Unusual demand increase detected (35% above normal)',
        severity: 'info',
        timestamp: new Date().toISOString(),
        isRead: true
      }
    ];
  }
};

// Get recommendations
router.get('/recommendations', (req, res) => {
  const { customerId, type, cartItems } = req.query;
  
  let recommendations = [];
  
  if (type === 'personalized' && customerId) {
    recommendations = aiService.getPersonalizedRecommendations(customerId, [], cartItems ? JSON.parse(cartItems as string) : []);
  } else if (type === 'popular') {
    recommendations = aiService.getPopularItems();
  } else if (type === 'upsell' && cartItems) {
    recommendations = aiService.getUpsellRecommendations(JSON.parse(cartItems as string));
  } else if (type === 'cross-sell' && cartItems) {
    recommendations = aiService.getCrossSellRecommendations(JSON.parse(cartItems as string));
  } else {
    // If no specific type is requested, return a mix of recommendations
    recommendations = [
      ...aiService.getPopularItems(),
      ...(cartItems ? aiService.getUpsellRecommendations(JSON.parse(cartItems as string)) : []),
      ...(cartItems ? aiService.getCrossSellRecommendations(JSON.parse(cartItems as string)) : [])
    ];
  }
  
  res.json({
    success: true,
    data: recommendations
  });
});

// Get customer preferences
router.get('/customer-preferences/:customerId', (req, res) => {
  const { customerId } = req.params;
  
  if (!customerId) {
    return res.status(400).json({
      success: false,
      error: {
        code: 'MISSING_CUSTOMER_ID',
        message: 'Customer ID is required'
      }
    });
  }
  
  const preferences = aiService.getCustomerPreferences(customerId);
  
  res.json({
    success: true,
    data: preferences
  });
});

// Get predictive inventory data
router.get('/inventory/predictive', (req, res) => {
  const predictiveData = aiService.getPredictiveInventoryData();
  
  res.json({
    success: true,
    data: predictiveData
  });
});

// Get inventory alerts
router.get('/inventory/alerts', (req, res) => {
  const alerts = aiService.getInventoryAlerts();
  
  res.json({
    success: true,
    data: alerts
  });
});

// Mark alert as read
router.patch('/inventory/alerts/:alertId/read', (req, res) => {
  const { alertId } = req.params;
  
  // In a real implementation, this would update the alert in the database
  // For demo purposes, we'll just return success
  
  res.json({
    success: true,
    data: {
      id: alertId,
      isRead: true
    }
  });
});

export const aiRoutes = router;
