# MalaysiaDish POS: Omnichannel Integration and Real-Time Synchronization

## 1. Introduction

This document outlines the architecture and implementation strategy for omnichannel integration and real-time data synchronization within the MalaysiaDish POS system. The goal is to provide a seamless and consistent experience for both customers and staff across all touchpoints, including in-store POS terminals, self-service kiosks, online ordering websites, and mobile applications. Real-time synchronization of key data entities like inventory, customer profiles, and orders is crucial for achieving this unified experience and maintaining operational efficiency.

## 2. Omnichannel Architecture Overview

The omnichannel capabilities are built upon the existing microservices architecture, ensuring that all channels interact with the same backend services as the source of truth. A dedicated Omnichannel Orchestration Layer facilitates communication and data consistency between channel-specific frontends and the core backend services.

![Omnichannel Architecture](omnichannel_architecture.png)

### 2.1 Core Principles

- **Single Source of Truth**: Core backend services (Inventory, Customer, Order, Menu, etc.) hold the master data.
- **Real-time Communication**: Event-driven architecture and APIs ensure near real-time data updates across channels.
- **Consistent Business Logic**: Core business rules are enforced centrally in the backend services.
- **Channel-Optimized Experiences**: Frontend applications are tailored for specific channel needs while consuming consistent data.
- **Decoupled Frontends**: Channel applications are loosely coupled with the backend via APIs and events.

### 2.2 Key Components

- **Channel Frontends**: Specific applications for each touchpoint (POS Terminal App, Kiosk App, Web Ordering Portal, Mobile App).
- **API Gateway**: Single entry point for all channel requests, routing them to appropriate backend services.
- **Omnichannel Orchestration Layer (Optional but Recommended)**: Handles complex cross-service workflows initiated by channels, simplifying frontend logic.
- **Event Bus (e.g., Kafka, RabbitMQ)**: Facilitates asynchronous communication and real-time event propagation between microservices and potentially to frontends (via WebSockets).
- **Core Backend Microservices**: Inventory, Customer, Order, Menu, Payment, AI, etc.
- **Data Synchronization Service**: Manages conflict resolution and ensures eventual consistency where needed.
- **WebSocket Gateway**: Enables real-time push notifications from the backend to channel frontends.

## 3. Real-Time Inventory Synchronization

Ensuring accurate, real-time inventory levels across all channels is critical to prevent overselling and provide a reliable customer experience.

### 3.1 Synchronization Strategy

- **Event Sourcing in Inventory Service**: The Inventory Service uses event sourcing to track all stock movements (sales, receiving, adjustments, waste). Each stock change generates an immutable event.
- **Event Publication**: The Inventory Service publishes inventory change events (e.g., `StockLevelUpdated`, `ItemSoldOut`) to the central Event Bus.
- **Real-time Consumption**: Backend services (like Order Service for validation) and potentially channel frontends (via WebSocket Gateway) subscribe to these events.
- **API for Current Stock**: Channels can query the Inventory Service API for the most current stock level when needed (e.g., displaying item availability).
- **Reservation Mechanism**: When an item is added to a cart (especially online/mobile), a temporary reservation might be placed via the Inventory Service API to reduce race conditions. Reservations expire after a short period.

```javascript
// Inventory Service Event Example
const stockLevelUpdatedEvent = {
  eventId: "evt_12345",
  eventType: "StockLevelUpdated",
  timestamp: "2025-05-23T10:00:00Z",
  sourceService: "InventoryService",
  payload: {
    locationId: "loc_KL01",
    itemId: "item_NasiLemak",
    ingredientId: null, // Can be for finished item or ingredient
    changeQuantity: -1,
    newQuantityOnHand: 5,
    previousQuantityOnHand: 6,
    reason: "SALE",
    orderId: "ord_ABCDE",
    channel: "KIOSK"
  }
};

// WebSocket Gateway pushing update to relevant frontends
class WebSocketNotifier {
  constructor(webSocketGateway) {
    this.gateway = webSocketGateway;
  }
  
  handleStockLevelUpdate(event) {
    const { locationId, itemId, newQuantityOnHand } = event.payload;
    
    // Construct message
    const message = {
      type: "INVENTORY_UPDATE",
      payload: {
        itemId,
        quantity: newQuantityOnHand,
        isAvailable: newQuantityOnHand > 0
      }
    };
    
    // Push to all connected clients for the specific location
    this.gateway.broadcastToLocation(locationId, message);
  }
}
```

### 3.2 Implementation Considerations

- **Performance**: High volume of inventory updates requires an efficient event bus and optimized database access.
- **Latency**: Minimize delay between stock change and update propagation.
- **Offline Handling**: Channel frontends need a strategy to handle temporary network disconnection (e.g., optimistic updates with later reconciliation, disabling ordering for unavailable items based on last known state).
- **Conflict Resolution**: Implement strategies (e.g., last write wins based on timestamp, reservation system) if concurrent updates are possible, although event sourcing typically minimizes this.

## 4. Unified Customer Profiles

Customer information, preferences, loyalty status, and order history should be consistent regardless of the channel used.

### 4.1 Centralized Customer Service

- **Single Repository**: The Customer Service microservice acts as the single source of truth for all customer data.
- **Unique Customer ID**: A unique identifier links customer activity across all channels.
- **API Access**: All channels access and update customer data via the Customer Service API.
- **Real-time Updates**: Changes made through one channel (e.g., updating contact info via mobile app) are immediately reflected when accessed via another channel (e.g., POS terminal).

```javascript
// Customer Service API Endpoint Example
// GET /api/v1/customers/lookup?identifier=0123456789&type=PHONE
// GET /api/v1/customers/{customerId}
// PUT /api/v1/customers/{customerId}/preferences

// Frontend accessing customer data
class CustomerProfileManager {
  constructor(apiClient, customerId) {
    this.apiClient = apiClient;
    this.customerId = customerId;
    this.profile = null;
  }
  
  async loadProfile() {
    try {
      this.profile = await this.apiClient.getCustomerProfile(this.customerId);
      return this.profile;
    } catch (error) {
      console.error("Failed to load customer profile:", error);
      return null;
    }
  }
  
  async updatePreferences(newPreferences) {
    try {
      const updatedProfile = await this.apiClient.updateCustomerPreferences(
        this.customerId,
        newPreferences
      );
      this.profile = updatedProfile;
      return true;
    } catch (error) {
      console.error("Failed to update preferences:", error);
      return false;
    }
  }
  
  getOrderHistory() {
    // Order history might be fetched from Order Service using customerId
    return this.apiClient.getCustomerOrderHistory(this.customerId);
  }
  
  getLoyaltyPoints() {
    return this.profile?.loyalty?.points || 0;
  }
}
```

### 4.2 Customer Identification Across Channels

- **Multiple Identifiers**: Support for various identification methods (phone number, email, loyalty ID, QR code, app login).
- **Account Linking**: Mechanisms to link different identifiers to a single profile.
- **Guest Checkout**: Handling anonymous users while still tracking order data.

### 4.3 Data Privacy and Consent

- **Centralized Consent Management**: Customer consent preferences (e.g., for marketing, profiling) are stored centrally and respected across all channels.
- **PDPA Compliance**: Ensuring all cross-channel data handling complies with Malaysian privacy laws.

## 5. Consistent Order Management

Orders placed through any channel need to be processed consistently and visible across relevant interfaces.

### 5.1 Centralized Order Service

- **Single Order Repository**: The Order Service manages all orders regardless of their origin channel.
- **Standardized Order Format**: Orders from different channels are transformed into a common format.
- **Order Status Synchronization**: Order status updates (e.g., `RECEIVED`, `PREPARING`, `READY_FOR_PICKUP`, `COMPLETED`, `CANCELLED`) are managed centrally and propagated.
- **Kitchen Display System (KDS) Integration**: Orders are routed to the appropriate KDS based on location and order type.
- **Cross-Channel Order Visibility**: Staff can view orders from all channels via the main POS or management dashboard. Customers can view their own orders via web/mobile portals.

```javascript
// Order Service handling order from different channels
class OrderService {
  constructor(eventBus, inventoryService, customerService, kdsNotifier) {
    this.eventBus = eventBus;
    this.inventoryService = inventoryService;
    this.customerService = customerService;
    this.kdsNotifier = kdsNotifier;
    // ... database connection
  }
  
  async createOrder(orderData) {
    // 1. Validate order data (items, quantities, customizations)
    const validation = await this.validateOrderData(orderData);
    if (!validation.isValid) {
      throw new Error(`Order validation failed: ${validation.message}`);
    }
    
    // 2. Check inventory availability / place reservation
    const inventoryCheck = await this.inventoryService.checkAvailability(
      orderData.locationId,
      orderData.items
    );
    if (!inventoryCheck.available) {
      throw new Error("Some items are out of stock");
    }
    
    // 3. Enrich with customer data if customerId provided
    if (orderData.customerId) {
      orderData.customerDetails = await this.customerService.getCustomerSnapshot(
        orderData.customerId
      );
    }
    
    // 4. Calculate totals, taxes, discounts
    orderData.totals = this.calculateTotals(orderData);
    
    // 5. Assign unique order ID and set initial status
    orderData.orderId = this.generateOrderId();
    orderData.status = "RECEIVED";
    orderData.receivedAt = new Date().toISOString();
    orderData.channel = orderData.channel || "UNKNOWN"; // Ensure channel is recorded
    
    // 6. Save order to database
    const savedOrder = await this.saveOrderToDB(orderData);
    
    // 7. Publish OrderReceived event
    this.eventBus.publish("OrderReceived", savedOrder);
    
    // 8. Decrement inventory / confirm reservation
    await this.inventoryService.confirmStockUsage(
      orderData.locationId,
      orderData.items,
      orderData.orderId
    );
    
    // 9. Send to KDS
    await this.kdsNotifier.sendOrderToKitchen(savedOrder);
    
    return savedOrder;
  }
  
  async updateOrderStatus(orderId, newStatus, details = {}) {
    // 1. Find order
    const order = await this.getOrderFromDB(orderId);
    if (!order) {
      throw new Error(`Order ${orderId} not found`);
    }
    
    // 2. Validate status transition
    if (!this.isValidStatusTransition(order.status, newStatus)) {
      throw new Error(`Invalid status transition from ${order.status} to ${newStatus}`);
    }
    
    // 3. Update status and timestamp
    order.status = newStatus;
    order.lastUpdatedAt = new Date().toISOString();
    order.statusHistory = order.statusHistory || [];
    order.statusHistory.push({ status: newStatus, timestamp: order.lastUpdatedAt, ...details });
    
    // 4. Save updated order
    const updatedOrder = await this.saveOrderToDB(order);
    
    // 5. Publish OrderStatusUpdated event
    this.eventBus.publish("OrderStatusUpdated", updatedOrder);
    
    // 6. Trigger notifications (e.g., to customer, delivery driver)
    await this.triggerNotifications(updatedOrder);
    
    return updatedOrder;
  }
  
  // ... other methods like getOrderById, getOrdersByCustomer, etc.
  
  validateOrderData(orderData) { /* ... */ }
  calculateTotals(orderData) { /* ... */ }
  generateOrderId() { /* ... */ }
  saveOrderToDB(orderData) { /* ... */ }
  getOrderFromDB(orderId) { /* ... */ }
  isValidStatusTransition(fromStatus, toStatus) { /* ... */ }
  triggerNotifications(order) { /* ... */ }
}
```

### 5.2 Order Fulfillment Workflows

- **Dine-in, Takeaway, Delivery**: The system differentiates order types originating from various channels and routes them appropriately for fulfillment.
- **Pickup Coordination**: For online/mobile orders for pickup, the system synchronizes the `READY_FOR_PICKUP` status with customer notifications and staff interfaces.
- **Delivery Integration**: Integration with delivery management platforms, synchronizing order status with drivers and customers.

## 6. Technology Stack and Patterns

### 6.1 Key Technologies

- **Microservices**: Backend built using independent, scalable services (e.g., using Spring Boot, Node.js/Fastify, Python/Flask).
- **API Gateway**: Kong, Apigee, or cloud-native gateways (AWS API Gateway, Azure API Management).
- **Event Bus**: Apache Kafka, RabbitMQ, NATS, or cloud-native options (AWS SNS/SQS, Google Pub/Sub).
- **Databases**: Mix of databases suited for specific needs (e.g., PostgreSQL for relational data, MongoDB for customer profiles, Redis for caching/session management, TimescaleDB for time-series inventory events).
- **WebSocket Gateway**: Socket.IO, Centrifugo, or cloud-native WebSocket services.
- **Frontend Frameworks**: React, Vue, or Angular for web/kiosk; React Native, Flutter, or native SDKs for mobile.

### 6.2 Integration Patterns

- **API-based Integration**: Synchronous request/response communication via REST or GraphQL APIs.
- **Event-Driven Architecture**: Asynchronous communication via events for decoupling and real-time updates.
- **Database Replication**: Used cautiously for specific read-heavy scenarios where eventual consistency is acceptable.
- **Change Data Capture (CDC)**: Capturing database changes and publishing them as events (e.g., using Debezium).
- **Polling (Less Preferred)**: Periodic checking for updates; generally avoided for real-time needs due to inefficiency.

### 6.3 Data Synchronization Mechanisms

- **Push Notifications**: Backend pushes updates to frontends via WebSockets.
- **Eventual Consistency**: Accepting temporary inconsistencies that are resolved over time (suitable for non-critical data).
- **Strong Consistency**: Ensuring immediate consistency, often requiring distributed transactions or locking (more complex, used sparingly).
- **Conflict Resolution Strategies**: Last-Write-Wins (LWW), merging, or manual intervention for conflicting updates.

## 7. Security Considerations

Omnichannel integration introduces security challenges that must be addressed:

- **Authentication and Authorization**: Consistent and secure user/device authentication across all channels. Role-based access control enforced centrally.
- **API Security**: Secure API Gateway with rate limiting, authentication (OAuth 2.0, JWT), and input validation.
- **Data Encryption**: End-to-end encryption (TLS) for all communication between channels and backend services.
- **Secure Event Bus**: Authentication and authorization for publishing/subscribing to events.
- **Cross-Origin Resource Sharing (CORS)**: Proper configuration for web-based channels.
- **Mobile App Security**: Secure coding practices, certificate pinning, code obfuscation.
- **Kiosk Security**: Hardened OS, physical security, network isolation (as detailed in Self-Service document).

## 8. Offline Capabilities

While real-time sync is the goal, channels (especially POS terminals and mobile apps) need graceful handling for network interruptions:

- **Local Caching**: Caching essential data like menu, pricing, and recent orders locally.
- **Offline Order Taking**: Ability to queue orders locally when offline.
- **Data Reconciliation**: Synchronizing queued offline data once connectivity is restored.
- **Offline Inventory Estimation**: Using last known stock levels with potential warnings or limitations.
- **Status Indication**: Clearly indicating online/offline status to the user.

## 9. Conclusion

Omnichannel integration with real-time data synchronization is fundamental to MalaysiaDish POS achieving its goal of being the #1 F&B POS system in Malaysia. By leveraging a microservices architecture, event-driven communication, and centralized data management, the system provides a consistent, reliable, and seamless experience across all customer and staff touchpoints.

Key benefits include:

1.  **Unified Customer Experience**: Customers interact consistently regardless of the channel.
2.  **Operational Accuracy**: Real-time inventory prevents overselling and improves fulfillment.
3.  **Staff Efficiency**: Centralized order management and consistent data reduce errors and streamline workflows.
4.  **Data Consistency**: Ensures all channels operate on the same, up-to-date information.
5.  **Scalability and Flexibility**: Decoupled architecture allows for easier addition of new channels or features.

The implementation requires careful consideration of performance, latency, security, and offline scenarios, but the resulting unified platform provides a significant competitive advantage in the modern F&B landscape.
