import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { usePOS } from "@/lib/pos-context";
import { Badge } from "@/components/ui/badge";
import { ShoppingCart, BarChart3, Receipt, Settings, Users, CreditCard, Utensils, MessageSquare } from "lucide-react";
import { useState } from "react";
import SelfServiceKiosk from "@/pages/SelfServiceKiosk";

export default function App() {
  const { selfServiceMode, toggleSelfServiceMode, orders, tables } = usePOS();
  const [activeTab, setActiveTab] = useState("dashboard");

  if (selfServiceMode) {
    return (
      <div className="flex flex-col min-h-screen">
        <SelfServiceKiosk />
        <div className="fixed bottom-4 right-4">
          <Button variant="outline" onClick={toggleSelfServiceMode}>
            Exit Self-Service Mode
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col min-h-screen">
      <header className="bg-primary text-primary-foreground py-4 px-6 flex justify-between items-center">
        <h1 className="text-xl font-bold">MalaysiaDish POS</h1>
        <div className="flex items-center gap-4">
          <Button variant="secondary" onClick={toggleSelfServiceMode}>
            Enter Self-Service Mode
          </Button>
        </div>
      </header>

      <div className="flex flex-1">
        <aside className="w-64 bg-muted p-4 hidden md:block">
          <nav className="space-y-2">
            <Button 
              variant={activeTab === "dashboard" ? "default" : "ghost"} 
              className="w-full justify-start"
              onClick={() => setActiveTab("dashboard")}
            >
              <BarChart3 className="mr-2 h-4 w-4" />
              Dashboard
            </Button>
            <Button 
              variant={activeTab === "orders" ? "default" : "ghost"} 
              className="w-full justify-start"
              onClick={() => setActiveTab("orders")}
            >
              <ShoppingCart className="mr-2 h-4 w-4" />
              Orders
            </Button>
            <Button 
              variant={activeTab === "tables" ? "default" : "ghost"} 
              className="w-full justify-start"
              onClick={() => setActiveTab("tables")}
            >
              <Users className="mr-2 h-4 w-4" />
              Tables
            </Button>
            <Button 
              variant={activeTab === "menu" ? "default" : "ghost"} 
              className="w-full justify-start"
              onClick={() => setActiveTab("menu")}
            >
              <Utensils className="mr-2 h-4 w-4" />
              Menu
            </Button>
            <Button 
              variant={activeTab === "e-invoice" ? "default" : "ghost"} 
              className="w-full justify-start"
              onClick={() => setActiveTab("e-invoice")}
            >
              <Receipt className="mr-2 h-4 w-4" />
              E-Invoicing
            </Button>
            <Button 
              variant={activeTab === "payments" ? "default" : "ghost"} 
              className="w-full justify-start"
              onClick={() => setActiveTab("payments")}
            >
              <CreditCard className="mr-2 h-4 w-4" />
              Payments
            </Button>
            <Button 
              variant={activeTab === "communication" ? "default" : "ghost"} 
              className="w-full justify-start"
              onClick={() => setActiveTab("communication")}
            >
              <MessageSquare className="mr-2 h-4 w-4" />
              Communication
            </Button>
            <Button 
              variant={activeTab === "settings" ? "default" : "ghost"} 
              className="w-full justify-start"
              onClick={() => setActiveTab("settings")}
            >
              <Settings className="mr-2 h-4 w-4" />
              Settings
            </Button>
          </nav>
        </aside>

        <main className="flex-1 p-6 overflow-auto">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="md:hidden grid w-full grid-cols-4 mb-4">
              <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
              <TabsTrigger value="orders">Orders</TabsTrigger>
              <TabsTrigger value="tables">Tables</TabsTrigger>
              <TabsTrigger value="menu">Menu</TabsTrigger>
            </TabsList>

            <TabsContent value="dashboard" className="space-y-6">
              <h2 className="text-2xl font-bold">Dashboard</h2>
              
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle>Today's Sales</CardTitle>
                    <CardDescription>Total sales for today</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-3xl font-bold">RM 1,245.90</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle>Active Orders</CardTitle>
                    <CardDescription>Orders being prepared</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-3xl font-bold">{orders.filter(o => o.status === 'preparing').length}</p>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader className="pb-2">
                    <CardTitle>Table Status</CardTitle>
                    <CardDescription>Available vs. occupied</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <p className="text-3xl font-bold">
                      {tables.filter(t => t.status === 'available').length} / {tables.length}
                    </p>
                  </CardContent>
                </Card>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader>
                    <CardTitle>AI-Powered Insights</CardTitle>
                    <CardDescription>Personalized recommendations based on sales data</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      <li className="flex items-start gap-2">
                        <Badge variant="outline" className="mt-0.5">Inventory</Badge>
                        <span>Predicted stock shortage of Teh Tarik ingredients by tomorrow</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Badge variant="outline" className="mt-0.5">Sales</Badge>
                        <span>Nasi Lemak sales are 15% higher on weekends</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Badge variant="outline" className="mt-0.5">Promotion</Badge>
                        <span>Recommend bundling Cendol with Mee Goreng for 10% higher sales</span>
                      </li>
                    </ul>
                  </CardContent>
                </Card>
                
                <Card>
                  <CardHeader>
                    <CardTitle>E-Invoicing Status</CardTitle>
                    <CardDescription>IRBM compliance monitoring</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span>E-Invoices Generated Today</span>
                        <Badge>24</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Successfully Submitted to IRBM</span>
                        <Badge variant="outline" className="bg-green-100">24</Badge>
                      </div>
                      <div className="flex items-center justify-between">
                        <span>Compliance Status</span>
                        <Badge className="bg-green-100 text-green-800">Compliant</Badge>
                      </div>
                    </div>
                  </CardContent>
                  <CardFooter>
                    <Button variant="outline" className="w-full">View Detailed Report</Button>
                  </CardFooter>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="orders">
              <h2 className="text-2xl font-bold mb-6">Orders Management</h2>
              
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-medium">Active Orders</h3>
                  <Button>New Order</Button>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {orders.map(order => (
                    <Card key={order.id}>
                      <CardHeader className="pb-2">
                        <div className="flex justify-between items-start">
                          <CardTitle>Order #{order.id.replace('order', '')}</CardTitle>
                          <Badge>{order.status}</Badge>
                        </div>
                        <CardDescription>
                          {order.tableNumber ? `Table ${order.tableNumber}` : 'Takeaway'} • 
                          {new Date(order.timestamp).toLocaleTimeString()}
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="pb-2">
                        <ul className="space-y-1 text-sm">
                          {order.items.map(item => (
                            <li key={item.id} className="flex justify-between">
                              <span>{item.quantity}x {item.name}</span>
                              <span>RM {(item.price * item.quantity).toFixed(2)}</span>
                            </li>
                          ))}
                        </ul>
                        <div className="mt-2 pt-2 border-t flex justify-between font-medium">
                          <span>Total</span>
                          <span>RM {order.total.toFixed(2)}</span>
                        </div>
                      </CardContent>
                      <CardFooter className="flex gap-2">
                        <Button variant="outline" className="flex-1">Update Status</Button>
                        <Button className="flex-1">View Details</Button>
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="tables">
              <h2 className="text-2xl font-bold mb-6">Tables Management</h2>
              
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {tables.map(table => (
                  <Card key={table.id} className={
                    table.status === 'available' ? 'border-green-500 border-2' :
                    table.status === 'occupied' ? 'border-red-500 border-2' :
                    'border-yellow-500 border-2'
                  }>
                    <CardHeader className="pb-2">
                      <CardTitle className="flex justify-between items-center">
                        <span>Table {table.number}</span>
                        <Badge>{table.status}</Badge>
                      </CardTitle>
                      <CardDescription>{table.seats} seats</CardDescription>
                    </CardHeader>
                    <CardContent className="pb-2">
                      {table.currentOrderId && (
                        <p className="text-sm">Order: #{table.currentOrderId.replace('order', '')}</p>
                      )}
                    </CardContent>
                    <CardFooter>
                      <Button 
                        variant={table.status === 'available' ? 'default' : 'outline'} 
                        className="w-full"
                        disabled={table.status === 'reserved'}
                      >
                        {table.status === 'available' ? 'New Order' : 'View Order'}
                      </Button>
                    </CardFooter>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="e-invoice">
              <h2 className="text-2xl font-bold mb-6">E-Invoicing (IRBM Compliant)</h2>
              
              <Card className="mb-6">
                <CardHeader>
                  <CardTitle>E-Invoicing Status</CardTitle>
                  <CardDescription>Your system is fully compliant with IRBM e-invoicing requirements</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div className="bg-green-50 p-4 rounded-lg">
                        <h3 className="font-medium text-green-800">UBL 2.1 Compliant</h3>
                        <p className="text-sm text-green-700">All invoices follow the Universal Business Language 2.1 standard</p>
                      </div>
                      <div className="bg-green-50 p-4 rounded-lg">
                        <h3 className="font-medium text-green-800">XML/JSON Format</h3>
                        <p className="text-sm text-green-700">Invoices are generated in both XML and JSON formats</p>
                      </div>
                      <div className="bg-green-50 p-4 rounded-lg">
                        <h3 className="font-medium text-green-800">MyInvois Integration</h3>
                        <p className="text-sm text-green-700">Direct submission to IRBM via MyInvois Portal/API</p>
                      </div>
                    </div>
                    
                    <div className="flex justify-between items-center p-4 bg-blue-50 rounded-lg">
                      <div>
                        <h3 className="font-medium text-blue-800">Mandatory Compliance Date</h3>
                        <p className="text-sm text-blue-700">Your system is ready for the July 1, 2025 deadline</p>
                      </div>
                      <Badge className="bg-blue-100 text-blue-800">Ready</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              <div className="space-y-4">
                <div className="flex justify-between items-center">
                  <h3 className="text-lg font-medium">Recent E-Invoices</h3>
                  <Button variant="outline">View All</Button>
                </div>
                
                <div className="overflow-x-auto">
                  <table className="w-full border-collapse">
                    <thead>
                      <tr className="bg-muted">
                        <th className="text-left p-2">Invoice #</th>
                        <th className="text-left p-2">Date</th>
                        <th className="text-left p-2">Customer</th>
                        <th className="text-right p-2">Amount</th>
                        <th className="text-center p-2">Status</th>
                        <th className="text-right p-2">Actions</th>
                      </tr>
                    </thead>
                    <tbody>
                      {[1, 2, 3, 4, 5].map(i => (
   
(Content truncated due to size limit. Use line ranges to read in chunks)