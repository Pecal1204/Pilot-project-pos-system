# MalaysiaDish POS: Customer Communication Automation

## 1. Introduction

This document outlines the implementation of automated customer communication features for the MalaysiaDish POS system. These capabilities enable F&B businesses to maintain consistent, timely, and personalized communication with customers across various channels, with a particular focus on WhatsApp integration for digital receipts and order notifications. The implementation ensures compliance with Malaysian privacy regulations while leveraging the existing omnichannel architecture to deliver a seamless customer experience.

## 2. Communication Architecture Overview

The customer communication capabilities are implemented through a dedicated Communication Service within the MalaysiaDish POS microservices architecture. This service orchestrates all customer-facing communications across multiple channels while maintaining message consistency, delivery tracking, and compliance with privacy preferences.

![Communication Architecture](communication_architecture.png)

### 2.1 Core Components

#### 2.1.1 Communication Service
- **Message Orchestrator**: Central component that manages message routing, formatting, and delivery
- **Template Engine**: Handles dynamic content insertion into predefined message templates
- **Channel Adapters**: Interfaces with specific communication channels (WhatsApp, SMS, Email, Push Notifications)
- **Delivery Tracker**: Monitors message delivery status and handles retries
- **Opt-in/Opt-out Manager**: Manages customer communication preferences and consent

#### 2.1.2 Integration Points
- **Order Service**: Triggers order-related notifications (confirmation, status updates, delivery)
- **Payment Service**: Initiates receipt delivery after successful payment
- **Customer Service**: Provides customer profiles and communication preferences
- **Loyalty Service**: Triggers loyalty-related communications (points updates, rewards)
- **Marketing Service**: Manages promotional campaigns and targeted offers

#### 2.1.3 External Channel Providers
- **WhatsApp Business API**: Primary channel for receipts and order notifications
- **SMS Gateway**: Fallback for customers without WhatsApp
- **Email Service**: For longer-form communications and statements
- **Push Notification Service**: For customers using the mobile app

## 3. WhatsApp Receipt Delivery

### 3.1 Implementation Overview

The WhatsApp receipt delivery feature provides customers with instant digital receipts directly to their WhatsApp account, reducing paper waste and providing convenient access to purchase records.

### 3.2 WhatsApp Business API Integration

```javascript
// WhatsApp Channel Adapter
class WhatsAppAdapter {
  constructor(whatsappApiClient, templateService, configService) {
    this.apiClient = whatsappApiClient;
    this.templateService = templateService;
    this.config = configService.getWhatsAppConfig();
    this.phoneNumberUtil = new PhoneNumberUtil();
  }
  
  async initialize() {
    // Verify API connection
    const connectionStatus = await this.apiClient.checkConnection();
    if (!connectionStatus.connected) {
      throw new Error(`WhatsApp API connection failed: ${connectionStatus.message}`);
    }
    
    // Load approved message templates
    await this.templateService.loadApprovedTemplates();
    
    return connectionStatus;
  }
  
  async sendReceipt(customerPhone, receiptData) {
    try {
      // Validate and format phone number
      const formattedPhone = this.formatPhoneNumber(customerPhone);
      if (!formattedPhone) {
        throw new Error(`Invalid phone number: ${customerPhone}`);
      }
      
      // Check if customer has opted in to WhatsApp communications
      const optInStatus = await this.checkOptInStatus(formattedPhone);
      if (!optInStatus.optedIn) {
        console.log(`Customer ${formattedPhone} has not opted in to WhatsApp communications`);
        return {
          success: false,
          channel: 'whatsapp',
          reason: 'NOT_OPTED_IN',
          fallbackAvailable: true
        };
      }
      
      // Generate receipt content using template
      const receiptContent = await this.templateService.generateReceiptContent(receiptData);
      
      // Prepare media (if receipt includes QR code or logo)
      let mediaId = null;
      if (receiptData.includeQrCode) {
        mediaId = await this.uploadReceiptQrCode(receiptData.orderId);
      }
      
      // Send message using appropriate template
      const sendResult = await this.apiClient.sendTemplateMessage({
        to: formattedPhone,
        templateName: 'receipt_delivery',
        languageCode: receiptData.languagePreference || 'en',
        components: [
          {
            type: 'header',
            parameters: mediaId ? [
              {
                type: 'image',
                image: {
                  id: mediaId
                }
              }
            ] : []
          },
          {
            type: 'body',
            parameters: [
              {
                type: 'text',
                text: receiptData.businessName
              },
              {
                type: 'text',
                text: receiptData.orderId
              },
              {
                type: 'text',
                text: receiptData.formattedDate
              },
              {
                type: 'text',
                text: receiptData.formattedAmount
              }
            ]
          },
          {
            type: 'button',
            subType: 'url',
            index: 0,
            parameters: [
              {
                type: 'text',
                text: receiptData.receiptUrl
              }
            ]
          }
        ]
      });
      
      // Log delivery attempt
      await this.logMessageDelivery({
        channel: 'whatsapp',
        recipient: formattedPhone,
        messageType: 'receipt',
        orderId: receiptData.orderId,
        status: sendResult.success ? 'SENT' : 'FAILED',
        messageId: sendResult.messageId,
        timestamp: new Date().toISOString(),
        error: sendResult.success ? null : sendResult.error
      });
      
      return {
        success: sendResult.success,
        channel: 'whatsapp',
        messageId: sendResult.messageId,
        timestamp: new Date().toISOString()
      };
      
    } catch (error) {
      console.error('WhatsApp receipt delivery failed:', error);
      
      // Log error
      await this.logMessageDelivery({
        channel: 'whatsapp',
        recipient: customerPhone,
        messageType: 'receipt',
        orderId: receiptData.orderId,
        status: 'ERROR',
        error: error.message,
        timestamp: new Date().toISOString()
      });
      
      return {
        success: false,
        channel: 'whatsapp',
        error: error.message,
        fallbackAvailable: true
      };
    }
  }
  
  async uploadReceiptQrCode(orderId) {
    // Generate and upload QR code image for the receipt
    try {
      const qrCodeUrl = `https://receipt.malaysiadish.com/r/${orderId}`;
      const qrCodeImage = await this.generateQrCode(qrCodeUrl);
      
      // Upload to WhatsApp API
      const uploadResult = await this.apiClient.uploadMedia({
        file: qrCodeImage,
        type: 'image/png'
      });
      
      return uploadResult.mediaId;
    } catch (error) {
      console.error('Failed to upload receipt QR code:', error);
      return null; // Proceed without QR code
    }
  }
  
  async generateQrCode(url) {
    // Implementation of QR code generation
    // ...
  }
  
  formatPhoneNumber(phoneNumber) {
    try {
      // Ensure phone number is in international format for Malaysia
      if (!phoneNumber.startsWith('+')) {
        // If number starts with 0, replace with Malaysia country code
        if (phoneNumber.startsWith('0')) {
          phoneNumber = '+60' + phoneNumber.substring(1);
        } 
        // If number starts with 60, add + prefix
        else if (phoneNumber.startsWith('60')) {
          phoneNumber = '+' + phoneNumber;
        }
        // Otherwise assume it's a Malaysian number without prefix
        else {
          phoneNumber = '+60' + phoneNumber;
        }
      }
      
      // Validate phone number format
      const parsedNumber = this.phoneNumberUtil.parse(phoneNumber);
      if (!this.phoneNumberUtil.isValidNumber(parsedNumber)) {
        return null;
      }
      
      // Return E.164 format
      return this.phoneNumberUtil.format(parsedNumber, PhoneNumberFormat.E164);
    } catch (error) {
      console.error('Phone number formatting failed:', error);
      return null;
    }
  }
  
  async checkOptInStatus(phoneNumber) {
    // Check if customer has opted in to WhatsApp communications
    try {
      const optInRecord = await this.apiClient.checkOptIn(phoneNumber);
      return {
        optedIn: optInRecord.status === 'ACTIVE',
        timestamp: optInRecord.timestamp,
        source: optInRecord.source
      };
    } catch (error) {
      console.error('Failed to check opt-in status:', error);
      // Default to not opted in if we can't verify
      return { optedIn: false };
    }
  }
  
  async logMessageDelivery(logData) {
    // Log message delivery attempt to database
    // ...
  }
}
```

### 3.3 Receipt Template Design

The receipt template is designed to be clear, concise, and include all necessary information while complying with Malaysian tax regulations:

- **Header**: Business logo and name
- **Transaction Details**: Date, time, order/transaction ID
- **Item Details**: Purchased items, quantities, unit prices
- **Pricing Summary**: Subtotal, tax (with GST/SST details), discounts, total
- **Payment Information**: Payment method, amount paid, change given
- **Additional Information**: Tax registration number, return policy
- **Digital Elements**: QR code for digital verification, link to full receipt

### 3.4 Receipt Delivery Flow

1. **Trigger**: Payment is completed at any channel (POS, kiosk, online)
2. **Data Preparation**: Receipt data is compiled from the transaction
3. **Customer Identification**: System retrieves customer's phone number and communication preferences
4. **Consent Check**: Verifies customer has opted in to WhatsApp communications
5. **Template Selection**: Chooses appropriate template based on transaction type and language preference
6. **Content Generation**: Populates template with transaction data
7. **Delivery**: Sends receipt via WhatsApp Business API
8. **Tracking**: Records delivery status and handles any failures
9. **Fallback**: If WhatsApp delivery fails, falls back to alternative method (SMS, email, print) based on preferences

## 4. Automated Order Notifications

### 4.1 Implementation Overview

The automated order notification system keeps customers informed about their order status throughout the fulfillment process, enhancing transparency and reducing inquiries.

### 4.2 Notification Types

- **Order Confirmation**: Acknowledges receipt of order with summary and estimated time
- **Order Status Updates**: Notifies when order status changes (preparing, ready, etc.)
- **Delivery Updates**: Provides delivery tracking information (if applicable)
- **Order Completion**: Confirms order fulfillment and requests feedback
- **Order Issues**: Alerts about delays, out-of-stock items, or other problems

```javascript
// Order Notification Manager
class OrderNotificationManager {
  constructor(communicationService, orderService, customerService) {
    this.communicationService = communicationService;
    this.orderService = orderService;
    this.customerService = customerService;
  }
  
  async initialize() {
    // Subscribe to order status change events
    this.orderService.subscribeToStatusChanges(async (orderEvent) => {
      await this.handleOrderStatusChange(orderEvent);
    });
    
    return true;
  }
  
  async handleOrderStatusChange(orderEvent) {
    try {
      const { orderId, newStatus, previousStatus, timestamp } = orderEvent;
      
      // Get full order details
      const order = await this.orderService.getOrderDetails(orderId);
      if (!order) {
        throw new Error(`Order ${orderId} not found`);
      }
      
      // Get customer details and preferences
      const customer = order.customerId ? 
        await this.customerService.getCustomer(order.customerId) : 
        order.guestDetails;
      
      // Skip notification if no contact info or opted out
      if (!this.canNotifyCustomer(customer, newStatus)) {
        console.log(`Skipping notification for order ${orderId}: No contact info or opted out`);
        return;
      }
      
      // Determine if this status change should trigger a notification
      if (!this.shouldNotifyOnStatus(newStatus, order.orderType)) {
        return;
      }
      
      // Prepare notification data
      const notificationData = this.prepareNotificationData(order, newStatus, timestamp);
      
      // Send notification through preferred channel
      const notificationResult = await this.sendOrderNotification(
        customer,
        notificationData
      );
      
      // Log notification attempt
      await this.logNotification({
        orderId,
        customerId: order.customerId,
        status: newStatus,
        notificationResult,
        timestamp: new Date().toISOString()
      });
      
      return notificationResult;
      
    } catch (error) {
      console.error('Order notification failed:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }
  
  canNotifyCustomer(customer, status) {
    // Check if we have contact information and customer hasn't opted out
    if (!customer) return false;
    
    // For order confirmation, we need explicit consent
    if (status === 'RECEIVED' || status === 'CONFIRMED') {
      return customer.communicationPreferences?.orderConfirmations === true &&
             (customer.phone || customer.email);
    }
    
    // For other status updates, we can notify if they haven't explicitly opted out
    return customer.communicationPreferences?.orderUpdates !== false &&
           (customer.phone || customer.email);
  }
  
  shouldNotifyOnStatus(status, orderType) {
    // Determine which status changes should trigger notifications based on order type
    const notifiableStatuses = {
      'DINE_IN': ['CONFIRMED', 'READY', 'CANCELLED'],
      'TAKEAWAY': ['CONFIRMED', 'PREPARING', 'READY_FOR_PICKUP', 'CANCELLED'],
      'DELIVERY': ['CONFIRMED', 'PREPARING', 'OUT_FOR_DELIVERY', 'DELIVERED', 'CANCELLED'],
      'ONLINE': ['CONFIRMED', 'PREPARING', 'READY_FOR_PICKUP', 'OUT_FOR_DELIVERY', 'DELIVERED', 'CANCELLED']
    };
    
    return notifiableStatuses[orderType]?.includes(status) || false;
  }
  
  prepareNotificationData(order, status, timestamp) {
    // Prepare data for notification based on order status
    const baseData = {
      orderId: order.orderId,
      businessName: order.locationName,
      orderType: order.orderType,
      formattedAmount: this.formatCurrency(order.totalAmount),
      itemCount: order.items.length,
      timestamp: timestamp || new Date().toISOString(),
      orderUrl: `https://order.malaysiadish.com/status/${order.orderId}`
    };
    
    // Add status-specific data
    switch (status) {
      case 'CONFIRMED':
        return {
          ...baseData,
          messageType: 'ORDER_CONFIRMATION',
          estimatedReadyTime: this.formatTime(order.estimatedReadyTime),
          paymentMethod: order.paymentMethod,
          orderSummary: this.createOrderSummary(order.items)
        };
        
      case 'PREPARING':
        return {
          ...baseData,
          messageType: 'ORDER_PREPARING',
          estimatedReadyTime: this.formatTime(order.estimatedReadyTime)
        };
        
      case 'READY_FOR_PICKUP':
        return {
          ...baseData,
          messageType: 'ORDER_READY',
          pickupLocation: order.pickupLocation || order.locationName,
          pickupInstructions: order.pickupInstructions
        };
        
      case 'OUT_FOR_DELIVERY':
        return {
          ...baseData,
          messageType: 'ORDER_OUT_FOR_DELIVERY',
          estimatedDeliveryTime: this.formatTime(order.estimatedDeliveryTime),
          deliveryAddress: this.formatAddress(order.deliveryAddress),
          driverName: order.driverName,
          trackingUrl: order.trackingUrl
        };
        
      case 'DELIVERED':
        return {
          ...baseData,
          messageType: 'ORDER_DELIVERED',
          feedbackUrl: `https://feedback.malaysiadish.com/${order.orderId}`
        };
        
      case 'CANCELLED':
        return {
          ...baseData,
          messageType: 'ORDER_CANCELLED',
          cancellationReason: order.cancellationReason,
          refundInfo: order.refundInfo
        };
        
      default:
        return {
          ...baseData,
          messageType: 'ORDER_UPDATE',
          status: status
        };
    }
  }
  
  async sendOrderNotification(customer, notificationData) {
    // Determine best channel based on customer preferences and notification type
    const channel = this.determineNotificationChannel(customer, notificationData.messageType);
    
    // Send through communication service
    return await this.communicationService.sendMessage({
      recipient: {
        customerId: customer.id,
        phone: customer.phone,
        email: customer.email,
        deviceTokens: customer.deviceTokens
      },
      messageType: notificationData.messageType,
      channel: channel,
      data: notificationData,
      priority: this.getNotificationPriority(notificationData.messageType)
    });
  }
  
  determineNotificationChannel(customer, messageType) {
    // Get customer's preferred channel for this message type
    const preferences = customer.communicationPreferences || {};
    
    // Default channel hierarchy: WhatsApp > Push > SMS > Email
    const availableChannels = [];
    
    // Add channels based on available contact info
    if (customer.phone) {
      if (preferences.whatsapp !== false) availableChannels.push('whatsapp');
      if (preferences.sms !== false) availableChannels.push('sms');
    }
    
    if (customer.deviceTokens?.length > 0 && preferences.push !== false) {
      availableChannels.push('push');
    }
    
    if (customer.email && preferences.email !== false) {
      availableChannels.push('email');
    }
    
    // If customer has specific preference for this message type, use it
    const specificPreference = preferences[`${messageType.toLowerCase()}Channel`];
    if (specificPreference && availableChannels.includes(specificPreference)) {
      return specificPreference;
    }
    
    // Otherwise return first available channel in hierarchy
    return availableChannels[0] || 'none';
  }
  
  getNotificationPriority(messageType) {
    // Set priority based on message type
    const priorities = {
      'ORDER_CONFIRMATION': 'high',
      'ORDER_READY': 'high',
      'ORDER_CANCELLED': 'high',
      'ORDER_PREPARING': 'medium',
      'ORDER_OUT_FOR_DELIVERY': 'medium',
      'ORDER_DELIVERED': 'medium'
    };
    
    return priorities[messageType] || 'medium';
  }
  
  formatCurrency(amount) {
    return new Intl.NumberFormat('ms-MY', {
      style: 'currency',
      currency: 'MYR'
    }).format(amount);
  }
  
  formatTime(timestamp) {
    if (!timestamp) return 'N/A';
    
    return new Date(timestamp).toLocaleTimeString('ms-MY', {
      hour: '2-digit',
      minute: '2-digit'
    });
  }
  
  formatAddress(address) {
    if (!address) return 'N/A';
    
    return `${address.street}, ${address.city}, ${address.state} ${address.postalCode}`;
  }
  
  createOrderSummary(items) {
    // Create a condensed summary of order items
    if (!items || items.length === 0) return 'No items';
    
    if (items.length <= 2) {
      return items.map(item => `${item.quantity}x ${item.name}`).join(', ');
    } else {
      return `${items[0].quantity}x ${items[0].name}, ${items[1].quantity}x ${items[1].name}, +${items.length - 2} more`;
    }
  }
  
  async logNotification(logData) {
    // Log notification to database
    // ...
  }
}
```

### 4.3 Channel Selection Logic

The system intelligently selects the optimal communication channel based on:

1. **Customer Preferences**: Explicitly stated channel preferences
2. **Message Type**: Different channels for different notification types
3. **Available Contact Information**: Phone number, email, app installation
4. **Previous Engagement**: Channels with higher open/response rates
5. **Urgency**: More immediate channels for time-sensitive notifications

### 4.4 Notification Timing and Frequency

- **Immediate Notifications**: Order confirmation, ready for pickup, delivery updates
- **Batched Notifications**: Non-urgent updates, promotional messages
- **Quiet Hours**: Respecting local time and avoiding late-night notifications
- **Frequency Caps**: Preventing notification fatigue
- **Smart Bundling**: Combining multiple updates when they occur in quick succession

## 5. Customer Feedback System

### 5.1 Implementation Overview

The feedback system automatically solicits, collects, and processes customer feedback after order completion, providing valuable insights for business improvement.

### 5.2 Feedback Collection Methods

- **WhatsApp Quick Replies**: Simple rating collection via WhatsApp
- **Short URL Surveys**: Mobile-optimized feedback forms
- **QR Code on Receipt**: Scan to provide feedback
- **In-App Feedback**: Native feedback interface in mobile app
- **Email Surveys**: More detailed feedback collection

```javascript
// Feedback Collection Service
class FeedbackService {
  constructor(communicationService, orderService, analyticsService) {
    this.communicationService = communicationService;
    this.orderService = orderService;
    this.analyticsService = analyticsService;
  }
  
  async initialize() {
    // Set up scheduled feedback requests
    this.setupFeedbackScheduler();
    
    // Set up webhook handlers for feedback responses
    this.setupResponseHandlers();
    
    return true;
  }
  
  setupFeedbackScheduler() {
    // Schedule feedback requests for completed orders
    setInterval(async () => {
      await this.processCompletedOrdersForFeedback();
    }, 15 * 60 * 1000); // Every 15 minutes
  }
  
  async processCompletedOrdersForFeedback() {
    try {
      // Get orders completed in the last hour that haven't had feedback requests
      const orders = await this.orderService.getOrdersForFeedback();
      
      for (const order of orders) {
        // Check if customer is eligible for feedback request
        if (await this.isEligibleForFeedback(order)) {
          // Send feedback request
          await this.sendFeedbackRequest(order);
          
          // Mark order as feedback requested
          await this.orderService.markFeedbackRequested(order.orderId);
        }
      }
    } catch (error) {
      console.error('Failed to process orders for feedback:', error);
    }
  }
  
  async isEligibleForFeedback(order) {
    // Skip if no customer ID or contact info
    if (!order.customerId && !order.customerPhone && !order.customerEmail) {
      return false;
    }
    
    // Skip if customer has opted out of feedback requests
    if (order.customer?.communicationPreferences?.feedbackRequests === false) {
      return false;
    }
    
    // Check if customer has received too many feedback requests recently
    const recentRequests = await this.getRecentFeedbackRequests(
      order.customerId || order.customerPhone || order.customerEmail
    );
    
    if (recentRequests >= 2) { // No more than 2 requests in the feedback window
      return false;
    }
    
    return true;
  }
  
  async getRecentFeedbackRequests(customerIdentifier) {
    // Get count of feedback requests in the last 7 days
    // ...
    return 0; // Placeholder
  }
  
  async sendFeedbackRequest(order) {
    try {
      // Prepare feedback request data
      const feedbackData = {
        orderId: order.orderId,
        businessName: order.locationName,
        orderDate: this.formatDate(order.completedAt || order.createdAt),
        feedbackUrl: this.generateFeedbackUrl(order),
        expiresAt: this.calculateExpiryTime(24) // 24 hours to provide feedback
      };
      
      // Determine best channel for feedback request
      const channel = this.determineFeedbackChannel(order);
      
      // Send feedback request
      const result = await this.communicationService.sendMessage({
        recipient: {
          customerId: order.customerId,
          phone: order.customerPhone,
          email: order.customerEmail
        },
        messageType: 'FEEDBACK_REQUEST',
        channel: channel,
        data: feedbackData,
        priority: 'low'
      });
      
      // Log feedback request
      await this.logFeedbackRequest({
        orderId: order.orderId,
        customerId: order.customerId,
        channel: channel,
        requestId: result.messageId,
        timestamp: new Date().toISOString(),
        success: result.success
      });
      
      return result;
      
    } catch (error) {
      console.error('Failed to send feedback request:', error);
      return { success: false, error: error.message };
    }
  }
  
  determineFeedbackChannel(order) {
    // Determine best channel based on customer preferences and available contact info
    const customer = order.customer || {};
    const preferences = customer.communicationPreferences || {};
    
    // Check specific preference for feedback
    if (preferences.feedbackChannel) {
      if (preferences.feedbackChannel === 'whatsapp' && order.customerPhone) {
        return 'whatsapp';
      } else if (preferences.feedbackChannel === 'email' && order.customerEmail) {
        return 'email';
      } else if (preferences.feedbackChannel === 'sms' && order.customerPhone) {
        return 'sms';
      }
    }
    
    // Default channel selection
    if (order.customerPhone && preferences.whatsapp !== false) {
      return 'whatsapp'; // Prefer WhatsApp if available
    } else if (order.customerEmail) {
      return 'email'; // Fall back to email
    } else if (order.customerPhone) {
      return 'sms'; // Last resort is SMS
    }
    
    return 'none'; // No viable channel
  }
  
  generateFeedbackUrl(order) {
    // Generate unique URL for feedback form
    const baseUrl = 'https://feedback.malaysiadish.com';
    const token = this.generateSecureToken(order);
    
    return `${baseUrl}/${order.orderId}?token=${token}`;
  }
  
  generateSecureToken(order) {
    // Generate secure token for feedback authentication
    // ...
    return 'sample-token-123'; // Placeholder
  }
  
  calculateExpiryTime(hoursFromNow) {
    const date = new Date();
    date.setHours(date.getHours() + hoursFromNow);
    return date.toISOString();
  }
  
  formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('ms-MY', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  }
  
  setupResponseHandlers() {
    // Set up handlers for different feedback response channels
    this.setupWhatsAppResponseHandler();
    this.setupWebFormResponseHandler();
    // Other channel handlers...
  }
  
  setupWhatsAppResponseHandler() {
    // Handle incoming WhatsApp responses to feedback requests
    // ...
  }
  
  setupWebFormResponseHandler() {
    // Handle web form submissions
    // ...
  }
  
  async processFeedbackResponse(feedbackData) {
    try {
      // Validate feedback data
      if (!this.validateFeedback(feedbackData)) {
        throw new Error('Invalid feedback data');
      }
      
      // Store feedback in database
      const savedFeedback = await this.storeFeedback(feedbackData);
      
      // Send thank you message if appropriate
      if (feedbackData.sendThankYou) {
        await this.sendFeedbackThankYou(feedbackData);
      }
      
      // Process feedback for analytics
      await this.analyticsService.processFeedback(savedFeedback);
      
      // Alert management for negative feedback if needed
      if (this.isNegativeFeedback(feedbackData)) {
        await this.alertManagementForNegativeFeedback(feedbackData);
      }
      
      return { success: true, feedbackId: savedFeedback.id };
      
    } catch (error) {
      console.error('Failed to process feedback response:', error);
      return { success: false, error: error.message };
    }
  }
  
  validateFeedback(feedbackData) {
    // Validate feedback data structure and content
    // ...
    return true; // Placeholder
  }
  
  async storeFeedback(feedbackData) {
    // Store feedback in database
    // ...
    return { id: 'feedback-123', ...feedbackData }; // Placeholder
  }
  
  isNegativeFeedback(feedbackData) {
    // Check if feedback is negative and requires management attention
    return feedbackData.rating < 3; // On a 5-point scale
  }
  
  async alertManagementForNegativeFeedback(feedbackData) {
    // Send alert to management about negative feedback
    // ...
  }
  
  async sendFeedbackThankYou(feedbackData) {
    // Send thank you message for providing feedback
    // ...
  }
  
  async logFeedbackRequest(logData) {
    // Log feedback request to database
    // ...
  }
}
```

### 5.3 Feedback Analysis and Reporting

- **Sentiment Analysis**: Automated analysis of feedback text
- **Rating Aggregation**: Compilation of numerical ratings
- **Trend Identification**: Spotting patterns over time
- **Issue Categorization**: Classifying feedback by topic
- **Management Alerts**: Notifications for negative feedback
- **Performance Dashboards**: Visual reporting of feedback metrics

## 6. Promotional Messaging

### 6.1 Implementation Overview

The promotional messaging system enables targeted marketing communications while ensuring compliance with privacy regulations and customer preferences.

### 6.2 Campaign Types

- **Loyalty Promotions**: Points-based offers and rewards
- **Special Occasions**: Birthday, anniversary offers
- **Win-back Campaigns**: Targeting lapsed customers
- **New Menu Items**: Promoting new offerings
- **Limited-Time Offers**: Time-sensitive promotions
- **Location-Based Promotions**: Geo-targeted offers

### 6.3 Targeting and Personalization

- **Segmentation**: Grouping customers by behavior, preferences, or demographics
- **Personalized Content**: Customizing message content based on customer data
- **Timing Optimization**: Sending at optimal times for engagement
- **A/B Testing**: Testing different message variants
- **Response Tracking**: Monitoring engagement and conversion

```javascript
// Promotional Campaign Manager
class PromotionalCampaignManager {
  constructor(communicationService, customerService, analyticsService) {
    this.communicationService = communicationService;
    this.customerService = customerService;
    this.analyticsService = analyticsService;
    this.activePromotions = new Map();
  }
  
  async createCampaign(campaignData) {
    try {
      // Validate campaign data
      this.validateCampaignData(campaignData);
      
      // Generate campaign ID
      const campaignId = this.generateCampaignId();
      
      // Prepare campaign object
      const campaign = {
        id: campaignId,
        name: campaignData.name,
        description: campaignData.description,
        startDate: campaignData.startDate,
        endDate: campaignData.endDate,
        targetSegment: campaignData.targetSegment,
        messageTemplate: campaignData.messageTemplate,
        channels: campaignData.channels || ['whatsapp', 'sms', 'email'],
        status: 'DRAFT',
        createdAt: new Date().toISOString(),
        createdBy: campaignData.createdBy,
        metrics: {
          targetAudience: 0,
          sent: 0,
          delivered: 0,
          opened: 0,
          clicked: 0,
          converted: 0
        }
      };
      
      // Store campaign
      await this.storeCampaign(campaign);
      
      // If campaign is scheduled to start immediately, activate it
      if (new Date(campaign.startDate) <= new Date()) {
        await this.activateCampaign(campaignId);
      }
      
      return { success: true, campaignId };
      
    } catch (error) {
      console.error('Failed to create campaign:', error);
      return { success: false, error: error.message };
    }
  }
  
  validateCampaignData(campaignData) {
    // Validate required fields
    const requiredFields = ['name', 'startDate', 'endDate', 'targetSegment', 'messageTemplate'];
    for (const field of requiredFields) {
      if (!campaignData[field]) {
        throw new Error(`Missing required field: ${field}`);
      }
    }
    
    // Validate dates
    const startDate = new Date(campaignData.startDate);
    const endDate = new Date(campaignData.endDate);
    
    if (isNaN(startDate.getTime())) {
      throw new Error('Invalid start date');
    }
    
    if (isNaN(endDate.getTime())) {
      throw new Error('Invalid end date');
    }
    
    if (endDate <= startDate) {
      throw new Error('End date must be after start date');
    }
    
    // Validate message template
    if (!campaignData.messageTemplate.content) {
      throw new Error('Message template must include content');
    }
    
    // Additional validations...
  }
  
  generateCampaignId() {
    // Generate unique campaign ID
    return 'camp_' + Date.now() + '_' + Math.random().toString(36).substring(2, 7);
  }
  
  async storeCampaign(campaign) {
    // Store campaign in database
    // ...
    
    // Add to active promotions if within date range
    const now = new Date();
    if (new Date(campaign.startDate) <= now && new Date(campaign.endDate) >= now) {
      this.activePromotions.set(campaign.id, campaign);
    }
  }
  
  async activateCampaign(campaignId) {
    try {
      // Get campaign
      const campaign = await this.getCampaign(campaignId);
      if (!campaign) {
        throw new Error(`Campaign ${campaignId} not found`);
      }
      
      // Verify campaign can be activated
      if (campaign.status !== 'DRAFT' && campaign.status !== 'PAUSED') {
        throw new Error(`Cannot activate campaign with status: ${campaign.status}`);
      }
      
      // Get target audience
      const targetCustomers = await this.customerService.getCustomersBySegment(
        campaign.targetSegment
      );
      
      // Update campaign status and metrics
      campaign.status = 'ACTIVE';
      campaign.metrics.targetAudience = targetCustomers.length;
      campaign.activatedAt = new Date().toISOString();
      
      // Store updated campaign
      await this.updateCampaign(campaign);
      
      // Add to active promotions
      this.activePromotions.set(campaign.id, campaign);
      
      // Schedule message delivery
      await this.scheduleCampaignDelivery(campaign, targetCustomers);
      
      return { success: true, targetAudience: targetCustomers.length };
      
    } catch (error) {
      console.error('Failed to activate campaign:', error);
      return { success: false, error: error.message };
    }
  }
  
  async scheduleCampaignDelivery(campaign, targetCustomers) {
    // For immediate campaigns, start delivery process
    if (campaign.deliveryType === 'IMMEDIATE') {
      this.startCampaignDelivery(campaign, targetCustomers);
    } 
    // For scheduled campaigns, set up delivery at specified time
    else if (campaign.deliveryType === 'SCHEDULED') {
      const deliveryTime = new Date(campaign.scheduledTime);
      const now = new Date();
      const delay = deliveryTime.getTime() - now.getTime();
      
      if (delay > 0) {
        setTimeout(() => {
          this.startCampaignDelivery(campaign, targetCustomers);
        }, delay);
      } else {
        // If scheduled time is in the past, start immediately
        this.startCampaignDelivery(campaign, targetCustomers);
      }
    }
    // For staggered delivery, set up batched sending
    else if (campaign.deliveryType === 'STAGGERED') {
      this.startStaggeredDelivery(campaign, targetCustomers);
    }
  }
  
  async startCampaignDelivery(campaign, targetCustomers) {
    try {
      console.log(`Starting delivery for campaign ${campaign.id} to ${targetCustomers.length} customers`);
      
      // Process in batches to avoid overwhelming the system
      const batchSize = 100;
      let processed = 0;
      
      while (processed < targetCustomers.length) {
        const batch = targetCustomers.slice(processed, processed + batchSize);
        
        // Process batch
        await Promise.all(batch.map(customer => 
          this.sendPromotionalMessage(campaign, customer)
        ));
        
        processed += batch.length;
        
        // Update campaign metrics
        campaign.metrics.sent = processed;
        await this.updateCampaign(campaign);
        
        // Small delay between batches
        if (processed < targetCustomers.length) {
          await new Promise(resolve => setTimeout(resolve, 1000));
        }
      }
      
      console.log(`Completed delivery for campaign ${campaign.id}`);
      
    } catch (error) {
      console.error(`Error in campaign delivery for ${campaign.id}:`, error);
      
      // Update campaign status to reflect error
      campaign.status = 'ERROR';
      campaign.lastError = error.message;
      await this.updateCampaign(campaign);
    }
  }
  
  async startStaggeredDelivery(campaign, targetCustomers) {
    // Implementation for staggered delivery over time
    // ...
  }
  
  async sendPromotionalMessage(campaign, customer) {
    try {
      // Skip if customer has opted out of promotional messages
      if (customer.communicationPreferences?.promotionalMessages === false) {
        return { success: false, reason: 'OPTED_OUT' };
      }
      
      // Personalize message content
      const personalizedContent = this.personalizeContent(
        campaign.messageTemplate,
        customer
      );
      
      // Determine best channel
      const channel = this.determinePromotionalChannel(campaign, customer);
      if (channel === 'none') {
        return { success: false, reason: 'NO_CHANNEL' };
      }
      
      // Prepare tracking data
      const trackingData = {
        campaignId: campaign.id,
        customerId: customer.id,
        timestamp: new Date().toISOString()
      };
      
      // Generate tracking URL if needed
      let content = personalizedContent;
      if (personalizedContent.includes('{tracking_url}')) {
        const trackingUrl = this.generateTrackingUrl(trackingData);
        content = personalizedContent.replace('{tracking_url}', trackingUrl);
      }
      
      // Send message
      const result = await this.communicationService.sendMessage({
        recipient: {
          customerId: customer.id,
          phone: customer.phone,
          email: customer.email
        },
        messageType: 'PROMOTIONAL',
        channel: channel,
        data: {
          content: content,
          subject: campaign.messageTemplate.subject,
          campaignName: campaign.name,
          ...trackingData
        },
        priority: 'low'
      });
      
      // Log delivery attempt
      await this.logPromotionalMessage({
        campaignId: campaign.id,
        customerId: customer.id,
        channel: channel,
        messageId: result.messageId,
        status: result.success ? 'SENT' : 'FAILED',
        timestamp: new Date().toISOString(),
        error: result.success ? null : result.error
      });
      
      return result;
      
    } catch (error) {
      console.error('Failed to send promotional message:', error);
      return { success: false, error: error.message };
    }
  }
  
  personalizeContent(template, customer) {
    let content = template.content;
    
    // Replace customer-specific placeholders
    const replacements = {
      '{customer_name}': customer.name || 'Valued Customer',
      '{first_name}': customer.firstName || customer.name?.split(' ')[0] || 'Friend',
      '{loyalty_points}': customer.loyaltyPoints || '0',
      '{last_visit_date}': customer.lastVisitDate ? 
        this.formatDate(customer.lastVisitDate) : 'recently',
      // Add more replacements as needed
    };
    
    // Apply replacements
    for (const [placeholder, value] of Object.entries(replacements)) {
      content = content.replace(new RegExp(placeholder, 'g'), value);
    }
    
    return content;
  }
  
  determinePromotionalChannel(campaign, customer) {
    // Check campaign-specific channel restrictions
    const availableChannels = campaign.channels || ['whatsapp', 'sms', 'email'];
    
    // Filter by customer preferences and available contact info
    const viableChannels = availableChannels.filter(channel => {
      if (channel === 'whatsapp' || channel === 'sms') {
        return customer.phone && customer.communicationPreferences?.[channel] !== false;
      } else if (channel === 'email') {
        return customer.email && customer.communicationPreferences?.email !== false;
      } else if (channel === 'push') {
        return customer.deviceTokens?.length > 0 && customer.communicationPreferences?.push !== false;
      }
      return false;
    });
    
    // Return preferred channel or first viable one
    const preferredChannel = customer.communicationPreferences?.preferredPromotionalChannel;
    if (preferredChannel && viableChannels.includes(preferredChannel)) {
      return preferredChannel;
    }
    
    return viableChannels[0] || 'none';
  }
  
  generateTrackingUrl(trackingData) {
    // Generate URL with tracking parameters
    const baseUrl = 'https://promo.malaysiadish.com/r';
    const params = new URLSearchParams({
      cid: trackingData.campaignId,
      uid: trackingData.customerId,
      ts: trackingData.timestamp
    });
    
    return `${baseUrl}?${params.toString()}`;
  }
  
  async getCampaign(campaignId) {
    // Get campaign from database or cache
    // ...
    return this.activePromotions.get(campaignId); // Placeholder
  }
  
  async updateCampaign(campaign) {
    // Update campaign in database
    // ...
    
    // Update in active promotions if applicable
    if (campaign.status === 'ACTIVE') {
      this.activePromotions.set(campaign.id, campaign);
    } else {
      this.activePromotions.delete(campaign.id);
    }
  }
  
  async logPromotionalMessage(logData) {
    // Log promotional message to database
    // ...
  }
  
  formatDate(dateString) {
    return new Date(dateString).toLocaleDateString('ms-MY', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  }
}
```

## 7. Loyalty Program Communications

### 7.1 Implementation Overview

The loyalty program communication system keeps members informed about their status, points, and available rewards, encouraging continued engagement.

### 7.2 Loyalty Notification Types

- **Points Updates**: Notifications about points earned or redeemed
- **Tier Status Changes**: Alerts about loyalty tier changes
- **Reward Availability**: Notifications when rewards become available
- **Expiration Reminders**: Alerts about points or rewards expiring
- **Special Member Offers**: Exclusive promotions for loyalty members

### 7.3 Personalization Elements

- **Current Points Balance**: Up-to-date loyalty points information
- **Progress to Next Tier**: Visual representation of tier progress
- **Personalized Rewards**: Recommendations based on preferences
- **Historical Activity**: Summary of recent loyalty activity
- **Milestone Celebrations**: Recognition of loyalty milestones

## 8. Privacy and Compliance

### 8.1 PDPA Compliance

The system ensures compliance with the Malaysian Personal Data Protection Act (PDPA):

- **Explicit Consent**: Clear opt-in mechanisms for each communication channel
- **Purpose Limitation**: Communications limited to specified purposes
- **Granular Preferences**: Separate consent for different message types
- **Easy Opt-Out**: Simple unsubscribe mechanisms in every message
- **Data Minimization**: Collecting only necessary information
- **Retention Limits**: Appropriate data retention periods

```javascript
// Consent Management Service
class ConsentManager {
  constructor(customerService, databaseService) {
    this.customerService = customerService;
    this.db = databaseService;
  }
  
  async recordConsent(customerId, consentData) {
    try {
      // Validate consent data
      this.validateConsentData(consentData);
      
      // Get current customer consent record
      const customer = await this.customerService.getCustomer(customerId);
      if (!customer) {
        throw new Error(`Customer ${customerId} not found`);
      }
      
      // Prepare consent record
      const consentRecord = {
        customerId,
        consentType: consentData.consentType,
        channel: consentData.channel,
        status: consentData.status,
        source: consentData.source,
        ipAddress: consentData.ipAddress,
        userAgent: consentData.userAgent,
        timestamp: new Date().toISOString(),
        expiryDate: this.calculateExpiryDate(consentData.consentType),
        consentVersion: consentData.consentVersion || '1.0'
      };
      
      // Store consent record
      await this.storeConsentRecord(consentRecord);
      
      // Update customer communication preferences
      await this.updateCustomerPreferences(customerId, consentData);
      
      return { success: true, consentRecord };
      
    } catch (error) {
      console.error('Failed to record consent:', error);
      return { success: false, error: error.message };
    }
  }
  
  validateConsentData(consentData) {
    // Validate required fields
    const requiredFields = ['consentType', 'channel', 'status', 'source'];
    for (const field of requiredFields) {
      if (!consentData[field]) {
        throw new Error(`Missing required field: ${field}`);
      }
    }
    
    // Validate consent type
    const validConsentTypes = [
      'MARKETING', 'TRANSACTIONAL', 'OPERATIONAL', 
      'WHATSAPP_BUSINESS', 'SMS', 'EMAIL', 'PUSH',
      'ORDER_UPDATES', 'PROMOTIONAL', 'FEEDBACK'
    ];
    
    if (!validConsentTypes.includes(consentData.consentType)) {
      throw new Error(`Invalid consent type: ${consentData.consentType}`);
    }
    
    // Validate channel
    const validChannels = ['whatsapp', 'sms', 'email', 'push', 'all'];
    if (!validChannels.includes(consentData.channel)) {
      throw new Error(`Invalid channel: ${consentData.channel}`);
    }
    
    // Validate status
    if (consentData.status !== 'GRANTED' && consentData.status !== 'WITHDRAWN') {
      throw new Error(`Invalid consent status: ${consentData.status}`);
    }
  }
  
  calculateExpiryDate(consentType) {
    // Set expiry based on consent type
    const now = new Date();
    
    switch (consentType) {
      case 'MARKETING':
      case 'PROMOTIONAL':
        // Marketing consent expires after 2 years
        now.setFullYear(now.getFullYear() + 2);
        break;
        
      case 'WHATSAPP_BUSINESS':
        // WhatsApp Business consent expires after 1 year
        now.setFullYear(now.getFullYear() + 1);
        break;
        
      default:
        // Other consent types don't expire automatically
        return null;
    }
    
    return now.toISOString();
  }
  
  async storeConsentRecord(consentRecord) {
    // Store consent record in database
    // ...
  }
  
  async updateCustomerPreferences(customerId, consentData) {
    try {
      // Get current preferences
      const customer = await this.customerService.getCustomer(customerId);
      const preferences = customer.communicationPreferences || {};
      
      // Update preferences based on consent type and channel
      switch (consentData.consentType) {
        case 'WHATSAPP_BUSINESS':
          preferences.whatsapp = consentData.status === 'GRANTED';
          break;
          
        case 'SMS':
          preferences.sms = consentData.status === 'GRANTED';
          break;
          
        case 'EMAIL':
          preferences.email = consentData.status === 'GRANTED';
          break;
          
        case 'PUSH':
          preferences.push = consentData.status === 'GRANTED';
          break;
          
        case 'MARKETING':
        case 'PROMOTIONAL':
          preferences.promotionalMessages = consentData.status === 'GRANTED';
          if (consentData.channel !== 'all') {
            preferences[`${consentData.channel}`] = consentData.status === 'GRANTED';
          }
          break;
          
        case 'ORDER_UPDATES':
          preferences.orderUpdates = consentData.status === 'GRANTED';
          break;
          
        case 'FEEDBACK':
          preferences.feedbackRequests = consentData.status === 'GRANTED';
          break;
      }
      
      // Update customer record
      await this.customerService.updateCustomerPreferences(customerId, preferences);
      
    } catch (error) {
      console.error('Failed to update customer preferences:', error);
      throw error;
    }
  }
  
  async checkConsentStatus(customerId, consentType, channel) {
    try {
      // Get customer
      const customer = await this.customerService.getCustomer(customerId);
      if (!customer) {
        return { hasConsent: false, reason: 'CUSTOMER_NOT_FOUND' };
      }
      
      // Get latest consent record
      const consentRecord = await this.getLatestConsentRecord(
        customerId, 
        consentType,
        channel
      );
      
      // Check if consent is valid
      if (!consentRecord) {
        return { hasConsent: false, reason: 'NO_CONSENT_RECORD' };
      }
      
      if (consentRecord.status !== 'GRANTED') {
        return { hasConsent: false, reason: 'CONSENT_WITHDRAWN' };
      }
      
      // Check if consent has expired
      if (consentRecord.expiryDate && new Date(consentRecord.expiryDate) < new Date()) {
        return { hasConsent: false, reason: 'CONSENT_EXPIRED' };
      }
      
      return { 
        hasConsent: true, 
        consentRecord,
        expiresAt: consentRecord.expiryDate
      };
      
    } catch (error) {
      console.error('Failed to check consent status:', error);
      return { hasConsent: false, error: error.message };
    }
  }
  
  async getLatestConsentRecord(customerId, consentType, channel) {
    // Get latest consent record from database
    // ...
    return null; // Placeholder
  }
  
  async processOptOut(optOutData) {
    try {
      // Validate opt-out data
      if (!optOutData.identifier || !optOutData.channel) {
        throw new Error('Missing required opt-out information');
      }
      
      // Find customer by identifier (phone, email, etc.)
      const customer = await this.customerService.findCustomerByIdentifier(
        optOutData.identifier,
        optOutData.identifierType || 'PHONE'
      );
      
      if (!customer) {
        return { success: false, reason: 'CUSTOMER_NOT_FOUND' };
      }
      
      // Determine consent types to withdraw based on channel and scope
      const consentTypesToWithdraw = this.determineConsentTypesToWithdraw(
        optOutData.channel,
        optOutData.scope || 'ALL'
      );
      
      // Record consent withdrawal for each type
      for (const consentType of consentTypesToWithdraw) {
        await this.recordConsent(customer.id, {
          consentType,
          channel: optOutData.channel,
          status: 'WITHDRAWN',
          source: optOutData.source || 'OPT_OUT_REQUEST',
          ipAddress: optOutData.ipAddress,
          userAgent: optOutData.userAgent
        });
      }
      
      return { success: true, customer: { id: customer.id } };
      
    } catch (error) {
      console.error('Failed to process opt-out:', error);
      return { success: false, error: error.message };
    }
  }
  
  determineConsentTypesToWithdraw(channel, scope) {
    // Determine which consent types to withdraw based on channel and scope
    if (scope === 'ALL') {
      switch (channel) {
        case 'whatsapp':
          return ['WHATSAPP_BUSINESS', 'MARKETING', 'PROMOTIONAL', 'FEEDBACK'];
        case 'sms':
          return ['SMS', 'MARKETING', 'PROMOTIONAL', 'FEEDBACK'];
        case 'email':
          return ['EMAIL', 'MARKETING', 'PROMOTIONAL', 'FEEDBACK'];
        case 'push':
          return ['PUSH', 'MARKETING', 'PROMOTIONAL', 'FEEDBACK'];
        default:
          return ['MARKETING', 'PROMOTIONAL', 'FEEDBACK'];
      }
    } else if (scope === 'MARKETING') {
      return ['MARKETING', 'PROMOTIONAL'];
    } else {
      return [scope];
    }
  }
}
```

### 8.2 Opt-In and Opt-Out Management

- **Channel-Specific Consent**: Separate opt-in for each communication channel
- **Purpose-Specific Consent**: Different consent for transactional vs. marketing messages
- **Consent Records**: Comprehensive tracking of consent actions
- **Preference Center**: Customer-accessible communication preferences
- **Unsubscribe Mechanisms**: One-click unsubscribe in all messages

### 8.3 Data Security

- **Encryption**: End-to-end encryption for sensitive data
- **Access Controls**: Strict limitations on who can access customer data
- **Audit Trails**: Logging of all data access and communication activities
- **Secure APIs**: Protected interfaces for external services
- **Data Anonymization**: Where appropriate for analytics and reporting

## 9. Technical Implementation

### 9.1 Integration with Existing Services

The Communication Service integrates with other MalaysiaDish POS microservices:

- **Customer Service**: For profile data and communication preferences
- **Order Service**: For order details and status updates
- **Payment Service**: For transaction details and receipts
- **Loyalty Service**: For points, rewards, and tier information
- **AI Service**: For personalization and targeting

### 9.2 External Service Providers

The system integrates with external communication providers:

- **WhatsApp Business API Provider**: For WhatsApp messaging (e.g., Twilio, MessageBird)
- **SMS Gateway**: For SMS messaging (e.g., Twilio, Nexmo)
- **Email Service Provider**: For email communications (e.g., SendGrid, Mailgun)
- **Push Notification Service**: For mobile app notifications (e.g., Firebase Cloud Messaging)

### 9.3 Scalability and Performance

- **Asynchronous Processing**: Message queuing for reliable delivery
- **Rate Limiting**: Respecting provider rate limits
- **Batching**: Grouping messages for efficient processing
- **Caching**: Reducing database load for frequent operations
- **Horizontal Scaling**: Adding capacity as message volume grows

### 9.4 Monitoring and Analytics

- **Delivery Tracking**: Monitoring message delivery status
- **Engagement Metrics**: Tracking open, click, and response rates
- **Error Monitoring**: Alerting on delivery failures
- **Performance Metrics**: Measuring system responsiveness
- **Business Impact**: Correlating communications with business outcomes

## 10. Implementation Roadmap

### 10.1 Phased Deployment

The customer communication capabilities will be implemented in phases:

#### 10.1.1 Phase 1: Core Transactional Communications
- WhatsApp receipt delivery
- Order status notifications
- Basic opt-in/opt-out management
- Compliance framework

#### 10.1.2 Phase 2: Enhanced Customer Engagement
- Feedback collection system
- Loyalty program communications
- Additional communication channels
- Preference center

#### 10.1.3 Phase 3: Advanced Marketing Capabilities
- Promotional campaign management
- Advanced personalization
- A/B testing framework
- Analytics dashboard

### 10.2 Testing and Validation

- **Functional Testing**: Verifying all communication features
- **Compliance Testing**: Ensuring regulatory adherence
- **Performance Testing**: Validating system under load
- **User Acceptance Testing**: Confirming business requirements
- **Security Testing**: Verifying data protection

## 11. Conclusion

The customer communication automation capabilities of MalaysiaDish POS provide F&B businesses with powerful tools to engage customers, deliver important information, and build loyalty. By implementing WhatsApp receipt delivery, automated order notifications, feedback collection, and promotional messaging within a privacy-compliant framework, the system enhances the customer experience while driving business growth.

Key benefits include:

1. **Enhanced Customer Experience**: Timely, relevant communications improve customer satisfaction and engagement.

2. **Operational Efficiency**: Automated communications reduce staff workload and ensure consistent messaging.

3. **Environmental Impact**: Digital receipts reduce paper waste and support sustainability goals.

4. **Marketing Effectiveness**: Targeted, personalized communications improve campaign performance.

5. **Regulatory Compliance**: Built-in privacy controls ensure adherence to Malaysian regulations.

The modular, scalable architecture ensures that communication capabilities can evolve over time, incorporating new channels and features as customer expectations and business needs change.
