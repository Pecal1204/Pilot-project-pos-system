import React from 'react';
import { Box, Typography, Paper, Grid, Card, CardContent, CardHeader, Divider } from '@mui/material';
import { styled } from '@mui/material/styles';
import RestaurantMenuIcon from '@mui/icons-material/RestaurantMenu';
import ReceiptIcon from '@mui/icons-material/Receipt';
import TableRestaurantIcon from '@mui/icons-material/TableRestaurant';
import PeopleIcon from '@mui/icons-material/People';
import TrendingUpIcon from '@mui/icons-material/TrendingUp';
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';

const StyledCard = styled(Card)(({ theme }) => ({
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
  transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out',
  '&:hover': {
    transform: 'translateY(-5px)',
    boxShadow: theme.shadows[6],
  },
}));

const IconWrapper = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  width: 60,
  height: 60,
  borderRadius: '50%',
  backgroundColor: theme.palette.primary.main,
  color: theme.palette.primary.contrastText,
  marginBottom: theme.spacing(2),
}));

const DashboardPage: React.FC = () => {
  // Mock data for dashboard
  const stats = {
    dailySales: 'RM 4,250.00',
    totalOrders: 78,
    activeOrders: 12,
    popularItems: [
      { name: 'Nasi Lemak Special', count: 42 },
      { name: 'Teh Tarik', count: 38 },
      { name: 'Roti Canai', count: 35 },
    ],
    tables: {
      available: 8,
      occupied: 12,
      reserved: 2,
    },
    customers: 65,
  };

  return (
    <Box sx={{ flexGrow: 1 }}>
      <Typography variant="h4" gutterBottom>
        Dashboard
      </Typography>

      <Grid container spacing={3}>
        {/* Sales Summary */}
        <Grid item xs={12} md={6} lg={3}>
          <StyledCard>
            <CardContent sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center' }}>
              <IconWrapper>
                <AttachMoneyIcon fontSize="large" />
              </IconWrapper>
              <Typography variant="h5" component="div">
                {stats.dailySales}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Today's Sales
              </Typography>
            </CardContent>
          </StyledCard>
        </Grid>

        {/* Orders Summary */}
        <Grid item xs={12} md={6} lg={3}>
          <StyledCard>
            <CardContent sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center' }}>
              <IconWrapper>
                <ReceiptIcon fontSize="large" />
              </IconWrapper>
              <Typography variant="h5" component="div">
                {stats.totalOrders}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Total Orders Today
              </Typography>
            </CardContent>
          </StyledCard>
        </Grid>

        {/* Tables Summary */}
        <Grid item xs={12} md={6} lg={3}>
          <StyledCard>
            <CardContent sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center' }}>
              <IconWrapper>
                <TableRestaurantIcon fontSize="large" />
              </IconWrapper>
              <Typography variant="h5" component="div">
                {stats.tables.occupied} / {stats.tables.available + stats.tables.occupied + stats.tables.reserved}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Tables Occupied
              </Typography>
            </CardContent>
          </StyledCard>
        </Grid>

        {/* Customers Summary */}
        <Grid item xs={12} md={6} lg={3}>
          <StyledCard>
            <CardContent sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center', textAlign: 'center' }}>
              <IconWrapper>
                <PeopleIcon fontSize="large" />
              </IconWrapper>
              <Typography variant="h5" component="div">
                {stats.customers}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                Customers Today
              </Typography>
            </CardContent>
          </StyledCard>
        </Grid>

        {/* Active Orders */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2, height: '100%' }}>
            <Typography variant="h6" gutterBottom>
              Active Orders
            </Typography>
            <Divider sx={{ mb: 2 }} />
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', height: '70%' }}>
              <Typography variant="h2" color="primary">
                {stats.activeOrders}
              </Typography>
            </Box>
            <Typography variant="body2" color="text.secondary" align="center">
              Orders currently being processed
            </Typography>
          </Paper>
        </Grid>

        {/* Popular Items */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2, height: '100%' }}>
            <Typography variant="h6" gutterBottom>
              Popular Items
            </Typography>
            <Divider sx={{ mb: 2 }} />
            <Box sx={{ mt: 2 }}>
              {stats.popularItems.map((item, index) => (
                <Box key={index} sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <RestaurantMenuIcon sx={{ mr: 1, color: 'text.secondary' }} />
                    <Typography variant="body1">{item.name}</Typography>
                  </Box>
                  <Typography variant="body1" fontWeight="bold">
                    {item.count} orders
                  </Typography>
                </Box>
              ))}
            </Box>
          </Paper>
        </Grid>

        {/* System Status */}
        <Grid item xs={12}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>
              System Status
            </Typography>
            <Divider sx={{ mb: 2 }} />
            <Grid container spacing={2}>
              <Grid item xs={12} md={4}>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <Box sx={{ width: 16, height: 16, borderRadius: '50%', bgcolor: 'success.main', mr: 1 }} />
                  <Typography variant="body1">E-Invoicing Module: Ready</Typography>
                </Box>
                <Typography variant="body2" color="text.secondary" sx={{ ml: 3 }}>
                  IRBM compliant for July 2025
                </Typography>
              </Grid>
              <Grid item xs={12} md={4}>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <Box sx={{ width: 16, height: 16, borderRadius: '50%', bgcolor: 'success.main', mr: 1 }} />
                  <Typography variant="body1">Payment Processing: Active</Typography>
                </Box>
                <Typography variant="body2" color="text.secondary" sx={{ ml: 3 }}>
                  All payment methods available
                </Typography>
              </Grid>
              <Grid item xs={12} md={4}>
                <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                  <Box sx={{ width: 16, height: 16, borderRadius: '50%', bgcolor: 'success.main', mr: 1 }} />
                  <Typography variant="body1">AI Recommendations: Active</Typography>
                </Box>
                <Typography variant="body2" color="text.secondary" sx={{ ml: 3 }}>
                  Personalization engine running
                </Typography>
              </Grid>
            </Grid>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default DashboardPage;
