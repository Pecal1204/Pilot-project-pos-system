# MalaysiaDish POS: E-Invoicing Compliance Implementation

## 1. Introduction

This document details the implementation of e-invoicing compliance for the MalaysiaDish POS system, adhering to the Inland Revenue Board of Malaysia (IRBM) requirements that become mandatory for all taxpayers by July 1, 2025. The implementation follows the Universal Business Language (UBL) 2.1 standard and supports both XML and JSON formats as required by IRBM.

## 2. IRBM E-Invoicing Requirements Overview

### 2.1 Regulatory Framework

The IRBM e-invoicing initiative is part of Malaysia's digital transformation strategy aimed at enhancing tax administration efficiency and reducing tax leakage. Key aspects of the regulatory framework include:

- **Mandatory Implementation**: All taxpayers must comply by July 1, 2025
- **Phased Approach**:
  - Phase 1 (July 1, 2024): Companies with annual revenue exceeding RM 100 million
  - Phase 2 (January 1, 2025): Companies with annual revenue between RM 25 million and RM 100 million
  - Phase 3 (July 1, 2025): All remaining taxpayers
- **Legal Basis**: Income Tax Act 1967 and supporting regulations
- **Enforcement**: Non-compliance may result in penalties and business disruption

### 2.2 Technical Requirements

The IRBM has specified the following technical requirements for e-invoicing:

- **Document Standards**: Universal Business Language (UBL) 2.1
- **Format Options**: XML or JSON
- **Transmission Methods**:
  - MyInvois Portal (web interface)
  - Direct API integration
- **Digital Signature**: Required for document authenticity
- **Validation**: Real-time validation before acceptance
- **Storage**: Secure retention of validated e-invoices
- **Minimum Data Fields**: Specific required information elements

## 3. E-Invoicing Service Architecture

### 3.1 Component Overview

The e-invoicing service is implemented as a dedicated microservice within the MalaysiaDish POS architecture, with the following components:

![E-Invoicing Service Architecture](e_invoicing_architecture.png)

#### 3.1.1 Invoice Generator
- Creates UBL 2.1 compliant invoice documents
- Supports both XML and JSON formats
- Validates against IRBM schemas
- Applies digital signatures

#### 3.1.2 IRBM Integration Adapter
- Connects to MyInvois Portal or API
- Handles authentication and secure transmission
- Processes validation responses
- Manages retries and error handling

#### 3.1.3 Invoice Repository
- Securely stores all generated invoices
- Maintains validation status and history
- Provides search and retrieval capabilities
- Implements retention policies

#### 3.1.4 Reporting Engine
- Generates tax and compliance reports
- Tracks submission statistics
- Monitors validation success rates
- Alerts on compliance issues

### 3.2 Integration Points

The e-invoicing service integrates with other MalaysiaDish POS components through:

- **Order Management Service**: Receives completed transaction data
- **Payment Processing Service**: Obtains payment details
- **Customer Service**: Retrieves customer information
- **Inventory Management Service**: Accesses product details and pricing
- **User Management Service**: Obtains business entity information
- **Notification Service**: Sends invoice-related communications

## 4. UBL 2.1 Implementation

### 4.1 UBL 2.1 Overview

Universal Business Language (UBL) 2.1 is an OASIS standard that defines a common XML library of business documents including invoices. Key aspects of UBL 2.1 include:

- **Standardized Schema**: XML Schema Definition (XSD) for invoice structure
- **Common Components**: Reusable data types and elements
- **Extensibility**: Support for customization and extension
- **Internationalization**: Multi-language and currency support
- **Interoperability**: Widely adopted global standard

### 4.2 UBL Invoice Structure

The UBL 2.1 invoice document follows this general structure:

```xml
<Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
         xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
         xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2">
    
    <!-- Document Identification -->
    <cbc:UBLVersionID>2.1</cbc:UBLVersionID>
    <cbc:ID>INV-12345</cbc:ID>
    <cbc:IssueDate>2025-05-23</cbc:IssueDate>
    <cbc:InvoiceTypeCode>380</cbc:InvoiceTypeCode>
    
    <!-- Document Currency -->
    <cbc:DocumentCurrencyCode>MYR</cbc:DocumentCurrencyCode>
    
    <!-- Seller Information -->
    <cac:AccountingSupplierParty>
        <!-- Seller details -->
    </cac:AccountingSupplierParty>
    
    <!-- Buyer Information -->
    <cac:AccountingCustomerParty>
        <!-- Customer details -->
    </cac:AccountingCustomerParty>
    
    <!-- Tax Information -->
    <cac:TaxTotal>
        <!-- Tax details -->
    </cac:TaxTotal>
    
    <!-- Invoice Totals -->
    <cac:LegalMonetaryTotal>
        <!-- Amount details -->
    </cac:LegalMonetaryTotal>
    
    <!-- Invoice Line Items -->
    <cac:InvoiceLine>
        <!-- Line item details -->
    </cac:InvoiceLine>
    
</Invoice>
```

### 4.3 IRBM-Specific Requirements

In addition to standard UBL 2.1 elements, IRBM requires specific fields and values:

- **Business Registration Number**: Seller and buyer tax identification
- **SST Registration Number**: If applicable
- **Invoice Series**: Sequential numbering system
- **Malaysian Service Tax**: Properly categorized and calculated
- **Item Classification**: Standard product/service codes
- **Payment Terms**: Clearly specified conditions
- **Digital Signature**: XML-DSig implementation

## 5. XML Implementation

### 5.1 XML Schema and Validation

The XML implementation uses the official UBL 2.1 schemas with IRBM extensions:

```javascript
// XML Schema Configuration
const ubl21Schema = {
  baseNamespace: 'urn:oasis:names:specification:ubl:schema:xsd:Invoice-2',
  commonAggregateComponents: 'urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2',
  commonBasicComponents: 'urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2',
  irbmExtensions: 'urn:my:irbm:einvoice:extension:1.0'
};

// XML Validation Function
function validateInvoiceXML(xmlDocument) {
  const validator = new XMLValidator(ubl21Schema);
  const validationResult = validator.validate(xmlDocument);
  
  if (!validationResult.valid) {
    throw new ValidationError('Invoice XML validation failed', validationResult.errors);
  }
  
  return validationResult;
}
```

### 5.2 XML Generation

The system generates XML invoices using a template-based approach:

```javascript
// XML Invoice Generator
class XMLInvoiceGenerator {
  constructor(templateEngine, schemaValidator) {
    this.templateEngine = templateEngine;
    this.schemaValidator = schemaValidator;
  }
  
  generateInvoice(invoiceData) {
    // Transform business data to UBL structure
    const ublData = this.mapToUBLFormat(invoiceData);
    
    // Apply template to generate XML
    const xmlDocument = this.templateEngine.render('ubl21-invoice.xml', ublData);
    
    // Validate against schema
    this.schemaValidator.validate(xmlDocument);
    
    // Apply digital signature
    const signedXml = this.applyDigitalSignature(xmlDocument);
    
    return signedXml;
  }
  
  mapToUBLFormat(invoiceData) {
    // Mapping logic from POS data model to UBL 2.1 structure
    // ...
  }
  
  applyDigitalSignature(xmlDocument) {
    // XML-DSig implementation
    // ...
  }
}
```

### 5.3 Sample XML Invoice

Below is a sample XML invoice that meets IRBM requirements:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
         xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
         xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2"
         xmlns:ext="urn:my:irbm:einvoice:extension:1.0">
    
    <cbc:UBLVersionID>2.1</cbc:UBLVersionID>
    <cbc:CustomizationID>urn:my:irbm:einvoice:1.0</cbc:CustomizationID>
    <cbc:ProfileID>IRBM-E-Invoice</cbc:ProfileID>
    <cbc:ID>INV-20250523-12345</cbc:ID>
    <cbc:IssueDate>2025-05-23</cbc:IssueDate>
    <cbc:IssueTime>14:42:00</cbc:IssueTime>
    <cbc:InvoiceTypeCode>380</cbc:InvoiceTypeCode>
    <cbc:Note>Thank you for dining with us!</cbc:Note>
    <cbc:DocumentCurrencyCode>MYR</cbc:DocumentCurrencyCode>
    <cbc:TaxCurrencyCode>MYR</cbc:TaxCurrencyCode>
    
    <cac:AccountingSupplierParty>
        <cac:Party>
            <cac:PartyIdentification>
                <cbc:ID schemeID="MY-TIN">123456789012</cbc:ID>
            </cac:PartyIdentification>
            <cac:PartyName>
                <cbc:Name>MalaysiaDish Restaurant Sdn Bhd</cbc:Name>
            </cac:PartyName>
            <cac:PostalAddress>
                <cbc:StreetName>123 Jalan Sultan</cbc:StreetName>
                <cbc:CityName>Kuala Lumpur</cbc:CityName>
                <cbc:PostalZone>50000</cbc:PostalZone>
                <cac:Country>
                    <cbc:IdentificationCode>MY</cbc:IdentificationCode>
                </cac:Country>
            </cac:PostalAddress>
            <cac:PartyTaxScheme>
                <cbc:CompanyID>SST-123456789</cbc:CompanyID>
                <cac:TaxScheme>
                    <cbc:ID>SST</cbc:ID>
                </cac:TaxScheme>
            </cac:PartyTaxScheme>
            <cac:PartyLegalEntity>
                <cbc:RegistrationName>MalaysiaDish Restaurant Sdn Bhd</cbc:RegistrationName>
                <cbc:CompanyID>201901123456</cbc:CompanyID>
            </cac:PartyLegalEntity>
        </cac:Party>
    </cac:AccountingSupplierParty>
    
    <cac:AccountingCustomerParty>
        <cac:Party>
            <cac:PartyIdentification>
                <cbc:ID schemeID="MY-TIN">987654321098</cbc:ID>
            </cac:PartyIdentification>
            <cac:PartyName>
                <cbc:Name>Ahmad bin Abdullah</cbc:Name>
            </cac:PartyName>
            <cac:PostalAddress>
                <cbc:StreetName>456 Jalan Ampang</cbc:StreetName>
                <cbc:CityName>Kuala Lumpur</cbc:CityName>
                <cbc:PostalZone>50450</cbc:PostalZone>
                <cac:Country>
                    <cbc:IdentificationCode>MY</cbc:IdentificationCode>
                </cac:Country>
            </cac:PostalAddress>
        </cac:Party>
    </cac:AccountingCustomerParty>
    
    <cac:PaymentMeans>
        <cbc:PaymentMeansCode>30</cbc:PaymentMeansCode>
        <cbc:PaymentID>PAY-20250523-12345</cbc:PaymentID>
    </cac:PaymentMeans>
    
    <cac:TaxTotal>
        <cbc:TaxAmount currencyID="MYR">6.00</cbc:TaxAmount>
        <cac:TaxSubtotal>
            <cbc:TaxableAmount currencyID="MYR">100.00</cbc:TaxableAmount>
            <cbc:TaxAmount currencyID="MYR">6.00</cbc:TaxAmount>
            <cac:TaxCategory>
                <cbc:ID>S</cbc:ID>
                <cbc:Percent>6.00</cbc:Percent>
                <cac:TaxScheme>
                    <cbc:ID>SST</cbc:ID>
                </cac:TaxScheme>
            </cac:TaxCategory>
        </cac:TaxSubtotal>
    </cac:TaxTotal>
    
    <cac:LegalMonetaryTotal>
        <cbc:LineExtensionAmount currencyID="MYR">100.00</cbc:LineExtensionAmount>
        <cbc:TaxExclusiveAmount currencyID="MYR">100.00</cbc:TaxExclusiveAmount>
        <cbc:TaxInclusiveAmount currencyID="MYR">106.00</cbc:TaxInclusiveAmount>
        <cbc:PayableAmount currencyID="MYR">106.00</cbc:PayableAmount>
    </cac:LegalMonetaryTotal>
    
    <cac:InvoiceLine>
        <cbc:ID>1</cbc:ID>
        <cbc:InvoicedQuantity unitCode="EA">2</cbc:InvoicedQuantity>
        <cbc:LineExtensionAmount currencyID="MYR">60.00</cbc:LineExtensionAmount>
        <cac:Item>
            <cbc:Name>Nasi Lemak Special</cbc:Name>
            <cac:SellersItemIdentification>
                <cbc:ID>FOOD-001</cbc:ID>
            </cac:SellersItemIdentification>
            <cac:ClassifiedTaxCategory>
                <cbc:ID>S</cbc:ID>
                <cbc:Percent>6.00</cbc:Percent>
                <cac:TaxScheme>
                    <cbc:ID>SST</cbc:ID>
                </cac:TaxScheme>
            </cac:ClassifiedTaxCategory>
        </cac:Item>
        <cac:Price>
            <cbc:PriceAmount currencyID="MYR">30.00</cbc:PriceAmount>
        </cac:Price>
    </cac:InvoiceLine>
    
    <cac:InvoiceLine>
        <cbc:ID>2</cbc:ID>
        <cbc:InvoicedQuantity unitCode="EA">2</cbc:InvoicedQuantity>
        <cbc:LineExtensionAmount currencyID="MYR">40.00</cbc:LineExtensionAmount>
        <cac:Item>
            <cbc:Name>Teh Tarik</cbc:Name>
            <cac:SellersItemIdentification>
                <cbc:ID>BEV-001</cbc:ID>
            </cac:SellersItemIdentification>
            <cac:ClassifiedTaxCategory>
                <cbc:ID>S</cbc:ID>
                <cbc:Percent>6.00</cbc:Percent>
                <cac:TaxScheme>
                    <cbc:ID>SST</cbc:ID>
                </cac:TaxScheme>
            </cac:ClassifiedTaxCategory>
        </cac:Item>
        <cac:Price>
            <cbc:PriceAmount currencyID="MYR">20.00</cbc:PriceAmount>
        </cac:Price>
    </cac:InvoiceLine>
    
    <ext:IRBMExtension>
        <ext:InvoiceSeriesIdentifier>MDISH-KL-2025</ext:InvoiceSeriesIdentifier>
        <ext:PointOfSaleIdentifier>POS-KL-001</ext:PointOfSaleIdentifier>
    </ext:IRBMExtension>
    
    <!-- Digital Signature would be applied here -->
    
</Invoice>
```

## 6. JSON Implementation

### 6.1 JSON Schema and Validation

The JSON implementation follows the IRBM-specified JSON schema that corresponds to UBL 2.1:

```javascript
// JSON Schema Configuration
const jsonSchema = require('./schemas/irbm-invoice-schema.json');

// JSON Validation Function
function validateInvoiceJSON(jsonDocument) {
  const validator = new JSONSchemaValidator(jsonSchema);
  const validationResult = validator.validate(jsonDocument);
  
  if (!validationResult.valid) {
    throw new ValidationError('Invoice JSON validation failed', validationResult.errors);
  }
  
  return validationResult;
}
```

### 6.2 JSON Generation

The system generates JSON invoices using a transformation approach:

```javascript
// JSON Invoice Generator
class JSONInvoiceGenerator {
  constructor(schemaValidator) {
    this.schemaValidator = schemaValidator;
  }
  
  generateInvoice(invoiceData) {
    // Transform business data to JSON structure
    const jsonInvoice = this.mapToJSONFormat(invoiceData);
    
    // Validate against schema
    this.schemaValidator.validate(jsonInvoice);
    
    // Apply digital signature
    const signedJson = this.applyDigitalSignature(jsonInvoice);
    
    return signedJson;
  }
  
  mapToJSONFormat(invoiceData) {
    // Mapping logic from POS data model to JSON structure
    // ...
  }
  
  applyDigitalSignature(jsonDocument) {
    // JSON Web Signature implementation
    // ...
  }
}
```

### 6.3 Sample JSON Invoice

Below is a sample JSON invoice that meets IRBM requirements:

```json
{
  "Invoice": {
    "UBLVersionID": "2.1",
    "CustomizationID": "urn:my:irbm:einvoice:1.0",
    "ProfileID": "IRBM-E-Invoice",
    "ID": "INV-20250523-12345",
    "IssueDate": "2025-05-23",
    "IssueTime": "14:42:00",
    "InvoiceTypeCode": "380",
    "Note": "Thank you for dining with us!",
    "DocumentCurrencyCode": "MYR",
    "TaxCurrencyCode": "MYR",
    
    "AccountingSupplierParty": {
      "Party": {
        "PartyIdentification": [
          {
            "ID": {
              "value": "123456789012",
              "schemeID": "MY-TIN"
            }
          }
        ],
        "PartyName": [
          {
            "Name": "MalaysiaDish Restaurant Sdn Bhd"
          }
        ],
        "PostalAddress": {
          "StreetName": "123 Jalan Sultan",
          "CityName": "Kuala Lumpur",
          "PostalZone": "50000",
          "Country": {
            "IdentificationCode": "MY"
          }
        },
        "PartyTaxScheme": [
          {
            "CompanyID": "SST-123456789",
            "TaxScheme": {
              "ID": "SST"
            }
          }
        ],
        "PartyLegalEntity": [
          {
            "RegistrationName": "MalaysiaDish Restaurant Sdn Bhd",
            "CompanyID": "201901123456"
          }
        ]
      }
    },
    
    "AccountingCustomerParty": {
      "Party": {
        "PartyIdentification": [
          {
            "ID": {
              "value": "987654321098",
              "schemeID": "MY-TIN"
            }
          }
        ],
        "PartyName": [
          {
            "Name": "Ahmad bin Abdullah"
          }
        ],
        "PostalAddress": {
          "StreetName": "456 Jalan Ampang",
          "CityName": "Kuala Lumpur",
          "PostalZone": "50450",
          "Country": {
            "IdentificationCode": "MY"
          }
        }
      }
    },
    
    "PaymentMeans": [
      {
        "PaymentMeansCode": "30",
        "PaymentID": "PAY-20250523-12345"
      }
    ],
    
    "TaxTotal": [
      {
        "TaxAmount": {
          "value": 6.00,
          "currencyID": "MYR"
        },
        "TaxSubtotal": [
          {
            "TaxableAmount": {
              "value": 100.00,
              "currencyID": "MYR"
            },
            "TaxAmount": {
              "value": 6.00,
              "currencyID": "MYR"
            },
            "TaxCategory": {
              "ID": "S",
              "Percent": 6.00,
              "TaxScheme": {
                "ID": "SST"
              }
            }
          }
        ]
      }
    ],
    
    "LegalMonetaryTotal": {
      "LineExtensionAmount": {
        "value": 100.00,
        "currencyID": "MYR"
      },
      "TaxExclusiveAmount": {
        "value": 100.00,
        "currencyID": "MYR"
      },
      "TaxInclusiveAmount": {
        "value": 106.00,
        "currencyID": "MYR"
      },
      "PayableAmount": {
        "value": 106.00,
        "currencyID": "MYR"
      }
    },
    
    "InvoiceLine": [
      {
        "ID": "1",
        "InvoicedQuantity": {
          "value": 2,
          "unitCode": "EA"
        },
        "LineExtensionAmount": {
          "value": 60.00,
          "currencyID": "MYR"
        },
        "Item": {
          "Name": "Nasi Lemak Special",
          "SellersItemIdentification": {
            "ID": "FOOD-001"
          },
          "ClassifiedTaxCategory": {
            "ID": "S",
            "Percent": 6.00,
            "TaxScheme": {
              "ID": "SST"
            }
          }
        },
        "Price": {
          "PriceAmount": {
            "value": 30.00,
            "currencyID": "MYR"
          }
        }
      },
      {
        "ID": "2",
        "InvoicedQuantity": {
          "value": 2,
          "unitCode": "EA"
        },
        "LineExtensionAmount": {
          "value": 40.00,
          "currencyID": "MYR"
        },
        "Item": {
          "Name": "Teh Tarik",
          "SellersItemIdentification": {
            "ID": "BEV-001"
          },
          "ClassifiedTaxCategory": {
            "ID": "S",
            "Percent": 6.00,
            "TaxScheme": {
              "ID": "SST"
            }
          }
        },
        "Price": {
          "PriceAmount": {
            "value": 20.00,
            "currencyID": "MYR"
          }
        }
      }
    ],
    
    "IRBMExtension": {
      "InvoiceSeriesIdentifier": "MDISH-KL-2025",
      "PointOfSaleIdentifier": "POS-KL-001"
    },
    
    "Signature": {
      // Digital signature would be applied here
    }
  }
}
```

## 7. Digital Signature Implementation

### 7.1 Digital Signature Requirements

IRBM requires digital signatures to ensure:

- **Document Authenticity**: Verify the origin of the invoice
- **Data Integrity**: Detect any modifications to the document
- **Non-Repudiation**: Prevent denial of document creation

### 7.2 XML Digital Signature

For XML invoices, the system implements XML-DSig according to W3C standards:

```javascript
// XML Digital Signature Implementation
class XMLDigitalSignature {
  constructor(certificateManager) {
    this.certificateManager = certificateManager;
  }
  
  signDocument(xmlDocument) {
    // Get the signing certificate and private key
    const { certificate, privateKey } = this.certificateManager.getSigningCredentials();
    
    // Create a signature reference for the entire document
    const signatureReference = this.createSignatureReference(xmlDocument);
    
    // Calculate the digest value
    const digestValue = this.calculateDigest(xmlDocument, signatureReference);
    
    // Create the signature value using the private key
    const signatureValue = this.createSignatureValue(digestValue, privateKey);
    
    // Construct the complete signature element
    const signatureElement = this.constructSignatureElement(
      signatureReference,
      digestValue,
      signatureValue,
      certificate
    );
    
    // Add the signature to the document
    return this.addSignatureToDocument(xmlDocument, signatureElement);
  }
  
  // Implementation details for each step...
}
```

### 7.3 JSON Digital Signature

For JSON invoices, the system implements JSON Web Signature (JWS):

```javascript
// JSON Web Signature Implementation
class JSONWebSignature {
  constructor(certificateManager) {
    this.certificateManager = certificateManager;
  }
  
  signDocument(jsonDocument) {
    // Get the signing certificate and private key
    const { certificate, privateKey } = this.certificateManager.getSigningCredentials();
    
    // Create the JWS header
    const header = {
      alg: 'RS256',
      x5c: [this.certificateManager.encodeCertificate(certificate)]
    };
    
    // Create the JWS payload (the JSON document)
    const payload = JSON.stringify(jsonDocument);
    
    // Create the JWS signature
    const signature = this.createSignature(header, payload, privateKey);
    
    // Construct the complete JWS
    const jws = this.constructJWS(header, payload, signature);
    
    // Add the signature to the document
    return this.addSignatureToDocument(jsonDocument, jws);
  }
  
  // Implementation details for each step...
}
```

### 7.4 Certificate Management

The system includes a comprehensive certificate management component:

```javascript
// Certificate Management
class CertificateManager {
  constructor(config) {
    this.config = config;
    this.certificates = new Map();
    this.privateKeys = new Map();
  }
  
  async initialize() {
    // Load certificates and private keys from secure storage
    await this.loadCertificates();
    await this.loadPrivateKeys();
  }
  
  getSigningCredentials() {
    const certificateId = this.config.signingCertificateId;
    
    if (!this.certificates.has(certificateId) || !this.privateKeys.has(certificateId)) {
      throw new Error(`Signing credentials not found for ID: ${certificateId}`);
    }
    
    return {
      certificate: this.certificates.get(certificateId),
      privateKey: this.privateKeys.get(certificateId)
    };
  }
  
  // Additional certificate management functions...
}
```

## 8. MyInvois Portal Integration

### 8.1 Integration Methods

The system supports two methods for submitting e-invoices to IRBM:

1. **MyInvois Portal Web Interface**: Manual upload through web UI
2. **MyInvois API Integration**: Automated submission via API

### 8.2 API Integration Implementation

The system implements direct API integration with MyInvois:

```javascript
// MyInvois API Client
class MyInvoisApiClient {
  constructor(config, certificateManager) {
    this.config = config;
    this.certificateManager = certificateManager;
    this.baseUrl = 'https://myinvois.hasil.gov.my/api/v1';
  }
  
  async authenticate() {
    const credentials = this.certificateManager.getApiCredentials();
    
    const response = await fetch(`${this.baseUrl}/auth`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        clientId: credentials.clientId,
        clientSecret: credentials.clientSecret
      })
    });
    
    if (!response.ok) {
      throw new Error(`Authentication failed: ${response.statusText}`);
    }
    
    const authResult = await response.json();
    this.authToken = authResult.token;
    this.tokenExpiry = new Date(authResult.expiresAt);
  }
  
  async submitInvoice(invoice, format = 'xml') {
    // Ensure we have a valid authentication token
    if (!this.authToken || new Date() >= this.tokenExpiry) {
      await this.authenticate();
    }
    
    // Prepare the submission payload
    const payload = {
      format: format,
      content: format === 'xml' ? invoice : JSON.stringify(invoice),
      metadata: {
        submissionType: 'REALTIME',
        businessUnitId: this.config.businessUnitId
      }
    };
    
    // Submit the invoice
    const response = await fetch(`${this.baseUrl}/invoices`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${this.authToken}`
      },
      body: JSON.stringify(payload)
    });
    
    if (!response.ok) {
      throw new Error(`Invoice submission failed: ${response.statusText}`);
    }
    
    return await response.json();
  }
  
  async getInvoiceStatus(invoiceId) {
    // Ensure we have a valid authentication token
    if (!this.authToken || new Date() >= this.tokenExpiry) {
      await this.authenticate();
    }
    
    // Get the invoice status
    const response = await fetch(`${this.baseUrl}/invoices/${invoiceId}`, {
      method: 'GET',
      headers: {
        'Authorization': `Bearer ${this.authToken}`
      }
    });
    
    if (!response.ok) {
      throw new Error(`Failed to get invoice status: ${response.statusText}`);
    }
    
    return await response.json();
  }
  
  // Additional API methods...
}
```

### 8.3 Error Handling and Retries

The system implements robust error handling and retry logic:

```javascript
// Retry Logic for API Calls
class RetryHandler {
  constructor(maxRetries = 3, initialDelay = 1000, backoffFactor = 2) {
    this.maxRetries = maxRetries;
    this.initialDelay = initialDelay;
    this.backoffFactor = backoffFactor;
  }
  
  async executeWithRetry(operation) {
    let lastError;
    let delay = this.initialDelay;
    
    for (let attempt = 1; attempt <= this.maxRetries; attempt++) {
      try {
        return await operation();
      } catch (error) {
        lastError = error;
        
        // Check if error is retryable
        if (!this.isRetryable(error)) {
          throw error;
        }
        
        // Log retry attempt
        console.log(`Retry attempt ${attempt}/${this.maxRetries} after error: ${error.message}`);
        
        // Wait before next retry
        await this.delay(delay);
        
        // Increase delay for next attempt
        delay *= this.backoffFactor;
      }
    }
    
    // If we've exhausted all retries, throw the last error
    throw lastError;
  }
  
  isRetryable(error) {
    // Determine if the error is retryable
    // Network errors, rate limits, and certain API errors are retryable
    // Authentication failures and validation errors are not
    
    if (error.name === 'NetworkError') return true;
    if (error.status === 429) return true; // Too Many Requests
    if (error.status >= 500 && error.status < 600) return true; // Server errors
    
    return false;
  }
  
  delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}
```

## 9. Invoice Storage and Retrieval

### 9.1 Storage Implementation

The system implements secure, compliant storage for e-invoices:

```javascript
// Invoice Repository
class InvoiceRepository {
  constructor(database, encryptionService) {
    this.database = database;
    this.encryptionService = encryptionService;
    this.collectionName = 'invoices';
  }
  
  async saveInvoice(invoice, metadata) {
    // Encrypt sensitive data
    const encryptedInvoice = this.encryptionService.encrypt(invoice);
    
    // Prepare the document
    const document = {
      invoiceId: metadata.invoiceId,
      issuedDate: metadata.issuedDate,
      customerInfo: metadata.customerInfo,
      totalAmount: metadata.totalAmount,
      status: metadata.status,
      format: metadata.format,
      content: encryptedInvoice,
      submissionId: metadata.submissionId,
      validationResult: metadata.validationResult,
      createdAt: new Date(),
      updatedAt: new Date()
    };
    
    // Save to database
    const result = await this.database
      .collection(this.collectionName)
      .insertOne(document);
    
    return result.insertedId;
  }
  
  async updateInvoiceStatus(invoiceId, status, validationResult) {
    const result = await this.database
      .collection(this.collectionName)
      .updateOne(
        { invoiceId },
        { 
          $set: { 
            status, 
            validationResult,
            updatedAt: new Date()
          } 
        }
      );
    
    return result.modifiedCount > 0;
  }
  
  async getInvoice(invoiceId) {
    const document = await this.database
      .collection(this.collectionName)
      .findOne({ invoiceId });
    
    if (!document) {
      return null;
    }
    
    // Decrypt the content
    const decryptedContent = this.encryptionService.decrypt(document.content);
    
    return {
      ...document,
      content: decryptedContent
    };
  }
  
  async searchInvoices(criteria) {
    const query = this.buildSearchQuery(criteria);
    
    const documents = await this.database
      .collection(this.collectionName)
      .find(query)
      .sort({ issuedDate: -1 })
      .limit(criteria.limit || 100)
      .skip(criteria.offset || 0)
      .toArray();
    
    // Return without decrypting content for search results
    return documents.map(doc => ({
      ...doc,
      content: undefined // Remove encrypted content from results
    }));
  }
  
  buildSearchQuery(criteria) {
    const query = {};
    
    if (criteria.startDate && criteria.endDate) {
      query.issuedDate = {
        $gte: new Date(criteria.startDate),
        $lte: new Date(criteria.endDate)
      };
    }
    
    if (criteria.customerInfo) {
      query['customerInfo.name'] = { $regex: criteria.customerInfo, $options: 'i' };
    }
    
    if (criteria.status) {
      query.status = criteria.status;
    }
    
    if (criteria.minAmount || criteria.maxAmount) {
      query.totalAmount = {};
      
      if (criteria.minAmount) {
        query.totalAmount.$gte = criteria.minAmount;
      }
      
      if (criteria.maxAmount) {
        query.totalAmount.$lte = criteria.maxAmount;
      }
    }
    
    return query;
  }
  
  // Additional repository methods...
}
```

### 9.2 Encryption Service

The system implements encryption for sensitive invoice data:

```javascript
// Encryption Service
class EncryptionService {
  constructor(keyManager) {
    this.keyManager = keyManager;
    this.algorithm = 'aes-256-gcm';
  }
  
  encrypt(data) {
    // Get the encryption key
    const key = this.keyManager.getEncryptionKey();
    
    // Generate a random initialization vector
    const iv = crypto.randomBytes(16);
    
    // Create cipher
    const cipher = crypto.createCipheriv(this.algorithm, key, iv);
    
    // Encrypt the data
    let encrypted = cipher.update(typeof data === 'string' ? data : JSON.stringify(data), 'utf8', 'base64');
    encrypted += cipher.final('base64');
    
    // Get the authentication tag
    const authTag = cipher.getAuthTag();
    
    // Return the encrypted data with IV and auth tag
    return {
      iv: iv.toString('base64'),
      authTag: authTag.toString('base64'),
      data: encrypted
    };
  }
  
  decrypt(encryptedData) {
    // Get the encryption key
    const key = this.keyManager.getEncryptionKey();
    
    // Parse the IV and auth tag
    const iv = Buffer.from(encryptedData.iv, 'base64');
    const authTag = Buffer.from(encryptedData.authTag, 'base64');
    
    // Create decipher
    const decipher = crypto.createDecipheriv(this.algorithm, key, iv);
    decipher.setAuthTag(authTag);
    
    // Decrypt the data
    let decrypted = decipher.update(encryptedData.data, 'base64', 'utf8');
    decrypted += decipher.final('utf8');
    
    // Parse JSON if the original data was an object
    try {
      return JSON.parse(decrypted);
    } catch (e) {
      return decrypted;
    }
  }
}
```

### 9.3 Retention Policy Implementation

The system implements compliant data retention policies:

```javascript
// Retention Policy Manager
class RetentionPolicyManager {
  constructor(database, config) {
    this.database = database;
    this.config = config;
    this.collectionName = 'invoices';
  }
  
  async applyRetentionPolicy() {
    // Calculate the retention threshold date
    const retentionYears = this.config.invoiceRetentionYears || 7;
    const thresholdDate = new Date();
    thresholdDate.setFullYear(thresholdDate.getFullYear() - retentionYears);
    
    // Find invoices eligible for archiving
    const archiveThresholdDate = new Date();
    archiveThresholdDate.setFullYear(archiveThresholdDate.getFullYear() - 2);
    
    const invoicesToArchive = await this.database
      .collection(this.collectionName)
      .find({
        issuedDate: { $lt: archiveThresholdDate, $gte: thresholdDate },
        archived: { $ne: true }
      })
      .toArray();
    
    // Archive eligible invoices
    for (const invoice of invoicesToArchive) {
      await this.archiveInvoice(invoice);
    }
    
    // Find invoices eligible for deletion
    const result = await this.database
      .collection(this.collectionName)
      .deleteMany({
        issuedDate: { $lt: thresholdDate }
      });
    
    return {
      archivedCount: invoicesToArchive.length,
      deletedCount: result.deletedCount
    };
  }
  
  async archiveInvoice(invoice) {
    // Compress the invoice content
    const compressedContent = await this.compressContent(invoice.content);
    
    // Update the invoice record
    await this.database
      .collection(this.collectionName)
      .updateOne(
        { _id: invoice._id },
        {
          $set: {
            content: compressedContent,
            archived: true,
            archivedAt: new Date()
          }
        }
      );
    
    // Store in cold storage if configured
    if (this.config.coldStorageEnabled) {
      await this.storeToColdStorage(invoice._id, compressedContent);
    }
  }
  
  async compressContent(content) {
    // Implementation of content compression
    // ...
  }
  
  async storeToColdStorage(invoiceId, compressedContent) {
    // Implementation of cold storage (e.g., AWS Glacier)
    // ...
  }
}
```

## 10. Reporting and Monitoring

### 10.1 Compliance Reporting

The system generates compliance reports for regulatory purposes:

```javascript
// Compliance Reporting Service
class ComplianceReportingService {
  constructor(database, config) {
    this.database = database;
    this.config = config;
    this.collectionName = 'invoices';
  }
  
  async generateMonthlyComplianceReport(year, month) {
    // Calculate date range for the month
    const startDate = new Date(year, month - 1, 1);
    const endDate = new Date(year, month, 0, 23, 59, 59, 999);
    
    // Get all invoices for the month
    const invoices = await this.database
      .collection(this.collectionName)
      .find({
        issuedDate: { $gte: startDate, $lte: endDate }
      })
      .toArray();
    
    // Calculate statistics
    const statistics = this.calculateStatistics(invoices);
    
    // Generate the report
    const report = {
      reportPeriod: {
        year,
        month,
        startDate,
        endDate
      },
      businessInfo: this.config.businessInfo,
      statistics,
      generatedAt: new Date()
    };
    
    // Save the report
    await this.database
      .collection('complianceReports')
      .insertOne(report);
    
    return report;
  }
  
  calculateStatistics(invoices) {
    return {
      totalInvoices: invoices.length,
      totalAmount: invoices.reduce((sum, inv) => sum + inv.totalAmount, 0),
      totalTax: invoices.reduce((sum, inv) => sum + (inv.taxAmount || 0), 0),
      statusBreakdown: this.calculateStatusBreakdown(invoices),
      validationErrors: this.summarizeValidationErrors(invoices),
      averageProcessingTime: this.calculateAverageProcessingTime(invoices)
    };
  }
  
  calculateStatusBreakdown(invoices) {
    const breakdown = {};
    
    for (const invoice of invoices) {
      const status = invoice.status || 'UNKNOWN';
      breakdown[status] = (breakdown[status] || 0) + 1;
    }
    
    return breakdown;
  }
  
  summarizeValidationErrors(invoices) {
    const errorSummary = {};
    
    for (const invoice of invoices) {
      if (invoice.validationResult && invoice.validationResult.errors) {
        for (const error of invoice.validationResult.errors) {
          const errorCode = error.code || 'UNKNOWN';
          errorSummary[errorCode] = (errorSummary[errorCode] || 0) + 1;
        }
      }
    }
    
    return errorSummary;
  }
  
  calculateAverageProcessingTime(invoices) {
    let totalTime = 0;
    let count = 0;
    
    for (const invoice of invoices) {
      if (invoice.submittedAt && invoice.processedAt) {
        const processingTime = invoice.processedAt - invoice.submittedAt;
        totalTime += processingTime;
        count++;
      }
    }
    
    return count > 0 ? totalTime / count : 0;
  }
  
  // Additional reporting methods...
}
```

### 10.2 Monitoring and Alerting

The system implements comprehensive monitoring and alerting:

```javascript
// E-Invoice Monitoring Service
class EInvoiceMonitoringService {
  constructor(database, notificationService, config) {
    this.database = database;
    this.notificationService = notificationService;
    this.config = config;
    this.collectionName = 'invoices';
  }
  
  async monitorSubmissionStatus() {
    // Find pending submissions
    const pendingInvoices = await this.database
      .collection(this.collectionName)
      .find({
        status: 'SUBMITTED',
        submittedAt: { $lt: new Date(Date.now() - this.config.pendingThresholdMs) }
      })
      .toArray();
    
    if (pendingInvoices.length > 0) {
      // Alert on long-pending submissions
      await this.notificationService.sendAlert({
        type: 'PENDING_SUBMISSIONS',
        severity: 'WARNING',
        message: `${pendingInvoices.length} invoices have been pending for more than ${this.config.pendingThresholdMs / 60000} minutes`,
        details: pendingInvoices.map(inv => inv.invoiceId)
      });
    }
    
    // Find failed submissions
    const failedInvoices = await this.database
      .collection(this.collectionName)
      .find({
        status: 'FAILED',
        updatedAt: { $gt: new Date(Date.now() - 86400000) } // Last 24 hours
      })
      .toArray();
    
    if (failedInvoices.length > 0) {
      // Alert on failed submissions
      await this.notificationService.sendAlert({
        type: 'FAILED_SUBMISSIONS',
        severity: 'ERROR',
        message: `${failedInvoices.length} invoices have failed submission in the last 24 hours`,
        details: failedInvoices.map(inv => ({
          invoiceId: inv.invoiceId,
          error: inv.validationResult?.errors || 'Unknown error'
        }))
      });
    }
    
    // Monitor validation error trends
    await this.monitorValidationErrorTrends();
  }
  
  async monitorValidationErrorTrends() {
    // Get validation errors from the last 7 days
    const startDate = new Date(Date.now() - 7 * 86400000);
    
    const pipeline = [
      {
        $match: {
          updatedAt: { $gte: startDate },
          'validationResult.errors': { $exists: true, $ne: [] }
        }
      },
      {
        $unwind: '$validationResult.errors'
      },
      {
        $group: {
          _id: '$validationResult.errors.code',
          count: { $sum: 1 },
          examples: { $push: { invoiceId: '$invoiceId', message: '$validationResult.errors.message' } }
        }
      },
      {
        $sort: { count: -1 }
      }
    ];
    
    const errorTrends = await this.database
      .collection(this.collectionName)
      .aggregate(pipeline)
      .toArray();
    
    // Alert on significant error trends
    for (const trend of errorTrends) {
      if (trend.count >= this.config.errorTrendThreshold) {
        await this.notificationService.sendAlert({
          type: 'ERROR_TREND',
          severity: 'WARNING',
          message: `Validation error code ${trend._id} has occurred ${trend.count} times in the last 7 days`,
          details: {
            errorCode: trend._id,
            count: trend.count,
            examples: trend.examples.slice(0, 5) // First 5 examples
          }
        });
      }
    }
  }
  
  // Additional monitoring methods...
}
```

## 11. Testing and Validation

### 11.1 Unit Testing

The system includes comprehensive unit tests for e-invoicing components:

```javascript
// Example Unit Tests for Invoice Generator
describe('XMLInvoiceGenerator', () => {
  let generator;
  let schemaValidator;
  let templateEngine;
  
  beforeEach(() => {
    schemaValidator = {
      validate: jest.fn().mockReturnValue({ valid: true })
    };
    
    templateEngine = {
      render: jest.fn().mockReturnValue('<Invoice>Test Invoice</Invoice>')
    };
    
    generator = new XMLInvoiceGenerator(templateEngine, schemaValidator);
    generator.mapToUBLFormat = jest.fn().mockReturnValue({ mappedData: 'test' });
    generator.applyDigitalSignature = jest.fn().mockReturnValue('<Invoice>Test Invoice<Signature>Test</Signature></Invoice>');
  });
  
  test('should generate a valid XML invoice', () => {
    const invoiceData = {
      id: 'INV-12345',
      customer: { name: 'Test Customer' },
      items: [{ name: 'Test Item', price: 100 }]
    };
    
    const result = generator.generateInvoice(invoiceData);
    
    expect(generator.mapToUBLFormat).toHaveBeenCalledWith(invoiceData);
    expect(templateEngine.render).toHaveBeenCalledWith('ubl21-invoice.xml', { mappedData: 'test' });
    expect(schemaValidator.validate).toHaveBeenCalledWith('<Invoice>Test Invoice</Invoice>');
    expect(generator.applyDigitalSignature).toHaveBeenCalledWith('<Invoice>Test Invoice</Invoice>');
    expect(result).toBe('<Invoice>Test Invoice<Signature>Test</Signature></Invoice>');
  });
  
  test('should throw error when validation fails', () => {
    schemaValidator.validate.mockReturnValue({ 
      valid: false, 
      errors: [{ message: 'Invalid invoice' }] 
    });
    
    const invoiceData = {
      id: 'INV-12345',
      customer: { name: 'Test Customer' },
      items: [{ name: 'Test Item', price: 100 }]
    };
    
    expect(() => generator.generateInvoice(invoiceData)).toThrow('Invoice XML validation failed');
  });
  
  // Additional tests...
});
```

### 11.2 Integration Testing

The system includes integration tests for e-invoicing workflows:

```javascript
// Example Integration Tests for E-Invoicing Service
describe('E-Invoicing Service Integration', () => {
  let eInvoicingService;
  let invoiceRepository;
  let myInvoisApiClient;
  
  beforeEach(async () => {
    // Setup test database
    const testDb = await setupTestDatabase();
    
    // Mock API client
    myInvoisApiClient = {
      submitInvoice: jest.fn().mockResolvedValue({
        submissionId: 'SUB-12345',
        status: 'ACCEPTED'
      }),
      getInvoiceStatus: jest.fn().mockResolvedValue({
        submissionId: 'SUB-12345',
        status: 'PROCESSED',
        validationResult: { valid: true }
      })
    };
    
    // Setup repository with test database
    invoiceRepository = new InvoiceRepository(testDb, new MockEncryptionService());
    
    // Setup e-invoicing service
    eInvoicingService = new EInvoicingService({
      invoiceRepository,
      xmlGenerator: new MockXMLGenerator(),
      jsonGenerator: new MockJSONGenerator(),
      apiClient: myInvoisApiClient,
      config: { defaultFormat: 'xml' }
    });
  });
  
  test('should process invoice through the complete workflow', async () => {
    // Test invoice data
    const invoiceData = {
      id: 'TEST-INV-12345',
      issuedDate: new Date(),
      customer: {
        name: 'Test Customer',
        taxId: '987654321098'
      },
      items: [
        { name: 'Test Item', quantity: 1, price: 100 }
      ],
      totalAmount: 106,
      taxAmount: 6
    };
    
    // Process the invoice
    const result = await eInvoicingService.processInvoice(invoiceData);
    
    // Verify API client was called
    expect(myInvoisApiClient.submitInvoice).toHaveBeenCalled();
    
    // Verify invoice was saved to repository
    const savedInvoice = await invoiceRepository.getInvoice('TEST-INV-12345');
    expect(savedInvoice).not.toBeNull();
    expect(savedInvoice.status).toBe('PROCESSED');
    
    // Verify result
    expect(result).toEqual({
      invoiceId: 'TEST-INV-12345',
      submissionId: 'SUB-12345',
      status: 'PROCESSED',
      success: true
    });
  });
  
  test('should handle validation errors', async () => {
    // Mock API client to return validation error
    myInvoisApiClient.submitInvoice.mockResolvedValue({
      submissionId: 'SUB-ERROR',
      status: 'REJECTED',
      validationResult: {
        valid: false,
        errors: [
          { code: 'E1001', message: 'Invalid tax calculation' }
        ]
      }
    });
    
    // Test invoice data with error
    const invoiceData = {
      id: 'TEST-INV-ERROR',
      issuedDate: new Date(),
      customer: {
        name: 'Test Customer',
        taxId: '987654321098'
      },
      items: [
        { name: 'Test Item', quantity: 1, price: 100 }
      ],
      totalAmount: 100, // Missing tax
      taxAmount: 0
    };
    
    // Process the invoice
    const result = await eInvoicingService.processInvoice(invoiceData);
    
    // Verify invoice was saved with error status
    const savedInvoice = await invoiceRepository.getInvoice('TEST-INV-ERROR');
    expect(savedInvoice).not.toBeNull();
    expect(savedInvoice.status).toBe('REJECTED');
    
    // Verify result includes error
    expect(result).toEqual({
      invoiceId: 'TEST-INV-ERROR',
      submissionId: 'SUB-ERROR',
      status: 'REJECTED',
      success: false,
      errors: [
        { code: 'E1001', message: 'Invalid tax calculation' }
      ]
    });
  });
  
  // Additional integration tests...
});
```

### 11.3 IRBM Compliance Testing

The system includes specific tests for IRBM compliance:

```javascript
// Example IRBM Compliance Tests
describe('IRBM Compliance Tests', () => {
  let xmlGenerator;
  let jsonGenerator;
  let irbmValidator;
  
  beforeEach(() => {
    // Setup generators
    xmlGenerator = new XMLInvoiceGenerator(
      new TemplateEngine(),
      new XMLValidator(ubl21Schema)
    );
    
    jsonGenerator = new JSONInvoiceGenerator(
      new JSONSchemaValidator(jsonSchema)
    );
    
    // Setup IRBM validator
    irbmValidator = new IRBMComplianceValidator();
  });
  
  test('XML invoice should meet all IRBM requirements', () => {
    // Test invoice data with all required fields
    const invoiceData = createCompleteInvoiceData();
    
    // Generate XML invoice
    const xmlInvoice = xmlGenerator.generateInvoice(invoiceData);
    
    // Validate against IRBM requirements
    const validationResult = irbmValidator.validateXML(xmlInvoice);
    
    // Verify compliance
    expect(validationResult.valid).toBe(true);
    expect(validationResult.errors).toHaveLength(0);
  });
  
  test('JSON invoice should meet all IRBM requirements', () => {
    // Test invoice data with all required fields
    const invoiceData = createCompleteInvoiceData();
    
    // Generate JSON invoice
    const jsonInvoice = jsonGenerator.generateInvoice(invoiceData);
    
    // Validate against IRBM requirements
    const validationResult = irbmValidator.validateJSON(jsonInvoice);
    
    // Verify compliance
    expect(validationResult.valid).toBe(true);
    expect(validationResult.errors).toHaveLength(0);
  });
  
  test('Should detect missing required fields', () => {
    // Test invoice data with missing fields
    const incompleteInvoiceData = {
      id: 'TEST-INV-INCOMPLETE',
      issuedDate: new Date(),
      // Missing customer tax ID
      customer: {
        name: 'Test Customer'
      },
      items: [
        { name: 'Test Item', quantity: 1, price: 100 }
      ],
      totalAmount: 106,
      taxAmount: 6
    };
    
    // Generate XML invoice
    const xmlInvoice = xmlGenerator.generateInvoice(incompleteInvoiceData);
    
    // Validate against IRBM requirements
    const validationResult = irbmValidator.validateXML(xmlInvoice);
    
    // Verify validation failure
    expect(validationResult.valid).toBe(false);
    expect(validationResult.errors).toContainEqual(
      expect.objectContaining({
        code: 'MISSING_CUSTOMER_TAX_ID',
        path: '/Invoice/AccountingCustomerParty/Party/PartyIdentification/ID'
      })
    );
  });
  
  // Additional compliance tests...
});
```

## 12. Deployment and Operations

### 12.1 Deployment Configuration

The e-invoicing service is deployed as part of the MalaysiaDish POS system:

```javascript
// E-Invoicing Service Deployment Configuration
const eInvoicingServiceConfig = {
  // Service configuration
  service: {
    name: 'e-invoicing-service',
    version: '1.0.0',
    port: 3001,
    healthCheckPath: '/health'
  },
  
  // Database configuration
  database: {
    uri: process.env.MONGODB_URI || 'mongodb://localhost:27017/malaysiadish',
    options: {
      useNewUrlParser: true,
      useUnifiedTopology: true
    },
    collections: {
      invoices: 'invoices',
      reports: 'complianceReports'
    }
  },
  
  // IRBM API configuration
  irbmApi: {
    baseUrl: process.env.IRBM_API_URL || 'https://myinvois.hasil.gov.my/api/v1',
    clientId: process.env.IRBM_CLIENT_ID,
    clientSecret: process.env.IRBM_CLIENT_SECRET,
    businessUnitId: process.env.IRBM_BUSINESS_UNIT_ID,
    timeout: 30000, // 30 seconds
    retryConfig: {
      maxRetries: 3,
      initialDelay: 1000,
      backoffFactor: 2
    }
  },
  
  // Security configuration
  security: {
    encryptionKeyId: process.env.ENCRYPTION_KEY_ID,
    signingCertificateId: process.env.SIGNING_CERTIFICATE_ID,
    keyVaultUri: process.env.KEY_VAULT_URI
  },
  
  // Invoice configuration
  invoice: {
    defaultFormat: 'xml',
    retentionYears: 7,
    archiveAfterYears: 2,
    coldStorageEnabled: true,
    coldStorageConfig: {
      provider: 'aws',
      bucketName: process.env.COLD_STORAGE_BUCKET,
      region: process.env.AWS_REGION
    }
  },
  
  // Monitoring configuration
  monitoring: {
    pendingThresholdMs: 15 * 60 * 1000, // 15 minutes
    errorTrendThreshold: 10, // Alert if error occurs 10+ times in 7 days
    alertEndpoints: {
      email: process.env.ALERT_EMAIL,
      webhook: process.env.ALERT_WEBHOOK
    }
  }
};
```

### 12.2 Operational Procedures

The system includes operational procedures for e-invoicing:

```javascript
// E-Invoicing Service Operations
class EInvoicingOperations {
  constructor(eInvoicingService, invoiceRepository, config) {
    this.eInvoicingService = eInvoicingService;
    this.invoiceRepository = invoiceRepository;
    this.config = config;
  }
  
  async reprocessFailedInvoices(timeframe = '24h') {
    // Calculate the time threshold
    const thresholdDate = new Date();
    const hours = parseInt(timeframe.replace('h', ''));
    thresholdDate.setHours(thresholdDate.getHours() - hours);
    
    // Find failed invoices
    const failedInvoices = await this.invoiceRepository.findByStatus(
      'FAILED',
      thresholdDate
    );
    
    console.log(`Found ${failedInvoices.length} failed invoices to reprocess`);
    
    // Reprocess each invoice
    const results = {
      success: 0,
      failure: 0,
      details: []
    };
    
    for (const invoice of failedInvoices) {
      try {
        // Reprocess the invoice
        const result = await this.eInvoicingService.reprocessInvoice(invoice.invoiceId);
        
        if (result.success) {
          results.success++;
        } else {
          results.failure++;
        }
        
        results.details.push({
          invoiceId: invoice.invoiceId,
          status: result.status,
          success: result.success,
          errors: result.errors
        });
      } catch (error) {
        results.failure++;
        results.details.push({
          invoiceId: invoice.invoiceId,
          status: 'ERROR',
          success: false,
          errors: [{ message: error.message }]
        });
      }
    }
    
    return results;
  }
  
  async generateMissingInvoices(startDate, endDate) {
    // Find transactions that don't have corresponding invoices
    const transactions = await this.findTransactionsWithoutInvoices(startDate, endDate);
    
    console.log(`Found ${transactions.length} transactions without invoices`);
    
    // Generate invoices for each transaction
    const results = {
      success: 0,
      failure: 0,
      details: []
    };
    
    for (const transaction of transactions) {
      try {
        // Convert transaction to invoice data
        const invoiceData = this.convertTransactionToInvoiceData(transaction);
        
        // Process the invoice
        const result = await this.eInvoicingService.processInvoice(invoiceData);
        
        if (result.success) {
          results.success++;
        } else {
          results.failure++;
        }
        
        results.details.push({
          transactionId: transaction.id,
          invoiceId: result.invoiceId,
          status: result.status,
          success: result.success,
          errors: result.errors
        });
      } catch (error) {
        results.failure++;
        results.details.push({
          transactionId: transaction.id,
          status: 'ERROR',
          success: false,
          errors: [{ message: error.message }]
        });
      }
    }
    
    return results;
  }
  
  async findTransactionsWithoutInvoices(startDate, endDate) {
    // Implementation to find transactions without invoices
    // ...
  }
  
  convertTransactionToInvoiceData(transaction) {
    // Implementation to convert transaction to invoice data
    // ...
  }
  
  // Additional operational methods...
}
```

## 13. Conclusion

The e-invoicing compliance implementation for MalaysiaDish POS system provides a robust, secure, and compliant solution for meeting IRBM requirements. The system supports both XML and JSON formats according to the UBL 2.1 standard, implements digital signatures for document authenticity, and provides seamless integration with the MyInvois Portal and API.

Key features of the implementation include:

1. **Compliant Invoice Generation**: Creates invoices that meet all IRBM requirements
2. **Secure Digital Signatures**: Ensures document authenticity and integrity
3. **Flexible Format Support**: Handles both XML and JSON as required by IRBM
4. **Robust API Integration**: Connects directly with MyInvois for automated submission
5. **Secure Storage**: Implements encrypted, compliant invoice storage
6. **Comprehensive Reporting**: Provides detailed compliance reports
7. **Monitoring and Alerting**: Proactively identifies and addresses issues
8. **Thorough Testing**: Ensures compliance through comprehensive test coverage

This implementation ensures that MalaysiaDish POS users will be fully compliant with the mandatory e-invoicing requirements by the July 1, 2025 deadline, while providing a seamless and efficient invoicing experience.
