# MalaysiaDish POS: Self-Service and Kiosk Capabilities

## 1. Introduction

This document details the implementation of self-service and kiosk capabilities for the MalaysiaDish POS system. These features enable F&B businesses to offer customers autonomous ordering and payment experiences while maintaining security, accessibility, and integration with the core POS system. The implementation addresses both hardware and software aspects, with a focus on creating an intuitive, accessible, and secure user experience tailored for the Malaysian market.

## 2. Self-Service Architecture Overview

The self-service capabilities are implemented through a dedicated Self-Service Module within the MalaysiaDish POS microservices architecture. This module interacts with other system components to provide a seamless customer experience while maintaining security and operational efficiency.

![Self-Service Architecture](self_service_architecture.png)

### 2.1 Core Components

#### 2.1.1 Kiosk Application Layer
- **UI Framework**: React-based frontend with responsive design
- **State Management**: Redux for application state handling
- **Rendering Engine**: Optimized for touchscreen interactions
- **Accessibility Engine**: Compliance with WCAG 2.1 standards
- **Internationalization**: Support for multiple languages

#### 2.1.2 Kiosk Service Layer
- **Session Manager**: Handles customer session lifecycle
- **Order Processor**: Manages order creation and modification
- **Payment Gateway**: Secure payment processing interface
- **Menu Service Client**: Retrieves and caches menu data
- **Customer Recognition**: Optional loyalty integration

#### 2.1.3 Kiosk Device Management
- **Device Monitoring**: Health and status tracking
- **Remote Management**: Configuration and updates
- **Diagnostics**: Troubleshooting and error reporting
- **Security Monitoring**: Intrusion and tamper detection
- **Power Management**: Energy optimization and recovery

#### 2.1.4 Integration Interfaces
- **Core POS Integration**: Synchronization with main POS
- **Kitchen Display Integration**: Order routing to preparation areas
- **Payment Processor Integration**: Secure payment handling
- **Loyalty System Integration**: Customer recognition and rewards
- **Analytics Integration**: Usage data collection and analysis

## 3. Kiosk Interface Design

### 3.1 User Interface Principles

The kiosk interface follows key design principles to ensure usability across diverse customer segments:

#### 3.1.1 Design Philosophy
- **Simplicity**: Minimalist design with clear visual hierarchy
- **Intuitiveness**: Self-explanatory navigation requiring minimal instruction
- **Consistency**: Uniform patterns and behaviors throughout the experience
- **Efficiency**: Streamlined flows minimizing time and effort
- **Localization**: Cultural adaptation for Malaysian context

#### 3.1.2 Visual Design
- **Color System**: High-contrast palette supporting accessibility
- **Typography**: Clear, readable fonts at appropriate sizes
- **Iconography**: Universally recognizable icons with labels
- **Layout**: Spacious design accommodating touch interaction
- **Branding**: Customizable elements for merchant identity

```css
/* Core Design System Variables */
:root {
  /* Primary Colors */
  --primary-color: #0D47A1;
  --primary-light: #5472D3;
  --primary-dark: #002171;
  
  /* Secondary Colors */
  --secondary-color: #FF6D00;
  --secondary-light: #FF9E40;
  --secondary-dark: #C43C00;
  
  /* Neutral Colors */
  --neutral-100: #FFFFFF;
  --neutral-200: #F5F5F5;
  --neutral-300: #E0E0E0;
  --neutral-400: #BDBDBD;
  --neutral-500: #9E9E9E;
  --neutral-600: #757575;
  --neutral-700: #616161;
  --neutral-800: #424242;
  --neutral-900: #212121;
  
  /* Semantic Colors */
  --success-color: #2E7D32;
  --warning-color: #F57F17;
  --error-color: #C62828;
  --info-color: #1565C0;
  
  /* Typography */
  --font-family-primary: 'Noto Sans', 'Noto Sans CJK SC', sans-serif;
  --font-family-secondary: 'Roboto', 'Noto Sans CJK SC', sans-serif;
  
  /* Font Sizes */
  --font-size-xxl: 2.5rem;   /* 40px */
  --font-size-xl: 2rem;      /* 32px */
  --font-size-lg: 1.5rem;    /* 24px */
  --font-size-md: 1.25rem;   /* 20px */
  --font-size-base: 1rem;    /* 16px */
  --font-size-sm: 0.875rem;  /* 14px */
  --font-size-xs: 0.75rem;   /* 12px */
  
  /* Spacing */
  --spacing-xxs: 0.25rem;    /* 4px */
  --spacing-xs: 0.5rem;      /* 8px */
  --spacing-sm: 0.75rem;     /* 12px */
  --spacing-md: 1rem;        /* 16px */
  --spacing-lg: 1.5rem;      /* 24px */
  --spacing-xl: 2rem;        /* 32px */
  --spacing-xxl: 3rem;       /* 48px */
  
  /* Border Radius */
  --border-radius-sm: 0.25rem;  /* 4px */
  --border-radius-md: 0.5rem;   /* 8px */
  --border-radius-lg: 1rem;     /* 16px */
  --border-radius-pill: 9999px;
  
  /* Shadows */
  --shadow-sm: 0 1px 2px 0 rgba(0, 0, 0, 0.05);
  --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1), 0 2px 4px -1px rgba(0, 0, 0, 0.06);
  --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
  
  /* Animation */
  --transition-fast: 150ms;
  --transition-normal: 250ms;
  --transition-slow: 350ms;
  --easing-standard: cubic-bezier(0.4, 0, 0.2, 1);
}

/* Accessibility Overrides */
.high-contrast-mode {
  --primary-color: #0000C8;
  --secondary-color: #D04500;
  --neutral-100: #FFFFFF;
  --neutral-900: #000000;
  --success-color: #006400;
  --error-color: #C80000;
  --font-size-base: 1.125rem; /* 18px */
}

.large-text-mode {
  --font-size-xxl: 3rem;     /* 48px */
  --font-size-xl: 2.5rem;    /* 40px */
  --font-size-lg: 2rem;      /* 32px */
  --font-size-md: 1.75rem;   /* 28px */
  --font-size-base: 1.5rem;  /* 24px */
  --font-size-sm: 1.25rem;   /* 20px */
  --font-size-xs: 1rem;      /* 16px */
}
```

#### 3.1.3 Interaction Design
- **Touch Targets**: Large, well-spaced interactive elements
- **Feedback**: Visual, auditory, and haptic feedback for actions
- **Error Prevention**: Confirmation for significant actions
- **Error Recovery**: Clear paths to correct mistakes
- **Progressive Disclosure**: Information revealed as needed

### 3.2 User Flow Design

The kiosk interface implements optimized flows for different customer scenarios:

#### 3.2.1 Core User Flows

**Main Menu Flow**
1. Welcome/Language Selection Screen
2. Optional Customer Identification (Loyalty/QR)
3. Menu Category Selection
4. Item Browsing and Selection
5. Item Customization
6. Cart Review
7. Payment Method Selection
8. Payment Processing
9. Order Confirmation
10. Thank You/Next Customer

**Quick Reorder Flow**
1. Customer Identification
2. Previous Order Display
3. Order Modification (Optional)
4. Payment
5. Confirmation

**Combo Meal Flow**
1. Combo Selection
2. Required Choices Selection
3. Optional Add-ons
4. Cart Addition
5. Continue or Checkout

```javascript
// User Flow State Machine
class KioskFlowManager {
  constructor(sessionManager, menuService, orderService, paymentService) {
    this.sessionManager = sessionManager;
    this.menuService = menuService;
    this.orderService = orderService;
    this.paymentService = paymentService;
    
    this.currentState = 'WELCOME';
    this.flowHistory = [];
    this.currentOrder = null;
    this.currentCustomer = null;
  }
  
  async initialize() {
    // Start new session
    await this.sessionManager.startSession();
    
    // Load initial menu data
    await this.menuService.preloadCategories();
    
    // Set initial state
    this.transitionTo('WELCOME');
  }
  
  async transitionTo(newState, data = {}) {
    // Record history for back navigation
    this.flowHistory.push(this.currentState);
    
    // Update state
    const previousState = this.currentState;
    this.currentState = newState;
    
    // Execute entry actions for the new state
    await this.executeStateActions(newState, previousState, data);
    
    // Return state information for UI updates
    return {
      currentState: this.currentState,
      canGoBack: this.canGoBack(),
      stateData: this.getStateData()
    };
  }
  
  async executeStateActions(state, previousState, data) {
    switch (state) {
      case 'WELCOME':
        // Reset session data
        this.currentOrder = null;
        this.currentCustomer = null;
        await this.sessionManager.resetSession();
        break;
        
      case 'LANGUAGE_SELECTION':
        // No special actions needed
        break;
        
      case 'CUSTOMER_IDENTIFICATION':
        if (data.method === 'LOYALTY_CARD' && data.cardId) {
          this.currentCustomer = await this.sessionManager.identifyCustomer(data.cardId);
          if (this.currentCustomer) {
            // Skip to menu if customer identified
            return this.transitionTo('MENU_CATEGORIES');
          }
        }
        break;
        
      case 'MENU_CATEGORIES':
        // Load full category data if not already loaded
        if (!this.menuService.areCategoriesLoaded()) {
          await this.menuService.loadCategories();
        }
        
        // Initialize order if needed
        if (!this.currentOrder) {
          this.currentOrder = await this.orderService.createOrder({
            customerId: this.currentCustomer?.id,
            orderType: 'KIOSK',
            tableNumber: null
          });
        }
        break;
        
      case 'MENU_ITEMS':
        // Load items for selected category
        await this.menuService.loadItemsByCategory(data.categoryId);
        break;
        
      case 'ITEM_CUSTOMIZATION':
        // Load customization options for item
        await this.menuService.loadItemCustomizations(data.itemId);
        break;
        
      case 'CART_REVIEW':
        // Validate order and calculate totals
        await this.orderService.validateOrder(this.currentOrder.id);
        break;
        
      case 'PAYMENT_METHOD_SELECTION':
        // Load available payment methods
        await this.paymentService.getAvailablePaymentMethods();
        break;
        
      case 'PAYMENT_PROCESSING':
        // Initiate payment flow
        const paymentResult = await this.paymentService.processPayment({
          orderId: this.currentOrder.id,
          amount: this.currentOrder.totalAmount,
          method: data.paymentMethod
        });
        
        // Transition based on payment result
        if (paymentResult.success) {
          return this.transitionTo('ORDER_CONFIRMATION', { 
            paymentResult 
          });
        } else {
          return this.transitionTo('PAYMENT_ERROR', { 
            error: paymentResult.error 
          });
        }
        break;
        
      case 'ORDER_CONFIRMATION':
        // Finalize order
        await this.orderService.finalizeOrder(this.currentOrder.id);
        
        // Start order preparation
        await this.orderService.sendToKitchen(this.currentOrder.id);
        break;
        
      case 'THANK_YOU':
        // Set session timeout to return to welcome
        this.sessionManager.setSessionTimeout(() => {
          this.transitionTo('WELCOME');
        }, 30000); // 30 seconds
        break;
        
      default:
        console.log(`No specific actions for state: ${state}`);
    }
  }
  
  canGoBack() {
    // Determine if back navigation is possible
    return this.flowHistory.length > 0 && 
           !['PAYMENT_PROCESSING', 'ORDER_CONFIRMATION', 'THANK_YOU'].includes(this.currentState);
  }
  
  async goBack() {
    if (this.canGoBack()) {
      const previousState = this.flowHistory.pop();
      // Direct transition without adding to history
      this.currentState = previousState;
      return {
        currentState: this.currentState,
        canGoBack: this.canGoBack(),
        stateData: this.getStateData()
      };
    }
    return null;
  }
  
  getStateData() {
    // Return relevant data for current state
    switch (this.currentState) {
      case 'MENU_CATEGORIES':
        return {
          categories: this.menuService.getCategories(),
          featuredItems: this.menuService.getFeaturedItems(),
          customerName: this.currentCustomer?.name
        };
        
      case 'MENU_ITEMS':
        return {
          items: this.menuService.getCurrentCategoryItems(),
          categoryName: this.menuService.getCurrentCategory()?.name
        };
        
      case 'CART_REVIEW':
        return {
          orderItems: this.currentOrder.items,
          subtotal: this.currentOrder.subtotal,
          tax: this.currentOrder.tax,
          total: this.currentOrder.totalAmount,
          discounts: this.currentOrder.discounts
        };
        
      // Additional cases for other states
        
      default:
        return {};
    }
  }
}
```

#### 3.2.2 Special Flows

**Accessibility Mode Flow**
1. Accessibility Mode Activation
2. Simplified Menu Navigation
3. Enhanced Visual/Audio Assistance
4. Extended Timeouts
5. Assistance Request Option

**Group Order Flow**
1. Initial Order Creation
2. Multiple Item Selection Across Categories
3. Order Review
4. Single Payment for Group
5. Order Confirmation with Identifiers

**Loyalty Integration Flow**
1. Member Identification (Card/QR/Phone)
2. Personalized Welcome
3. Reward Status Display
4. Personalized Recommendations
5. Point Earning/Redemption Options

### 3.3 Screen Designs

The kiosk interface includes the following key screens:

#### 3.3.1 Welcome and Language Selection
- Multilingual welcome screen (Bahasa Malaysia, English, Chinese, Tamil)
- Clear language selection buttons with flags and text
- Accessibility mode toggle
- Branded visuals and animations

#### 3.3.2 Menu Navigation
- Category display with images and text
- Featured items carousel
- Search functionality
- Dietary filter options (Halal, Vegetarian, etc.)
- Special promotions section

#### 3.3.3 Item Selection and Customization
- High-quality food imagery
- Clear pricing information
- Ingredient listing
- Customization options
- Quantity selector
- Add to cart button

#### 3.3.4 Cart and Checkout
- Order summary with images
- Edit/remove item controls
- Subtotal, tax, and total calculations
- Discount application section
- Clear call-to-action for checkout

#### 3.3.5 Payment
- Payment method selection
- Integrated card reader interface
- QR code for mobile payments
- Cash payment instructions (if applicable)
- Receipt options (print/email/SMS)

## 4. Accessibility Implementation

### 4.1 Accessibility Standards Compliance

The kiosk interface adheres to international accessibility standards while considering Malaysian requirements:

#### 4.1.1 WCAG 2.1 Compliance
- **Level AA Compliance**: Meeting Web Content Accessibility Guidelines
- **Perceivable**: Content presentable in multiple ways
- **Operable**: Interface operable through various methods
- **Understandable**: Information and operation understandable
- **Robust**: Content interpretable by assistive technologies

#### 4.1.2 Physical Accessibility
- **Height Adjustability**: Support for different user heights (where hardware allows)
- **Reach Range**: Interactive elements within accessible reach zones
- **Approach Space**: Sufficient space for wheelchair users
- **Stability**: Secure mounting and stability

```javascript
// Accessibility Controller
class AccessibilityController {
  constructor(uiManager, settingsService) {
    this.uiManager = uiManager;
    this.settingsService = settingsService;
    this.currentProfile = 'STANDARD';
    this.availableProfiles = {
      'STANDARD': {
        fontSize: 'normal',
        contrast: 'normal',
        animations: 'enabled',
        audioFeedback: 'minimal',
        interactionTiming: 'normal'
      },
      'VISION_IMPAIRED': {
        fontSize: 'large',
        contrast: 'high',
        animations: 'reduced',
        audioFeedback: 'verbose',
        interactionTiming: 'extended'
      },
      'HEARING_IMPAIRED': {
        fontSize: 'normal',
        contrast: 'normal',
        animations: 'enabled',
        audioFeedback: 'visual-alternative',
        interactionTiming: 'no
(Content truncated due to size limit. Use line ranges to read in chunks)