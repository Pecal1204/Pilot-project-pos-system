import React, { useState, useEffect } from 'react';
import { 
  Box, 
  Grid, 
  Paper, 
  Typography, 
  Button, 
  Divider, 
  List, 
  ListItem, 
  ListItemText, 
  IconButton,
  Chip,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  CircularProgress
} from '@mui/material';
import AddIcon from '@mui/icons-material/Add';
import RemoveIcon from '@mui/icons-material/Remove';
import DeleteIcon from '@mui/icons-material/Delete';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import PaymentIcon from '@mui/icons-material/Payment';
import { OrderItem, OrderStatus, OrderType, PaymentMethod } from '@malaysiadish-pos/common';
import { useAppDispatch, useAppSelector } from '../hooks/reduxHooks';
import { 
  addDraftItem, 
  updateDraftItem, 
  removeDraftItem, 
  clearDraftItems,
  selectDraftItems,
  selectDraftTotal,
  setOrderModalOpen,
  selectIsOrderModalOpen
} from '../features/orders/orderSlice';
import { 
  useGetProductsQuery,
  useCreateOrderMutation
} from '../services/api';
import { selectCurrentUser } from '../features/auth/authSlice';

const OrdersPage: React.FC = () => {
  const dispatch = useAppDispatch();
  const draftItems = useAppSelector(selectDraftItems);
  const draftTotal = useAppSelector(selectDraftTotal);
  const isOrderModalOpen = useAppSelector(selectIsOrderModalOpen);
  const currentUser = useAppSelector(selectCurrentUser);
  
  const [selectedCategory, setSelectedCategory] = useState<string>('ALL');
  const [orderType, setOrderType] = useState<OrderType>(OrderType.DINE_IN);
  const [tableId, setTableId] = useState<string>('');
  const [customerName, setCustomerName] = useState<string>('');
  const [customerPhone, setCustomerPhone] = useState<string>('');
  const [notes, setNotes] = useState<string>('');
  
  const { data: productsData, isLoading: isLoadingProducts } = useGetProductsQuery({ 
    category: selectedCategory === 'ALL' ? undefined : selectedCategory 
  });
  
  const [createOrder, { isLoading: isCreatingOrder }] = useCreateOrderMutation();
  
  const handleAddToOrder = (product: any) => {
    const newItem: OrderItem = {
      id: '', // Will be generated on the server
      productId: product.id,
      name: product.name,
      quantity: 1,
      unitPrice: product.price,
      discount: 0,
      subtotal: product.price,
      modifiers: [],
      status: 'PENDING'
    };
    
    dispatch(addDraftItem(newItem));
  };
  
  const handleQuantityChange = (index: number, change: number) => {
    const item = draftItems[index];
    const newQuantity = Math.max(1, item.quantity + change);
    
    dispatch(updateDraftItem({
      index,
      item: {
        quantity: newQuantity,
        subtotal: newQuantity * item.unitPrice
      }
    }));
  };
  
  const handleRemoveItem = (index: number) => {
    dispatch(removeDraftItem(index));
  };
  
  const handleOpenOrderModal = () => {
    dispatch(setOrderModalOpen(true));
  };
  
  const handleCloseOrderModal = () => {
    dispatch(setOrderModalOpen(false));
  };
  
  const handleCreateOrder = async () => {
    if (draftItems.length === 0) return;
    
    try {
      await createOrder({
        type: orderType,
        tableId: tableId || undefined,
        customerName: customerName || undefined,
        customerPhone: customerPhone || undefined,
        notes: notes || undefined,
        items: draftItems,
        createdBy: currentUser?.id || 'unknown'
      }).unwrap();
      
      // Reset form fields
      setOrderType(OrderType.DINE_IN);
      setTableId('');
      setCustomerName('');
      setCustomerPhone('');
      setNotes('');
      
      // Close modal (clearDraftItems is handled by the orderSlice extraReducer)
      handleCloseOrderModal();
    } catch (error) {
      console.error('Failed to create order:', error);
    }
  };
  
  const categories = [
    { value: 'ALL', label: 'All Items' },
    { value: 'FOOD', label: 'Food' },
    { value: 'BEVERAGE', label: 'Beverages' },
    { value: 'DESSERT', label: 'Desserts' },
    { value: 'COMBO', label: 'Combo Meals' }
  ];
  
  return (
    <Box sx={{ flexGrow: 1 }}>
      <Typography variant="h4" gutterBottom>
        New Order
      </Typography>
      
      <Grid container spacing={3}>
        {/* Left side - Menu items */}
        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 2, mb: 2 }}>
            <Box sx={{ display: 'flex', mb: 2, overflowX: 'auto', pb: 1 }}>
              {categories.map((category) => (
                <Chip
                  key={category.value}
                  label={category.label}
                  onClick={() => setSelectedCategory(category.value)}
                  color={selectedCategory === category.value ? 'primary' : 'default'}
                  sx={{ mr: 1, mb: 1 }}
                />
              ))}
            </Box>
            
            {isLoadingProducts ? (
              <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
                <CircularProgress />
              </Box>
            ) : (
              <Grid container spacing={2}>
                {productsData?.data?.map((product) => (
                  <Grid item xs={6} sm={4} md={3} key={product.id}>
                    <Paper
                      elevation={3}
                      sx={{
                        p: 2,
                        display: 'flex',
                        flexDirection: 'column',
                        height: '100%',
                        cursor: 'pointer',
                        '&:hover': {
                          bgcolor: 'action.hover',
                        },
                      }}
                      onClick={() => handleAddToOrder(product)}
                    >
                      <Box
                        sx={{
                          height: 100,
                          mb: 1,
                          bgcolor: 'grey.200',
                          display: 'flex',
                          justifyContent: 'center',
                          alignItems: 'center',
                        }}
                      >
                        {product.imageUrl ? (
                          <img
                            src={product.imageUrl}
                            alt={product.name}
                            style={{ maxHeight: '100%', maxWidth: '100%' }}
                          />
                        ) : (
                          <RestaurantMenuIcon sx={{ fontSize: 40, color: 'text.secondary' }} />
                        )}
                      </Box>
                      <Typography variant="subtitle1" noWrap>
                        {product.name}
                      </Typography>
                      <Typography variant="body2" color="text.secondary" noWrap>
                        {product.description}
                      </Typography>
                      <Box sx={{ mt: 'auto', pt: 1 }}>
                        <Typography variant="h6" color="primary">
                          RM {product.price.toFixed(2)}
                        </Typography>
                      </Box>
                    </Paper>
                  </Grid>
                ))}
              </Grid>
            )}
          </Paper>
        </Grid>
        
        {/* Right side - Order summary */}
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 2, position: 'sticky', top: 88 }}>
            <Typography variant="h6" gutterBottom>
              Current Order
            </Typography>
            
            {draftItems.length === 0 ? (
              <Box sx={{ py: 4, textAlign: 'center' }}>
                <ShoppingCartIcon sx={{ fontSize: 48, color: 'text.secondary', mb: 2 }} />
                <Typography variant="body1" color="text.secondary">
                  No items added yet
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  Select items from the menu to add them to your order
                </Typography>
              </Box>
            ) : (
              <>
                <List sx={{ maxHeight: 300, overflow: 'auto' }}>
                  {draftItems.map((item, index) => (
                    <ListItem
                      key={index}
                      secondaryAction={
                        <IconButton edge="end" onClick={() => handleRemoveItem(index)}>
                          <DeleteIcon />
                        </IconButton>
                      }
                    >
                      <ListItemText
                        primary={item.name}
                        secondary={`RM ${item.unitPrice.toFixed(2)}`}
                      />
                      <Box sx={{ display: 'flex', alignItems: 'center', ml: 2 }}>
                        <IconButton size="small" onClick={() => handleQuantityChange(index, -1)}>
                          <RemoveIcon fontSize="small" />
                        </IconButton>
                        <Typography sx={{ mx: 1 }}>{item.quantity}</Typography>
                        <IconButton size="small" onClick={() => handleQuantityChange(index, 1)}>
                          <AddIcon fontSize="small" />
                        </IconButton>
                      </Box>
                    </ListItem>
                  ))}
                </List>
                
                <Divider sx={{ my: 2 }} />
                
                <Box sx={{ mb: 2 }}>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                    <Typography variant="body1">Subtotal</Typography>
                    <Typography variant="body1">RM {draftTotal.subtotal.toFixed(2)}</Typography>
                  </Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                    <Typography variant="body2" color="text.secondary">
                      Service Charge (10%)
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      RM {draftTotal.serviceCharge.toFixed(2)}
                    </Typography>
                  </Box>
                  <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
                    <Typography variant="body2" color="text.secondary">
                      Tax (6%)
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      RM {draftTotal.taxAmount.toFixed(2)}
                    </Typography>
                  </Box>
                </Box>
                
                <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
                  <Typography variant="h6">Total</Typography>
                  <Typography variant="h6">RM {draftTotal.total.toFixed(2)}</Typography>
                </Box>
                
                <Button
                  variant="contained"
                  fullWidth
                  size="large"
                  startIcon={<PaymentIcon />}
                  onClick={handleOpenOrderModal}
                >
                  Place Order
                </Button>
                
                <Button
                  variant="outlined"
                  fullWidth
                  size="large"
                  sx={{ mt: 1 }}
                  onClick={() => dispatch(clearDraftItems())}
                >
                  Clear Items
                </Button>
              </>
            )}
          </Paper>
        </Grid>
      </Grid>
      
      {/* Order confirmation modal */}
      <Dialog open={isOrderModalOpen} onClose={handleCloseOrderModal} maxWidth="sm" fullWidth>
        <DialogTitle>Confirm Order</DialogTitle>
        <DialogContent>
          <Box sx={{ mb: 3 }}>
            <FormControl fullWidth margin="normal">
              <InputLabel>Order Type</InputLabel>
              <Select
                value={orderType}
                label="Order Type"
                onChange={(e) => setOrderType(e.target.value as OrderType)}
              >
                <MenuItem value={OrderType.DINE_IN}>Dine In</MenuItem>
                <MenuItem value={OrderType.TAKEAWAY}>Takeaway</MenuItem>
                <MenuItem value={OrderType.DELIVERY}>Delivery</MenuItem>
              </Select>
            </FormControl>
            
            {orderType === OrderType.DINE_IN && (
              <TextField
                fullWidth
                margin="normal"
                label="Table Number"
                value={tableId}
                onChange={(e) => setTableId(e.target.value)}
              />
            )}
            
            <TextField
              fullWidth
              margin="normal"
              label="Customer Name (Optional)"
              value={customerName}
              onChange={(e) => setCustomerName(e.target.value)}
            />
            
            <TextField
              fullWidth
              margin="normal"
              label="Customer Phone (Optional)"
              value={customerPhone}
              onChange={(e) => setCustomerPhone(e.target.value)}
            />
            
            <TextField
              fullWidth
              margin="normal"
              label="Order Notes (Optional)"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              multiline
              rows={2}
            />
          </Box>
          
          <Typography variant="subtitle1" gutterBottom>
            Order Summary
          </Typography>
          
          <List dense>
            {draftItems.map((item, index) => (
              <ListItem key={index}>
                <ListItemText
                  primary={`${item.quantity}x ${item.name}`}
                  secondary={`RM ${(item.quantity * item.unitPrice).toFixed(2)}`}
                />
              </ListItem>
            ))}
          </List>
          
          <Divider sx={{ my: 1 }} />
          
          <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 1 }}>
            <Typography variant="body1">Total</Typography>
            <Typography variant="body1" fontWeight="bold">
              RM {draftTotal.total.toFixed(2)}
            </Typography>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseOrderModal}>Cancel</Button>
          <Button 
            onClick={handleCreateOrder} 
            variant="contained" 
            disabled={isCreatingOrder || draftItems.length === 0}
          >
            {isCreatingOrder ? <CircularProgress size={24} /> : 'Confirm Order'}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default OrdersPage;
