import { createSlice, PayloadAction } from '@reduxjs/toolkit';
import { RootState } from '../../store';
import { api } from '../../services/api';

interface CommunicationTemplate {
  id: string;
  name: string;
  type: 'receipt' | 'order_confirmation' | 'order_ready' | 'promotion' | 'feedback_request' | 'custom';
  channel: 'whatsapp' | 'sms' | 'email' | 'push_notification';
  subject?: string;
  content: string;
  variables: string[];
  isActive: boolean;
  lastModified: string;
}

interface CommunicationHistory {
  id: string;
  templateId: string;
  templateName: string;
  channel: 'whatsapp' | 'sms' | 'email' | 'push_notification';
  recipient: string;
  content: string;
  status: 'pending' | 'sent' | 'delivered' | 'failed';
  sentAt: string;
  deliveredAt?: string;
  errorMessage?: string;
  metadata: Record<string, any>;
}

interface CommunicationSettings {
  whatsappEnabled: boolean;
  whatsappApiKey?: string;
  whatsappBusinessId?: string;
  whatsappPhoneNumber?: string;
  smsEnabled: boolean;
  smsApiKey?: string;
  smsFrom?: string;
  emailEnabled: boolean;
  emailSmtpServer?: string;
  emailUsername?: string;
  emailPassword?: string;
  emailFrom?: string;
  pushNotificationsEnabled: boolean;
  pushNotificationsApiKey?: string;
  defaultChannel: 'whatsapp' | 'sms' | 'email' | 'push_notification';
  requireCustomerConsent: boolean;
  includePrivacyPolicy: boolean;
  privacyPolicyUrl?: string;
  receiptFooterText?: string;
}

interface CustomerCommunicationState {
  templates: CommunicationTemplate[];
  history: CommunicationHistory[];
  settings: CommunicationSettings;
  isLoadingTemplates: boolean;
  isLoadingHistory: boolean;
  isSending: boolean;
  error: string | null;
  selectedTemplateId: string | null;
}

const initialState: CustomerCommunicationState = {
  templates: [
    {
      id: 'receipt-whatsapp',
      name: 'WhatsApp Receipt',
      type: 'receipt',
      channel: 'whatsapp',
      content: `Thank you for dining at MalaysiaDish!

*Receipt #{{receiptNumber}}*
Date: {{date}}
Time: {{time}}

{{orderItems}}

Subtotal: RM {{subtotal}}
Tax (6%): RM {{tax}}
*Total: RM {{total}}*

Payment Method: {{paymentMethod}}

This is an official receipt from MalaysiaDish.
{{eInvoiceInfo}}

Rate your experience: {{feedbackLink}}`,
      variables: ['receiptNumber', 'date', 'time', 'orderItems', 'subtotal', 'tax', 'total', 'paymentMethod', 'eInvoiceInfo', 'feedbackLink'],
      isActive: true,
      lastModified: new Date().toISOString()
    },
    {
      id: 'order-confirmation-whatsapp',
      name: 'WhatsApp Order Confirmation',
      type: 'order_confirmation',
      channel: 'whatsapp',
      content: `Thank you for your order at MalaysiaDish!

*Order #{{orderNumber}}*
Date: {{date}}
Time: {{time}}

{{orderItems}}

Total: RM {{total}}

Your order is being prepared and will be ready in approximately {{estimatedTime}} minutes.

Track your order: {{trackingLink}}`,
      variables: ['orderNumber', 'date', 'time', 'orderItems', 'total', 'estimatedTime', 'trackingLink'],
      isActive: true,
      lastModified: new Date().toISOString()
    },
    {
      id: 'order-ready-whatsapp',
      name: 'WhatsApp Order Ready',
      type: 'order_ready',
      channel: 'whatsapp',
      content: `Good news! Your order is ready for pickup.

*Order #{{orderNumber}}*

Please collect your order from counter {{counterNumber}}.

Thank you for choosing MalaysiaDish!`,
      variables: ['orderNumber', 'counterNumber'],
      isActive: true,
      lastModified: new Date().toISOString()
    },
    {
      id: 'feedback-request-whatsapp',
      name: 'WhatsApp Feedback Request',
      type: 'feedback_request',
      channel: 'whatsapp',
      content: `Hello {{customerName}},

We hope you enjoyed your meal at MalaysiaDish!

We'd love to hear your feedback. Please take a moment to rate your experience:

{{feedbackLink}}

Thank you for helping us improve!`,
      variables: ['customerName', 'feedbackLink'],
      isActive: true,
      lastModified: new Date().toISOString()
    }
  ],
  history: [],
  settings: {
    whatsappEnabled: true,
    whatsappApiKey: 'wa_api_key_placeholder',
    whatsappBusinessId: 'wa_business_id_placeholder',
    whatsappPhoneNumber: '+60123456789',
    smsEnabled: true,
    smsApiKey: 'sms_api_key_placeholder',
    smsFrom: 'MalaysiaDish',
    emailEnabled: true,
    emailSmtpServer: 'smtp.malaysiadish.com',
    emailUsername: 'notifications@malaysiadish.com',
    emailPassword: 'email_password_placeholder',
    emailFrom: 'MalaysiaDish <notifications@malaysiadish.com>',
    pushNotificationsEnabled: false,
    defaultChannel: 'whatsapp',
    requireCustomerConsent: true,
    includePrivacyPolicy: true,
    privacyPolicyUrl: 'https://www.malaysiadish.com/privacy-policy',
    receiptFooterText: 'Thank you for dining with us!'
  },
  isLoadingTemplates: false,
  isLoadingHistory: false,
  isSending: false,
  error: null,
  selectedTemplateId: null
};

export const customerCommunicationSlice = createSlice({
  name: 'customerCommunication',
  initialState,
  reducers: {
    setTemplates: (state, action: PayloadAction<CommunicationTemplate[]>) => {
      state.templates = action.payload;
    },
    addTemplate: (state, action: PayloadAction<Omit<CommunicationTemplate, 'id' | 'lastModified'>>) => {
      const newTemplate = {
        ...action.payload,
        id: `template-${Date.now()}`,
        lastModified: new Date().toISOString()
      };
      state.templates.push(newTemplate);
    },
    updateTemplate: (state, action: PayloadAction<Partial<CommunicationTemplate> & { id: string }>) => {
      const index = state.templates.findIndex(t => t.id === action.payload.id);
      if (index !== -1) {
        state.templates[index] = {
          ...state.templates[index],
          ...action.payload,
          lastModified: new Date().toISOString()
        };
      }
    },
    deleteTemplate: (state, action: PayloadAction<string>) => {
      state.templates = state.templates.filter(t => t.id !== action.payload);
      if (state.selectedTemplateId === action.payload) {
        state.selectedTemplateId = null;
      }
    },
    setTemplateActive: (state, action: PayloadAction<{ id: string; isActive: boolean }>) => {
      const template = state.templates.find(t => t.id === action.payload.id);
      if (template) {
        template.isActive = action.payload.isActive;
        template.lastModified = new Date().toISOString();
      }
    },
    setHistory: (state, action: PayloadAction<CommunicationHistory[]>) => {
      state.history = action.payload;
    },
    addHistoryItem: (state, action: PayloadAction<CommunicationHistory>) => {
      state.history.unshift(action.payload);
    },
    updateHistoryItem: (state, action: PayloadAction<Partial<CommunicationHistory> & { id: string }>) => {
      const index = state.history.findIndex(h => h.id === action.payload.id);
      if (index !== -1) {
        state.history[index] = {
          ...state.history[index],
          ...action.payload
        };
      }
    },
    clearHistory: (state) => {
      state.history = [];
    },
    updateSettings: (state, action: PayloadAction<Partial<CommunicationSettings>>) => {
      state.settings = {
        ...state.settings,
        ...action.payload
      };
    },
    setSelectedTemplateId: (state, action: PayloadAction<string | null>) => {
      state.selectedTemplateId = action.payload;
    },
    setIsLoadingTemplates: (state, action: PayloadAction<boolean>) => {
      state.isLoadingTemplates = action.payload;
    },
    setIsLoadingHistory: (state, action: PayloadAction<boolean>) => {
      state.isLoadingHistory = action.payload;
    },
    setIsSending: (state, action: PayloadAction<boolean>) => {
      state.isSending = action.payload;
    },
    setError: (state, action: PayloadAction<string | null>) => {
      state.error = action.payload;
    }
  },
  extraReducers: (builder) => {
    builder
      .addMatcher(
        api.endpoints.sendCommunication?.matchPending,
        (state) => {
          state.isSending = true;
          state.error = null;
        }
      )
      .addMatcher(
        api.endpoints.sendCommunication?.matchFulfilled,
        (state, { payload }) => {
          state.isSending = false;
          state.history.unshift(payload.data);
        }
      )
      .addMatcher(
        api.endpoints.sendCommunication?.matchRejected,
        (state, { error }) => {
          state.isSending = false;
          state.error = error.message || 'Failed to send communication';
        }
      )
      .addMatcher(
        api.endpoints.getCommunicationTemplates?.matchPending,
        (state) => {
          state.isLoadingTemplates = true;
        }
      )
      .addMatcher(
        api.endpoints.getCommunicationTemplates?.matchFulfilled,
        (state, { payload }) => {
          state.isLoadingTemplates = false;
          state.templates = payload.data;
        }
      )
      .addMatcher(
        api.endpoints.getCommunicationTemplates?.matchRejected,
        (state, { error }) => {
          state.isLoadingTemplates = false;
          state.error = error.message || 'Failed to load templates';
        }
      )
      .addMatcher(
        api.endpoints.getCommunicationHistory?.matchPending,
        (state) => {
          state.isLoadingHistory = true;
        }
      )
      .addMatcher(
        api.endpoints.getCommunicationHistory?.matchFulfilled,
        (state, { payload }) => {
          state.isLoadingHistory = false;
          state.history = payload.data;
        }
      )
      .addMatcher(
        api.endpoints.getCommunicationHistory?.matchRejected,
        (state, { error }) => {
          state.isLoadingHistory = false;
          state.error = error.message || 'Failed to load communication history';
        }
      );
  }
});

export const {
  setTemplates,
  addTemplate,
  updateTemplate,
  deleteTemplate,
  setTemplateActive,
  setHistory,
  addHistoryItem,
  updateHistoryItem,
  clearHistory,
  updateSettings,
  setSelectedTemplateId,
  setIsLoadingTemplates,
  setIsLoadingHistory,
  setIsSending,
  setError
} = customerCommunicationSlice.actions;

// Selectors
export const selectTemplates = (state: RootState) => state.customerCommunication.templates;
export const selectActiveTemplates = (state: RootState) => 
  state.customerCommunication.templates.filter(t => t.isActive);
export const selectTemplatesByType = (type: string) => (state: RootState) => 
  state.customerCommunication.templates.filter(t => t.type === type && t.isActive);
export const selectTemplatesByChannel = (channel: string) => (state: RootState) => 
  state.customerCommunication.templates.filter(t => t.channel === channel && t.isActive);
export const selectHistory = (state: RootState) => state.customerCommunication.history;
export const selectSettings = (state: RootState) => state.customerCommunication.settings;
export const selectIsLoadingTemplates = (state: RootState) => state.customerCommunication.isLoadingTemplates;
export const selectIsLoadingHistory = (state: RootState) => state.customerCommunication.isLoadingHistory;
export const selectIsSending = (state: RootState) => state.customerCommunication.isSending;
export const selectError = (state: RootState) => state.customerCommunication.error;
export const selectSelectedTemplateId = (state: RootState) => state.customerCommunication.selectedTemplateId;
export const selectSelectedTemplate = (state: RootState) => {
  const id = state.customerCommunication.selectedTemplateId;
  return id ? state.customerCommunication.templates.find(t => t.id === id) || null : null;
};

export default customerCommunicationSlice.reducer;
