/**
 * E-Invoicing Module for MalaysiaDish POS
 * Implements IRBM-compliant e-invoicing with UBL 2.1 standard
 * Required for Malaysia's mandatory e-invoicing (July 1, 2025)
 */

// Types for UBL 2.1 compliant e-invoice
export interface Address {
  streetName: string;
  buildingNumber?: string;
  cityName: string;
  postalZone: string;
  countrySubentity: string; // State
  country: string;
}

export interface Contact {
  name: string;
  telephone?: string;
  electronicMail?: string;
}

export interface TaxSubtotal {
  taxableAmount: number;
  taxAmount: number;
  taxCategory: {
    id: string; // Tax category code
    percent: number;
    taxScheme: {
      id: string; // Tax scheme ID (e.g., "SST")
      name: string; // Tax scheme name
    };
  };
}

export interface InvoiceLine {
  id: string;
  invoicedQuantity: {
    value: number;
    unitCode: string; // UOM code
  };
  lineExtensionAmount: number; // Amount without tax
  item: {
    name: string;
    description?: string;
    sellersItemIdentification?: {
      id: string;
    };
    standardItemIdentification?: {
      id: string;
    };
  };
  price: {
    priceAmount: number;
    baseQuantity?: {
      value: number;
      unitCode: string;
    };
  };
  taxTotal?: {
    taxAmount: number;
    taxSubtotal: TaxSubtotal[];
  };
}

export interface PaymentMeans {
  paymentMeansCode: string; // Payment method code
  paymentID?: string; // Payment reference
  paymentChannelCode?: string; // Payment channel
}

export interface Signature {
  signatureMethod: string;
  signatureValue: string;
  certificate?: string;
}

export interface EInvoice {
  // Invoice Header
  invoiceNumber: string;
  issueDate: string;
  dueDate: string;
  invoiceTypeCode: string;
  documentCurrencyCode: string;
  
  // Supplier Information
  accountingSupplierParty: {
    registrationName: string;
    companyID: string;
    taxRegistrationID: string;
    address: Address;
    contact: Contact;
  };
  
  // Customer Information
  accountingCustomerParty: {
    registrationName: string;
    companyID?: string;
    taxRegistrationID?: string;
    address?: Address;
    contact?: Contact;
  };
  
  // Tax Information
  taxTotal: {
    taxAmount: number;
    taxSubtotals: TaxSubtotal[];
  };
  
  // Line Items
  invoiceLines: InvoiceLine[];
  
  // Payment Information
  paymentMeans: PaymentMeans;
  
  // Totals
  legalMonetaryTotal: {
    lineExtensionAmount: number;
    taxExclusiveAmount: number;
    taxInclusiveAmount: number;
    payableAmount: number;
  };
  
  // Digital Signature
  signature?: Signature;
}

// Business information for the POS system
const businessInfo = {
  registrationName: "MalaysiaDish Restaurant Sdn Bhd",
  companyID: "MY12345678",
  taxRegistrationID: "SST-123456789",
  address: {
    streetName: "Jalan Sultan Ismail",
    buildingNumber: "123",
    cityName: "Kuala Lumpur",
    postalZone: "50250",
    countrySubentity: "Wilayah Persekutuan",
    country: "MY"
  },
  contact: {
    name: "MalaysiaDish Customer Service",
    telephone: "+60312345678",
    electronicMail: "info@malaysiadish.com"
  }
};

/**
 * Generates a UBL 2.1 compliant e-invoice from order data
 * @param order Order data from POS system
 * @param customer Customer information
 * @param paymentMethod Payment method used
 * @returns Complete e-invoice object
 */
export function generateEInvoice(
  order: any,
  customer: { name: string; phone?: string; email?: string; address?: Address },
  paymentMethod: string
): EInvoice {
  // Calculate tax and totals
  const taxRate = 0.06; // 6% SST
  const subtotal = order.items.reduce((sum: number, item: any) => sum + (item.price * item.quantity), 0);
  const taxAmount = subtotal * taxRate;
  const total = subtotal + taxAmount;
  
  // Create invoice lines
  const invoiceLines = order.items.map((item: any, index: number) => {
    const lineSubtotal = item.price * item.quantity;
    const lineTax = lineSubtotal * taxRate;
    
    return {
      id: (index + 1).toString(),
      invoicedQuantity: {
        value: item.quantity,
        unitCode: "EA" // Each
      },
      lineExtensionAmount: lineSubtotal,
      item: {
        name: item.name,
        description: item.description,
        sellersItemIdentification: {
          id: item.id
        }
      },
      price: {
        priceAmount: item.price
      },
      taxTotal: {
        taxAmount: lineTax,
        taxSubtotal: [{
          taxableAmount: lineSubtotal,
          taxAmount: lineTax,
          taxCategory: {
            id: "S",
            percent: 6,
            taxScheme: {
              id: "SST",
              name: "Sales and Service Tax"
            }
          }
        }]
      }
    };
  });
  
  // Map payment method to UBL code
  const paymentMeansCode = mapPaymentMethodToUBL(paymentMethod);
  
  // Create customer information
  const customerInfo = {
    registrationName: customer.name,
    contact: {
      name: customer.name,
      telephone: customer.phone,
      electronicMail: customer.email
    },
    address: customer.address
  };
  
  // Generate invoice number
  const invoiceNumber = `INV-${order.id.replace('order', '')}-${Date.now().toString().slice(-6)}`;
  
  // Create the complete e-invoice
  const invoice: EInvoice = {
    invoiceNumber,
    issueDate: new Date().toISOString().split('T')[0],
    dueDate: new Date().toISOString().split('T')[0], // Due immediately for POS
    invoiceTypeCode: "380", // Commercial invoice
    documentCurrencyCode: "MYR",
    
    accountingSupplierParty: {
      registrationName: businessInfo.registrationName,
      companyID: businessInfo.companyID,
      taxRegistrationID: businessInfo.taxRegistrationID,
      address: businessInfo.address,
      contact: businessInfo.contact
    },
    
    accountingCustomerParty: {
      registrationName: customerInfo.registrationName,
      contact: customerInfo.contact,
      address: customerInfo.address
    },
    
    taxTotal: {
      taxAmount,
      taxSubtotals: [{
        taxableAmount: subtotal,
        taxAmount,
        taxCategory: {
          id: "S",
          percent: 6,
          taxScheme: {
            id: "SST",
            name: "Sales and Service Tax"
          }
        }
      }]
    },
    
    invoiceLines,
    
    paymentMeans: {
      paymentMeansCode,
      paymentID: order.id
    },
    
    legalMonetaryTotal: {
      lineExtensionAmount: subtotal,
      taxExclusiveAmount: subtotal,
      taxInclusiveAmount: total,
      payableAmount: total
    }
  };
  
  return invoice;
}

/**
 * Converts e-invoice to XML format following UBL 2.1 standard
 * @param invoice E-invoice object
 * @returns XML string
 */
export function convertToXML(invoice: EInvoice): string {
  // In a production implementation, this would use a proper XML library
  // This is a simplified version for demonstration
  
  let xml = `<?xml version="1.0" encoding="UTF-8"?>
<Invoice xmlns="urn:oasis:names:specification:ubl:schema:xsd:Invoice-2"
         xmlns:cac="urn:oasis:names:specification:ubl:schema:xsd:CommonAggregateComponents-2"
         xmlns:cbc="urn:oasis:names:specification:ubl:schema:xsd:CommonBasicComponents-2">
  <cbc:UBLVersionID>2.1</cbc:UBLVersionID>
  <cbc:ID>${invoice.invoiceNumber}</cbc:ID>
  <cbc:IssueDate>${invoice.issueDate}</cbc:IssueDate>
  <cbc:DueDate>${invoice.dueDate}</cbc:DueDate>
  <cbc:InvoiceTypeCode>${invoice.invoiceTypeCode}</cbc:InvoiceTypeCode>
  <cbc:DocumentCurrencyCode>${invoice.documentCurrencyCode}</cbc:DocumentCurrencyCode>
  
  <cac:AccountingSupplierParty>
    <cac:Party>
      <cac:PartyName>
        <cbc:Name>${invoice.accountingSupplierParty.registrationName}</cbc:Name>
      </cac:PartyName>
      <cac:PartyIdentification>
        <cbc:ID>${invoice.accountingSupplierParty.companyID}</cbc:ID>
      </cac:PartyIdentification>
      <cac:PartyTaxScheme>
        <cbc:CompanyID>${invoice.accountingSupplierParty.taxRegistrationID}</cbc:CompanyID>
        <cac:TaxScheme>
          <cbc:ID>SST</cbc:ID>
        </cac:TaxScheme>
      </cac:PartyTaxScheme>
      <cac:PostalAddress>
        <cbc:StreetName>${invoice.accountingSupplierParty.address.streetName}</cbc:StreetName>
        ${invoice.accountingSupplierParty.address.buildingNumber ? `<cbc:BuildingNumber>${invoice.accountingSupplierParty.address.buildingNumber}</cbc:BuildingNumber>` : ''}
        <cbc:CityName>${invoice.accountingSupplierParty.address.cityName}</cbc:CityName>
        <cbc:PostalZone>${invoice.accountingSupplierParty.address.postalZone}</cbc:PostalZone>
        <cbc:CountrySubentity>${invoice.accountingSupplierParty.address.countrySubentity}</cbc:CountrySubentity>
        <cac:Country>
          <cbc:IdentificationCode>${invoice.accountingSupplierParty.address.country}</cbc:IdentificationCode>
        </cac:Country>
      </cac:PostalAddress>
      <cac:Contact>
        <cbc:Name>${invoice.accountingSupplierParty.contact.name}</cbc:Name>
        ${invoice.accountingSupplierParty.contact.telephone ? `<cbc:Telephone>${invoice.accountingSupplierParty.contact.telephone}</cbc:Telephone>` : ''}
        ${invoice.accountingSupplierParty.contact.electronicMail ? `<cbc:ElectronicMail>${invoice.accountingSupplierParty.contact.electronicMail}</cbc:ElectronicMail>` : ''}
      </cac:Contact>
    </cac:Party>
  </cac:AccountingSupplierParty>
  
  <cac:AccountingCustomerParty>
    <cac:Party>
      <cac:PartyName>
        <cbc:Name>${invoice.accountingCustomerParty.registrationName}</cbc:Name>
      </cac:PartyName>
      ${invoice.accountingCustomerParty.contact ? `
      <cac:Contact>
        <cbc:Name>${invoice.accountingCustomerParty.contact.name}</cbc:Name>
        ${invoice.accountingCustomerParty.contact.telephone ? `<cbc:Telephone>${invoice.accountingCustomerParty.contact.telephone}</cbc:Telephone>` : ''}
        ${invoice.accountingCustomerParty.contact.electronicMail ? `<cbc:ElectronicMail>${invoice.accountingCustomerParty.contact.electronicMail}</cbc:ElectronicMail>` : ''}
      </cac:Contact>` : ''}
    </cac:Party>
  </cac:AccountingCustomerParty>
  
  <cac:PaymentMeans>
    <cbc:PaymentMeansCode>${invoice.paymentMeans.paymentMeansCode}</cbc:PaymentMeansCode>
    ${invoice.paymentMeans.paymentID ? `<cbc:PaymentID>${invoice.paymentMeans.paymentID}</cbc:PaymentID>` : ''}
  </cac:PaymentMeans>
  
  <cac:TaxTotal>
    <cbc:TaxAmount currencyID="${invoice.documentCurrencyCode}">${invoice.taxTotal.taxAmount.toFixed(2)}</cbc:TaxAmount>
    ${invoice.taxTotal.taxSubtotals.map(subtotal => `
    <cac:TaxSubtotal>
      <cbc:TaxableAmount currencyID="${invoice.documentCurrencyCode}">${subtotal.taxableAmount.toFixed(2)}</cbc:TaxableAmount>
      <cbc:TaxAmount currencyID="${invoice.documentCurrencyCode}">${subtotal.taxAmount.toFixed(2)}</cbc:TaxAmount>
      <cac:TaxCategory>
        <cbc:ID>${subtotal.taxCategory.id}</cbc:ID>
        <cbc:Percent>${subtotal.taxCategory.percent}</cbc:Percent>
        <cac:TaxScheme>
          <cbc:ID>${subtotal.taxCategory.taxScheme.id}</cbc:ID>
          <cbc:Name>${subtotal.taxCategory.taxScheme.name}</cbc:Name>
        </cac:TaxScheme>
      </cac:TaxCategory>
    </cac:TaxSubtotal>`).join('')}
  </cac:TaxTotal>
  
  <cac:LegalMonetaryTotal>
    <cbc:LineExtensionAmount currencyID="${invoice.documentCurrencyCode}">${invoice.legalMonetaryTotal.lineExtensionAmount.toFixed(2)}</cbc:LineExtensionAmount>
    <cbc:TaxExclusiveAmount currencyID="${invoice.documentCurrencyCode}">${invoice.legalMonetaryTotal.taxExclusiveAmount.toFixed(2)}</cbc:TaxExclusiveAmount>
    <cbc:TaxInclusiveAmount currencyID="${invoice.documentCurrencyCode}">${invoice.legalMonetaryTotal.taxInclusiveAmount.toFixed(2)}</cbc:TaxInclusiveAmount>
    <cbc:PayableAmount currencyID="${invoice.documentCurrencyCode}">${invoice.legalMonetaryTotal.payableAmount.toFixed(2)}</cbc:PayableAmount>
  </cac:LegalMonetaryTotal>
  
  ${invoice.invoiceLines.map(line => `
  <cac:InvoiceLine>
    <cbc:ID>${line.id}</cbc:ID>
    <cbc:InvoicedQuantity unitCode="${line.invoicedQuantity.unitCode}">${line.invoicedQuantity.value}</cbc:InvoicedQuantity>
    <cbc:LineExtensionAmount currencyID="${invoice.documentCurrencyCode}">${line.lineExtensionAmount.toFixed(2)}</cbc:LineExtensionAmount>
    
    ${line.taxTotal ? `
    <cac:TaxTotal>
      <cbc:TaxAmount currencyID="${invoice.documentCurrencyCode}">${line.taxTotal.taxAmount.toFixed(2)}</cbc:TaxAmount>
    </cac:TaxTotal>` : ''}
    
    <cac:Item>
      <cbc:Name>${line.item.name}</cbc:Name>
      ${line.item.description ? `<cbc:Description>${line.item.description}</cbc:Description>` : ''}
      ${line.item.sellersItemIdentification ? `
      <cac:SellersItemIdentification>
        <cbc:ID>${line.item.sellersItemIdentification.id}</cbc:ID>
      </cac:SellersItemIdentification>` : ''}
    </cac:Item>
    
    <cac:Price>
      <cbc:PriceAmount currencyID="${invoice.documentCurrencyCode}">${line.price.priceAmount.toFixed(2)}</cbc:PriceAmount>
    </cac:Price>
  </cac:InvoiceLine>`).join('')}
</Invoice>`;

  return xml;
}

/**
 * Converts e-invoice to JSON format following UBL 2.1 standard
 * @param invoice E-invoice object
 * @returns JSON string
 */
export function convertToJSON(invoice: EInvoice): string {
  // In a production implementation, this would include proper UBL JSON mapping
  // This is a simplified version for demonstration
  return JSON.stringify(invoice, null, 2);
}

/**
 * Maps POS payment methods to UBL payment means codes
 * @param method Payment method from POS
 * @returns UBL payment means code
 */
function mapPaymentMethodToUBL(method: string): string {
  switch (method.toLowerCase()) {
    case 'cash':
      return '10'; // Cash
    case 'card':
      return '48'; // Bank card
    case 'credit':
      return '48'; // Bank card
    case 'ewallet':
    case 'e-wallet':
      return '97'; // Clearing between partners
    case 'qr':
    case 'qrpay':
    case 'qr pay':
      return '97'; // Clearing between partners
    default:
      return '30'; // Credit transfer
  }
}

/**
 * Validates an e-invoice against UBL 2.1 schema and business rules
 * @param invoice E-invoice to validate
 * @returns Validation result with any errors
 */
export function validateEInvoice(invoice: EInvoice): { valid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Check required fields
  if (!invoice.invoiceNumber) errors.push("Invoice number is required");
  if (!invoice.issueDate) errors.push("Issue date is required");
  if (!invoice.documentCurrencyCode) errors.push("Currency code is required");
  
  // Validate supplier information
  if (!invoice.accountingSupplierParty.registrationName) errors.push("Supplier name is required");
  if (!invoice.accountingSupplierParty.companyID) errors.push("Supplier company ID is required");
  if (!invoice.accountingSupplierParty.taxRegistrationID) errors.push("Supplier tax ID is required");
  
  // Validate customer information
  if (!invoice.accountingCustomerParty.registrationName) errors.push("Customer name is required");
  
  // Validate line items
  if (!invoice.invoiceLines || invoice.invoiceLines.length === 0) {
    errors.push("At least one invoice line is required");
  } else {
    // Check each line item
    invoice.invoiceLines.forEach((line, index) => {
      if (!line.item.name) errors.push(`Line ${index + 1}: Item name is required`);
      if (line.invoicedQuantity.value <= 0) errors.push(`Line ${index + 1}: Quantity must be positive`);
      if (line.price.priceAmount < 0) errors.push(`Line ${index + 1}: Price cannot be negative`);
    });
  }
  
  // Validate totals
  const calculatedLineTotal = invoice.invoiceLines.reduce((sum, line) => sum + line.lineExtensionAmount, 0);
  if (Math.abs(calculatedLineTotal - invoice.legalMonetaryTotal.lineExtensionAmount) > 0.01) {
    errors.push("Line extension amount does not match sum of invoice lines");
  }
  
  const calculatedTaxTotal = invoice.taxTotal.taxSubtotals.reduce((sum, subtotal) => sum + subtotal.taxAmount, 0);
  if (Math.abs
(Content truncated due to size limit. Use line ranges to read in chunks)