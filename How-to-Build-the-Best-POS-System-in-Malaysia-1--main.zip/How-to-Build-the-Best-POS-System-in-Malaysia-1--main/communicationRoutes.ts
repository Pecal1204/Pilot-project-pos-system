import express from 'express';
import { v4 as uuidv4 } from 'uuid';

const router = express.Router();

// Mock communication service
const communicationService = {
  // Send WhatsApp message
  sendWhatsAppMessage: async (phoneNumber, templateName, variables) => {
    // In a real implementation, this would use the WhatsApp Business API
    // For demo purposes, we'll simulate a successful message send
    const messageId = `wa-${uuidv4()}`;
    const timestamp = new Date().toISOString();
    
    return {
      id: messageId,
      recipient: phoneNumber,
      status: 'sent',
      sentAt: timestamp,
      deliveredAt: new Date(Date.now() + 2000).toISOString(),
      metadata: {
        templateName,
        variables
      }
    };
  },
  
  // Send SMS
  sendSMS: async (phoneNumber, message) => {
    // In a real implementation, this would use an SMS gateway
    // For demo purposes, we'll simulate a successful message send
    const messageId = `sms-${uuidv4()}`;
    const timestamp = new Date().toISOString();
    
    return {
      id: messageId,
      recipient: phoneNumber,
      status: 'sent',
      sentAt: timestamp,
      deliveredAt: new Date(Date.now() + 3000).toISOString(),
      metadata: {
        messageLength: message.length
      }
    };
  },
  
  // Send email
  sendEmail: async (email, subject, body) => {
    // In a real implementation, this would use an email service
    // For demo purposes, we'll simulate a successful email send
    const messageId = `email-${uuidv4()}`;
    const timestamp = new Date().toISOString();
    
    return {
      id: messageId,
      recipient: email,
      status: 'sent',
      sentAt: timestamp,
      deliveredAt: null, // Email delivery status is often not reliably tracked
      metadata: {
        subject,
        bodyLength: body.length
      }
    };
  },
  
  // Get communication templates
  getTemplates: () => {
    return [
      {
        id: 'receipt-whatsapp',
        name: 'WhatsApp Receipt',
        type: 'receipt',
        channel: 'whatsapp',
        content: `Thank you for dining at MalaysiaDish!\n\n*Receipt #{{receiptNumber}}*\nDate: {{date}}\nTime: {{time}}\n\n{{orderItems}}\n\nSubtotal: RM {{subtotal}}\nTax (6%): RM {{tax}}\n*Total: RM {{total}}*\n\nPayment Method: {{paymentMethod}}\n\nThis is an official receipt from MalaysiaDish.\n{{eInvoiceInfo}}\n\nRate your experience: {{feedbackLink}}`,
        variables: ['receiptNumber', 'date', 'time', 'orderItems', 'subtotal', 'tax', 'total', 'paymentMethod', 'eInvoiceInfo', 'feedbackLink'],
        isActive: true,
        lastModified: new Date().toISOString()
      },
      {
        id: 'order-confirmation-whatsapp',
        name: 'WhatsApp Order Confirmation',
        type: 'order_confirmation',
        channel: 'whatsapp',
        content: `Thank you for your order at MalaysiaDish!\n\n*Order #{{orderNumber}}*\nDate: {{date}}\nTime: {{time}}\n\n{{orderItems}}\n\nTotal: RM {{total}}\n\nYour order is being prepared and will be ready in approximately {{estimatedTime}} minutes.\n\nTrack your order: {{trackingLink}}`,
        variables: ['orderNumber', 'date', 'time', 'orderItems', 'total', 'estimatedTime', 'trackingLink'],
        isActive: true,
        lastModified: new Date().toISOString()
      },
      {
        id: 'order-ready-whatsapp',
        name: 'WhatsApp Order Ready',
        type: 'order_ready',
        channel: 'whatsapp',
        content: `Good news! Your order is ready for pickup.\n\n*Order #{{orderNumber}}*\n\nPlease collect your order from counter {{counterNumber}}.\n\nThank you for choosing MalaysiaDish!`,
        variables: ['orderNumber', 'counterNumber'],
        isActive: true,
        lastModified: new Date().toISOString()
      },
      {
        id: 'feedback-request-whatsapp',
        name: 'WhatsApp Feedback Request',
        type: 'feedback_request',
        channel: 'whatsapp',
        content: `Hello {{customerName}},\n\nWe hope you enjoyed your meal at MalaysiaDish!\n\nWe'd love to hear your feedback. Please take a moment to rate your experience:\n\n{{feedbackLink}}\n\nThank you for helping us improve!`,
        variables: ['customerName', 'feedbackLink'],
        isActive: true,
        lastModified: new Date().toISOString()
      }
    ];
  },
  
  // Get communication history
  getHistory: () => {
    return [
      {
        id: 'hist-001',
        templateId: 'receipt-whatsapp',
        templateName: 'WhatsApp Receipt',
        channel: 'whatsapp',
        recipient: '+60123456789',
        content: 'Thank you for dining at MalaysiaDish!...',
        status: 'delivered',
        sentAt: '2025-05-22T15:30:00Z',
        deliveredAt: '2025-05-22T15:30:05Z',
        metadata: {
          orderId: 'order-001',
          total: 45.50
        }
      },
      {
        id: 'hist-002',
        templateId: 'order-confirmation-whatsapp',
        templateName: 'WhatsApp Order Confirmation',
        channel: 'whatsapp',
        recipient: '+60123456790',
        content: 'Thank you for your order at MalaysiaDish!...',
        status: 'delivered',
        sentAt: '2025-05-22T14:15:00Z',
        deliveredAt: '2025-05-22T14:15:03Z',
        metadata: {
          orderId: 'order-002',
          total: 32.80
        }
      },
      {
        id: 'hist-003',
        templateId: 'feedback-request-whatsapp',
        templateName: 'WhatsApp Feedback Request',
        channel: 'whatsapp',
        recipient: '+60123456791',
        content: 'Hello John, We hope you enjoyed your meal at MalaysiaDish!...',
        status: 'sent',
        sentAt: '2025-05-22T16:45:00Z',
        metadata: {
          customerId: 'cust-001',
          orderIds: ['order-003']
        }
      }
    ];
  }
};

// Send communication
router.post('/send', async (req, res, next) => {
  try {
    const { 
      channel, 
      templateId, 
      recipient, 
      variables,
      orderId,
      customerId
    } = req.body;
    
    if (!channel || !templateId || !recipient) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'INVALID_REQUEST',
          message: 'Channel, template ID, and recipient are required'
        }
      });
    }
    
    // Get template
    const templates = communicationService.getTemplates();
    const template = templates.find(t => t.id === templateId);
    
    if (!template) {
      return res.status(404).json({
        success: false,
        error: {
          code: 'TEMPLATE_NOT_FOUND',
          message: `Template with ID ${templateId} not found`
        }
      });
    }
    
    if (!template.isActive) {
      return res.status(400).json({
        success: false,
        error: {
          code: 'TEMPLATE_INACTIVE',
          message: `Template with ID ${templateId} is inactive`
        }
      });
    }
    
    // Process template with variables
    let content = template.content;
    
    if (variables) {
      Object.entries(variables).forEach(([key, value]) => {
        content = content.replace(new RegExp(`{{${key}}}`, 'g'), value);
      });
    }
    
    // Send message based on channel
    let result;
    
    switch (channel) {
      case 'whatsapp':
        result = await communicationService.sendWhatsAppMessage(recipient, template.name, variables);
        break;
      case 'sms':
        result = await communicationService.sendSMS(recipient, content);
        break;
      case 'email':
        result = await communicationService.sendEmail(recipient, variables.subject || template.name, content);
        break;
      default:
        return res.status(400).json({
          success: false,
          error: {
            code: 'INVALID_CHANNEL',
            message: `Channel ${channel} is not supported`
          }
        });
    }
    
    // Create history record
    const historyRecord = {
      id: `hist-${uuidv4()}`,
      templateId,
      templateName: template.name,
      channel,
      recipient,
      content,
      status: result.status,
      sentAt: result.sentAt,
      deliveredAt: result.deliveredAt,
      metadata: {
        ...result.metadata,
        orderId,
        customerId
      }
    };
    
    res.json({
      success: true,
      data: historyRecord
    });
  } catch (error) {
    next(error);
  }
});

// Get communication templates
router.get('/templates', (req, res) => {
  const templates = communicationService.getTemplates();
  
  res.json({
    success: true,
    data: templates
  });
});

// Get communication history
router.get('/history', (req, res) => {
  const history = communicationService.getHistory();
  
  // Filter by query parameters if provided
  const { channel, recipient, status, orderId, customerId } = req.query;
  
  let filteredHistory = [...history];
  
  if (channel) {
    filteredHistory = filteredHistory.filter(h => h.channel === channel);
  }
  
  if (recipient) {
    filteredHistory = filteredHistory.filter(h => h.recipient.includes(recipient));
  }
  
  if (status) {
    filteredHistory = filteredHistory.filter(h => h.status === status);
  }
  
  if (orderId) {
    filteredHistory = filteredHistory.filter(h => h.metadata.orderId === orderId);
  }
  
  if (customerId) {
    filteredHistory = filteredHistory.filter(h => h.metadata.customerId === customerId);
  }
  
  res.json({
    success: true,
    data: filteredHistory
  });
});

// Get communication settings
router.get('/settings', (req, res) => {
  res.json({
    success: true,
    data: {
      whatsappEnabled: true,
      whatsappApiKey: '********', // Masked for security
      whatsappBusinessId: 'wa_business_id_placeholder',
      whatsappPhoneNumber: '+60123456789',
      smsEnabled: true,
      smsApiKey: '********', // Masked for security
      smsFrom: 'MalaysiaDish',
      emailEnabled: true,
      emailSmtpServer: 'smtp.malaysiadish.com',
      emailUsername: 'notifications@malaysiadish.com',
      emailPassword: '********', // Masked for security
      emailFrom: 'MalaysiaDish <notifications@malaysiadish.com>',
      pushNotificationsEnabled: false,
      defaultChannel: 'whatsapp',
      requireCustomerConsent: true,
      includePrivacyPolicy: true,
      privacyPolicyUrl: 'https://www.malaysiadish.com/privacy-policy',
      receiptFooterText: 'Thank you for dining with us!'
    }
  });
});

// Update communication settings
router.patch('/settings', (req, res) => {
  // In a real implementation, this would update the settings in the database
  // For demo purposes, we'll just return success
  
  res.json({
    success: true,
    data: {
      ...req.body,
      whatsappApiKey: req.body.whatsappApiKey ? '********' : undefined,
      smsApiKey: req.body.smsApiKey ? '********' : undefined,
      emailPassword: req.body.emailPassword ? '********' : undefined
    }
  });
});

export const communicationRoutes = router;
